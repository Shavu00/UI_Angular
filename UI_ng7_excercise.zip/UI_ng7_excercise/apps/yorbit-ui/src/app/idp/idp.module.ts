import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IdpComponent } from './idp.component';
import { IdpPopupComponent } from './idp-popup/idp-popup.component';
import { ReusableUiModule } from '@YorbitWorkspace/reusable-ui';
import { MatDialogModule, MatIconModule, MatButtonModule } from '@angular/material';

@NgModule({
  imports: [
    CommonModule,

    MatDialogModule,
    MatIconModule,
    MatButtonModule,


    ReusableUiModule
  ],
  declarations: [IdpComponent, IdpPopupComponent],
  entryComponents:[IdpPopupComponent]
})
export class IdpModule { }
