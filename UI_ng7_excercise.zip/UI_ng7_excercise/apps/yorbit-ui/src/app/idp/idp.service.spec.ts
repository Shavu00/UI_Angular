import { TestBed, inject } from '@angular/core/testing';

import { IdpService } from './idp.service';

describe('IdpService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [IdpService]
    });
  });

  it('should be created', inject([IdpService], (service: IdpService) => {
    expect(service).toBeTruthy();
  }));
});
