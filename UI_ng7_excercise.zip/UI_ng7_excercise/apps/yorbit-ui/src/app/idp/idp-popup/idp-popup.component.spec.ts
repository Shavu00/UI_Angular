import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IdpPopupComponent } from './idp-popup.component';

describe('IdpPopupComponent', () => {
  let component: IdpPopupComponent;
  let fixture: ComponentFixture<IdpPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IdpPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IdpPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
