import { IdpModule } from './idp.module';

describe('IdpModule', () => {
  let idpModule: IdpModule;

  beforeEach(() => {
    idpModule = new IdpModule();
  });

  it('should create an instance', () => {
    expect(idpModule).toBeTruthy();
  });
});
