import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppRoutesRoutingModule } from './app-routes-routing.module';

@NgModule({
  imports: [CommonModule, AppRoutesRoutingModule],
  declarations: [],
  exports: [AppRoutesRoutingModule]
})
export class AppRoutesModule {}
