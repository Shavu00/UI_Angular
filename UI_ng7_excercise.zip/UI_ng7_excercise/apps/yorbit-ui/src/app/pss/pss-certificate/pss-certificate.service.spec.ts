import { TestBed, inject } from '@angular/core/testing';

import { PssCertificateService } from './pss-certificate.service';

describe('PssCertificateService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PssCertificateService]
    });
  });

  it('should be created', inject([PssCertificateService], (service: PssCertificateService) => {
    expect(service).toBeTruthy();
  }));
});
