import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PssActionedContentTileComponent } from './pss-actioned-content-tile.component';

describe('PssActionedContentTileComponent', () => {
  let component: PssActionedContentTileComponent;
  let fixture: ComponentFixture<PssActionedContentTileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PssActionedContentTileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PssActionedContentTileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
