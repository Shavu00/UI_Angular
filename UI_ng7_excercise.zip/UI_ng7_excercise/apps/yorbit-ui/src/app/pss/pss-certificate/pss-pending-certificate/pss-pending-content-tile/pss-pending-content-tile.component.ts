import { Component, OnInit, Input } from '@angular/core';
import { PssCertificateService } from '../../pss-certificate.service';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { PssStatusMessageComponent } from '../../pss-status-message/pss-status-message.component';

@Component({
  selector: 'yorbit-pss-pending-content-tile',
  templateUrl: './pss-pending-content-tile.component.html',
  styleUrls: ['./pss-pending-content-tile.component.scss']
})
export class PssPendingContentTileComponent implements OnInit {
  @Input() unitList: any;
  disableOtherRequest: boolean;
  tileSetup: {
    textAreaInput: any[];
    requestInProgress: any[];
    acceptButtonTitle: any[];
    denyButtonTitle: any[];
  };
  constructor(
    private _PssCertificateService: PssCertificateService,
    private dialog: MatDialog
  ) {}

  ngOnInit() {
    this.disableOtherRequest = false;
    this.tileSetup = {
      textAreaInput: [],
      requestInProgress: [],
      acceptButtonTitle: [],
      denyButtonTitle: []
    };
    this.tileSetupInit();
  }

  tileSetupInit() {
    if (this.unitList && this.unitList) {
      this.unitList.forEach(value => {
        this.tileSetup.textAreaInput[value.RequestId] = [];
        this.tileSetup.requestInProgress[value.RequestId] = false;
        this.tileSetup.acceptButtonTitle[value.RequestId] = 'accept';
        this.tileSetup.denyButtonTitle[value.RequestId] = 'deny';
      });
    }
  }

  accept(request) {
    this.tileSetup.requestInProgress[request.RequestId] = true;
    this.disableOtherRequest = true;
    this.tileSetup.acceptButtonTitle[request.RequestId] = 'accepting...';
    if (null===this.tileSetup.textAreaInput[request.RequestId]||this.tileSetup.textAreaInput[request.RequestId].length === 0) {
      this.tileSetup.textAreaInput[request.RequestId] = null;
    }
    const obj = {
      RequestId: request.RequestId,
      AcceptOrDeny: 'ACCEPTED',
      CourseId: request.CourseId,
      CourseUniqueId: request.CourseUniqueId,
      Remarks: this.tileSetup.textAreaInput[request.RequestId],
      LearnerId: request.MID,
      Expertise: request.Expertise
    };
    this._PssCertificateService
      .takeActionOnPendingRequest(obj)
      .then(response => {
        this.disableOtherRequest = false;
        if (response === 'ACCEPTED') {
          this.tileSetup.acceptButtonTitle[request.RequestId] = 'accepted';
        } else {
          //Failed popup
          // $state.go( "NoAutoCloseModal.popupTmpl", {
          //     'selectedContext': "PSSInternalCertPostActionMessage",
          //     data: {
          //         "message": response
          //     }
          // } );
          this.tileSetup.acceptButtonTitle[request.RequestId] = 'Failed';
    this.tileSetup.requestInProgress[request.RequestId] = false;
          this.disableOtherRequest = false;
          this.openMessagePopup(response);
        }
      })
      .catch(function(error) {
        this.tileSetup.acceptButtonTitle[request.RequestId] = 'Failed';
    this.tileSetup.requestInProgress[request.RequestId] = false;
        this.disableOtherRequest = false;
        this.openMessagePopup(error);
      });
  }
  deny(request) {
    this.tileSetup.requestInProgress[request.RequestId] = true;
    this.disableOtherRequest = true;
    this.tileSetup.denyButtonTitle[request.RequestId] = 'denying...';
    const obj = {
      RequestId: request.RequestId,
      AcceptOrDeny: 'DENIED',
      CourseId: request.CourseId,
      CourseUniqueId: request.CourseUniqueId,
      Remarks: this.tileSetup.textAreaInput[request.RequestId],
      LearnerId: request.MID,
      Expertise: request.Expertise
    };
    this._PssCertificateService
      .takeActionOnPendingRequest(obj)
      .then(response => {
        this.disableOtherRequest = false;
        if (response === 'DENIED') {
          this.tileSetup.denyButtonTitle[request.RequestId] = 'denied';
        }
        else{
          this.tileSetup.denyButtonTitle[request.RequestId] = 'Failed';
          this.tileSetup.requestInProgress[request.RequestId] = false;
                this.disableOtherRequest = false;
                this.openMessagePopup(response);
        }
      })
      .catch(function(error) {
        this.tileSetup.denyButtonTitle[request.RequestId] = 'Failed';
        this.disableOtherRequest = false;
    this.tileSetup.requestInProgress[request.RequestId] = false;
        this.openMessagePopup(error);
      });
  }

  downloadCertificate(filePath) {
    window.open(filePath, '_blank');
  }
  openMessagePopup(message) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.panelClass = 'popupDialogContainer';
    //pssMessageDialogContainer
    dialogConfig.data = {
      message: message
    };
    this.dialog.open(PssStatusMessageComponent, dialogConfig);
  }
}
