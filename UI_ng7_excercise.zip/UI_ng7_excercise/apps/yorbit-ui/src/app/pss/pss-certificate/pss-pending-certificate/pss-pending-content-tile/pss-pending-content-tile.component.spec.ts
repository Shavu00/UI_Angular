import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PssPendingContentTileComponent } from './pss-pending-content-tile.component';

describe('PssPendingContentTileComponent', () => {
  let component: PssPendingContentTileComponent;
  let fixture: ComponentFixture<PssPendingContentTileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PssPendingContentTileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PssPendingContentTileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
