import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PssPendingCertificateComponent } from './pss-pending-certificate.component';

describe('PssPendingCertificateComponent', () => {
  let component: PssPendingCertificateComponent;
  let fixture: ComponentFixture<PssPendingCertificateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PssPendingCertificateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PssPendingCertificateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
