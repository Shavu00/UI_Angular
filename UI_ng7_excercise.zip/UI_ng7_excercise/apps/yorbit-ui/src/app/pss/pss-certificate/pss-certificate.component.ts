import { Component, OnInit, Input, ViewChild, OnChanges } from '@angular/core';
import { GraphDataService } from '@YorbitWorkspace/graph';
import { PssCertificateService } from './pss-certificate.service';
import { PssPendingCertificateComponent } from './pss-pending-certificate/pss-pending-certificate.component';

@Component({
  selector: 'yorbit-pss-certificate',
  templateUrl: './pss-certificate.component.html',
  styleUrls: ['./pss-certificate.component.scss']
})
export class PssCertificateComponent implements OnInit, OnChanges {
  @Input() pssSubGroupSelected: string;

  paginateFilter: {
    pageSizeLimit: number;
    pageLength: number;
    pageIndex: number;
    PaginationContentIndex: number;
    previousPageIndex: number;
  };
  orderBy: { type: string; text: string };
  arrangeByCourseList: any[];
  contentListItems: any;
  showLoading: any;
  pssFilterRange: {
    StartDate: any;
    EndDate: any;
    Expertise: string;
    CourseName: string;
    CourseType: string;
    Vendor: string;
    Academy: string;
    IsArrangeByDate: boolean;
    SearchRequestId: number;
    SearchMid: string;
  };
  textAreaInput: any;
  requestInProgress: any;
  acceptButtonTitle: any;
  denyButtonTitle: any;
  actionedStatus: string;
  constructor(
    private _PssCertificateService: PssCertificateService,
    private _GraphDataService: GraphDataService
  ) {}

  ngOnChanges(changesObj) {
    //console.log(changesObj);
    if (changesObj['pssSubGroupSelected']) {
      this.actionedStatus = 'accepted';
      this.showLoading = {
        contentData: false
      };

      this.pssFirstload();
    }
  }
  ngOnInit() {}

  pssFirstload() {
    this.getPssListInit();
    this.getPssListData();
  }
  getPssListInit() {
    let startDate, endDate;

    this.paginateFilter = {
      pageSizeLimit: 20,
      pageLength: 0,
      pageIndex: 0,
      PaginationContentIndex: 0,
      previousPageIndex: 0
    };
    this.orderBy = {
      type: 'date',
      text: 'Arrange by Course'
    };

    const StartDate = new Date();
    StartDate.setDate(StartDate.getDate() - 1);
    const EndDate = new Date();

    //setting the date according to the right format
    startDate =
      StartDate.getMonth() +
      1 +
      '-' +
      StartDate.getDate() +
      '-' +
      StartDate.getFullYear();
    endDate =
      EndDate.getMonth() +
      1 +
      '-' +
      EndDate.getDate() +
      '-' +
      EndDate.getFullYear();
    this.pssFilterRange = {
      StartDate: startDate,
      EndDate: endDate,
      Expertise: '',
      CourseName: '',
      CourseType: '',
      Vendor: '',
      Academy: '',
      IsArrangeByDate: true,
      SearchRequestId: 0,
      SearchMid: ''
    };
  }

  /*
  CertificationStatus: this.certificationStatuses,
  CertificationSubStatus: this.certificationSubStatuses,
  Location: "",
*/

  getPssListData() {
    //setting the params required for url
    const urlParam = {
      limit: this.paginateFilter.pageSizeLimit,
      count: this.paginateFilter.PaginationContentIndex,
      nextOrPrevious: 'next'
    };
    //setting the payloads
    this.showLoading.contentData = true;
    console.log('PSS', this.pssSubGroupSelected);
    if ('Pending' === this.pssSubGroupSelected) {
      this._PssCertificateService
        .getPssCertificatePendingItems(this.pssFilterRange, urlParam)
        .then(response => {
          //
          this.setContentListItems(response);
        });
    } else {
      this._PssCertificateService
        .getPssCertificateActionedItems(
          this.actionedStatus,
          this.pssFilterRange,
          urlParam
        )
        .then(response => {
          //
          this.setContentListItems(response);
        });
    }
  }

  updatePssList(filterData) {
    this.pssFilterRange = {
      StartDate: filterData.StartDate,
      EndDate: filterData.EndDate,

      Expertise: filterData.Expertise,
      CourseType: filterData.CourseType,
      Vendor: filterData.Vendor,
      Academy: filterData.Academy,

      CourseName: filterData.CourseName,
      IsArrangeByDate: filterData.IsArrangeByDate,

      SearchRequestId: this.pssFilterRange.SearchRequestId,
      SearchMid: this.pssFilterRange.SearchMid
    };

    this.getPssListData();
  }
  updatePaginateData(paginateData) {
    this.paginateFilter = {
      pageSizeLimit: paginateData.pageSize,
      pageLength: paginateData.length,
      pageIndex: paginateData.pageIndex,
      PaginationContentIndex: paginateData.pageIndex * paginateData.pageSize,
      previousPageIndex: paginateData.previousPageIndex
    };
    this.getPssListData();
  }
  updateSearch(search) {
    this.getPssListInit();
    this.pssFilterRange.SearchRequestId = search.SearchRequestId;
    this.pssFilterRange.SearchMid = search.SearchMid;
    this.getPssListData();
  }

  setContentListItems(response) {
    this.paginateFilter.pageLength = response.count;
    if (!this.pssFilterRange.IsArrangeByDate) {
      this.arrangeByCourseList = [];
      for (let i = 0; i < response.PSSCertificateRequestItemList.length; i++) {
        if (
          -1 ===
          this.arrangeByCourseList.indexOf(
            response.PSSCertificateRequestItemList[i].CourseName
          )
        ) {
          this.arrangeByCourseList.push(
            response.PSSCertificateRequestItemList[i].CourseName
          );
        }
      }
    }
    this.contentListItems = response;
    this.showLoading.contentData = false;
    // getting the graph details of user and setting it to the model
    this.contentListItems.PSSCertificateRequestItemList.forEach((value, key) => {
      this._GraphDataService
        .getUserName(this.contentListItems.PSSCertificateRequestItemList[key].MID)
        .subscribe(responseUserName => {
          this.contentListItems.PSSCertificateRequestItemList[key].Name = responseUserName.value;
        });
      if (null !== this.contentListItems.PSSCertificateRequestItemList[key].LastmodifiedBy) {
        this._GraphDataService
          .getUserName(this.contentListItems.PSSCertificateRequestItemList[key].LastmodifiedBy)
          .subscribe(responseUserName => {
            this.contentListItems.PSSCertificateRequestItemList[key].ActionedByName =
              responseUserName.value;
          });
      }
    });
  }

  actionStatusChangeUpdate(status) {
    this.actionedStatus = status;
    this.getPssListData();
  }

  resetFilter(event) {
    this.pssFirstload();
  }
}
