import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { EnvironmentService, Ienvironment } from '@YorbitWorkspace/global-environments';

@Injectable()
export class PssCertificateService {
  config: Ienvironment;

  constructor(
    private http: HttpClient,
    private _envSvc: EnvironmentService,
  ) {
    this.config = this._envSvc.getEnvironment();
  }

  getPssCertificatePendingItems( range, urlParam ) {
    const Url = this.config.apiUrl + "PSS/CertificateRequest/Pending/" + urlParam.limit + "/" + urlParam.count + "/" + urlParam.nextOrPrevious;
    return this.http
    .post<any>(Url,range)
    .toPromise();
};
//getting PSS certificate actioned data list
getPssCertificateActionedItems( status, range, urlParam ) {
    const Url = this.config.apiUrl + "PSS/CertificateRequest/Actioned/" + status + "/" + urlParam.limit + "/" + urlParam.count + "/" + urlParam.nextOrPrevious;
    return this.http
    .post<any>(Url,range)
    .toPromise();
};
//PSS certificate action
takeActionOnPendingRequest( payload ) {
    const Url = this.config.apiUrl + "PSS/InternalCertificateAction";
    return this.http
    .post<any>(Url,payload)
    .toPromise();
};
}
