import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'yorbit-pss-actioned-content-tile',
  templateUrl: './pss-actioned-content-tile.component.html',
  styleUrls: ['./pss-actioned-content-tile.component.scss']
})
export class PssActionedContentTileComponent implements OnInit {
@Input() unitList:any;


  constructor() { }

  ngOnInit() {
  }

}
