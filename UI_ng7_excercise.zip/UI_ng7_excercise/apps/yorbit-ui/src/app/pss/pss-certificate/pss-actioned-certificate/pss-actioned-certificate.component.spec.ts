import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PssActionedCertificateComponent } from './pss-actioned-certificate.component';

describe('PssActionedCertificateComponent', () => {
  let component: PssActionedCertificateComponent;
  let fixture: ComponentFixture<PssActionedCertificateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PssActionedCertificateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PssActionedCertificateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
