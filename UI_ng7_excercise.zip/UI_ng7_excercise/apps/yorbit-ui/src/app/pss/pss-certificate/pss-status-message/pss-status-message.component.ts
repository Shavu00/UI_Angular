import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { PssPendingContentTileComponent } from '../pss-pending-certificate/pss-pending-content-tile/pss-pending-content-tile.component';

@Component({
  selector: 'yorbit-pss-status-message',
  templateUrl: './pss-status-message.component.html',
  styleUrls: ['./pss-status-message.component.scss']
})
export class PssStatusMessageComponent implements OnInit {

  constructor(    public dialogRef: MatDialogRef<PssPendingContentTileComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,) { }

  ngOnInit() {
  }
  closePopup() {
    this.dialogRef.close();
  }

}
