import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'yorbit-pss-pending-certificate',
  templateUrl: './pss-pending-certificate.component.html',
  styleUrls: ['./pss-pending-certificate.component.scss']
})
export class PssPendingCertificateComponent implements OnInit {
  @Input() contentData: any;
  @Input() IsArrangeByDate: string;
  @Input() arrangeByCourseList: any;

  constructor() {}

  ngOnInit() {  
    console.log(this.contentData);
  }

}
