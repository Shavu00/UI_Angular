import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PssCertificateComponent } from './pss-certificate.component';

describe('PssCertificateComponent', () => {
  let component: PssCertificateComponent;
  let fixture: ComponentFixture<PssCertificateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PssCertificateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PssCertificateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
