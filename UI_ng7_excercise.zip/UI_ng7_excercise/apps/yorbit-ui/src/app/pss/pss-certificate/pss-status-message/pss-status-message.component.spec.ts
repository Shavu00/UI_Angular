import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PssStatusMessageComponent } from './pss-status-message.component';

describe('PssStatusMessageComponent', () => {
  let component: PssStatusMessageComponent;
  let fixture: ComponentFixture<PssStatusMessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PssStatusMessageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PssStatusMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
