import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'yorbit-pss-actioned-certificate',
  templateUrl: './pss-actioned-certificate.component.html',
  styleUrls: ['./pss-actioned-certificate.component.scss']
})
export class PssActionedCertificateComponent implements OnInit {
  @Input() contentData: any;
  @Input() IsArrangeByDate: string;
  @Input() arrangeByCourseList: any;
  @Input() actionedStatus: string;
  @Output() actionStatusChange = new EventEmitter<string>();

  constructor() {}

  ngOnInit() {}

  actionedStatusChanged(event) {
    this.actionStatusChange.emit(event.value);
  }
}
