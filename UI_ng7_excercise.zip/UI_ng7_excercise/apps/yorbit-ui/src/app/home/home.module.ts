import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ContentTilesModule } from '../shared/content-tiles/content-tiles.module';
import { NgbCarouselModule } from '@ng-bootstrap/ng-bootstrap';
import { ReusableUiModule } from '@YorbitWorkspace/reusable-ui';
import { LearnerRecognitionComponent } from './learner-recognition/learner-recognition.component';
import { RecognitionProfileComponent } from './learner-recognition/recognition-profile/recognition-profile.component';
import { NasscomModule } from '../shared/nasscom/nasscom.module';
import { GeneralInfoComponent } from '../shared/global-popups/general-info/general-info.component';



@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    ContentTilesModule,
    NgbCarouselModule,
    ReusableUiModule,
    NasscomModule
  ],
  declarations: [HomeComponent, LearnerRecognitionComponent, RecognitionProfileComponent],
  entryComponents: [GeneralInfoComponent]
})
export class HomeModule { }
