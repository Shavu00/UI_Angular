import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecognitionProfileComponent } from './recognition-profile.component';

describe('RecognitionProfileComponent', () => {
  let component: RecognitionProfileComponent;
  let fixture: ComponentFixture<RecognitionProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecognitionProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecognitionProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
