import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LearnerRecognitionComponent } from './learner-recognition.component';

describe('LearnerRecognitionComponent', () => {
  let component: LearnerRecognitionComponent;
  let fixture: ComponentFixture<LearnerRecognitionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LearnerRecognitionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LearnerRecognitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
