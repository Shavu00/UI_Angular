﻿import {
  Component,
  OnInit,
  ViewChild,
  ViewContainerRef,
  Inject,
  AfterViewInit
} from '@angular/core';
import { DynamicComponentLoaderService } from '../dynamic-component-loader/dynamic-component-loader.service';
import { ImagesGridComponent } from '../dynamic-component-loader/images/images-grid/images-grid.component';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import * as fromUserDetailsStore from '../shared/user-details/store';
import { IuserDetails } from '../shared/user-details/store/user-details.interface';
import { NewAndTrendingService } from '../shared/services/new-and-trending.service';
import { TopLearnersService } from '../shared/services/top-learners.service';
import { DomSanitizer } from '@angular/platform-browser';
import { WINDOW } from '../shared/services/window.service';
import { PopupTriggerService } from '../shared/services/popup-trigger.service';
import { Globals } from '../globals';
import { GraphDataService, getName } from '@YorbitWorkspace/graph';
import { ManagerFeedbackComponent } from '../shared/global-popups/manager-feedback/manager-feedback.component';
import { PopupService } from '../shared/global-popups/popup.service';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { HomeService } from './home.service';
import { GeneralInfoComponent } from '../shared/global-popups/general-info/general-info.component';
import { AppInsightService } from '@YorbitWorkspace/app-insight';
import { MediaChange, MediaObserver } from '@angular/flex-layout';
@Component({
  selector: 'yorbit-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  providers: [NgbCarouselConfig]
})
export class HomeComponent implements OnInit, AfterViewInit {
  packages: any;
  userDetails: IuserDetails;
  userDetailsLoaded: boolean;
  showAllRecommendedCourses: boolean;
  recommendations: any;
  recommendationsFullList: any;
  newAndTrending: any;
  isnewAndTrendingLoading: boolean;
  isTopLearnersLoading: boolean;
  topLearnersList: any;
  navCount: number;
  startCount: number;
  endCount: number;
  previousMonth: string;
  fileToUpload: File = null;

  @ViewChild('testOutlet', { read: ViewContainerRef })
  testOutlet: ViewContainerRef;

  constructor(
    private dynamicLoaderService: DynamicComponentLoaderService,
    config: NgbCarouselConfig,
    private _router: Router,
    private userDetailsStore: Store<fromUserDetailsStore.IuserDetailsState>,
    private _newAndTrendingService: NewAndTrendingService,
    private _topLearnersService: TopLearnersService,
    @Inject(WINDOW) private _window: Window,
    private _graphSvc: GraphDataService,
    private sanitizer: DomSanitizer,
    public globals: Globals,
    private _popupSvc: PopupService,
    private dialog: MatDialog,
    private _popupTriggerService: PopupTriggerService,
    private _homeService: HomeService,
    private _insightService: AppInsightService,
    private mediaObserver: MediaObserver
  ) {
    // config.showNavigationArrows = true;
    // config.showNavigationIndicators = true;
    config.interval = 10000;
    config.wrap = false;
    config.keyboard = false;
    config.pauseOnHover = false;
  }
  ngOnInit() {
    this.userDetailsLoaded = false;
    this.navCount = 0;
    this.startCount = 0;
    this.endCount = 4;
    this.showAllRecommendedCourses = false;
    this.recommendationsFullList = [];
    this.recommendations = [];
    this.newAndTrending = [];
    this.topLearnersList = [];
    this.subscribeMediaChanges();
    this.getPreviousMonth();

    this.getUserDetails();
    this.getNewAndTrending();
    this.getTopLearners();
    this.getReleasePopupStatus();
    this._popupTriggerService.canTriggerPopupsOnLoad.subscribe(
      canTriggerPopupOnLoad => {
        if (canTriggerPopupOnLoad) {
          this._popupSvc
            .isManagerFeedbackPending()
            .then(isManagerFeedbackPending => {
              if (
                isManagerFeedbackPending &&
                !this.globals.isManagerFeedbackPopupShown
              ) {
                this.openMgrFeedbackDialog();
              }
            });
        }
      }
    );
  }

  ngAfterViewInit() {
    this.loadComponent();
  }
  subscribeMediaChanges() {
    this.mediaObserver.media$.subscribe((media: MediaChange) => {
      if (media.mqAlias == 'xs' || media.mqAlias == 'sm') {
        this.showAllRecommendedCourses = true;
      } else {
        this.showAllRecommendedCourses = false;
      }
      if (this.showAllRecommendedCourses) {
        this.recommendations = this.recommendationsFullList;
      } else {
        this.recommendations = this.recommendationsFullList.slice(0, 3);
      }
    });
  }
  loadComponent() {
    this.dynamicLoaderService
      .getComponentFactory<ImagesGridComponent>('images-grid')
      .subscribe(
        componentFactory => {
          this.testOutlet.createComponent(componentFactory);
        },
        error => {}
      );
  }
  goToHelp() {
    this._router.navigate(['/info/aboutus']);
  }
  goToFAQ() {
    this._router.navigate(['/info/faq/', 'General']);
  }
  goToFeedback() {
    this._router.navigate(['/info/feedback']);
  }
  getUserDetails() {
    this.userDetailsStore
      .select(fromUserDetailsStore.getUserDetailObject)
      .subscribe(data => {
        if (data.id !== '' && !this.userDetailsLoaded) {
          this.userDetailsLoaded = true;
          this.userDetails = data;
          this.getRecommendedCoursesForUser(data.id);
        } else {
          this.userDetails = {};
        }
      });
  }
  getRecommendedCoursesForUser(mid) {
    this._homeService.getRecommendedCourses(mid).then((res: any) => {
      if (res != null && res.length !== 0) {
        this.recommendationsFullList = res;
        this._homeService.personalizedRecommendations = res;
        if (this.showAllRecommendedCourses) {
          this.recommendations = this.recommendationsFullList;
        } else {
          this.recommendations = res.slice(0, 3);
        }
      } else {
        this.recommendations = [];
      }
    });
  }
  showAllRecommendations() {
    this.recommendations = this.recommendationsFullList;
  }
  navigateToMyProfile() {
    this.globals.isPersonalisedRecommendationsClicked = true;
    this._router.navigate(['my-page/' + this.userDetails.id + '/self']);
  }
  getContextForMobile() {
    if (this.recommendations.length > 0) {
      return this.recommendations;
    } else {
      return this.topLearnersList;
    }
  }
  getNewAndTrending() {
    this.isnewAndTrendingLoading = true;
    this._newAndTrendingService.getNewAndTrendingList().then(
      (data: any) => {
        this.isnewAndTrendingLoading = false;
        if (data.newPackages.packages.length > 0) {
          for (let i = 0; i < data.newPackages.packages.length; i++) {
            this.newAndTrending.push(data.newPackages.packages[i]);
          }
        }
        if (data.trendingPackages.packages.length > 0) {
          for (let i = 0; i < data.trendingPackages.packages.length; i++) {
            this.newAndTrending.push(data.trendingPackages.packages[i]);
          }
        }

        // extra element to keep the index in bound
        this.newAndTrending.push(data.trendingPackages.packages[0]);
      },
      error => {
        this.isnewAndTrendingLoading = false;
        this.newAndTrending = [];
      }
    );
  }

  getTopLearners() {
    this.isTopLearnersLoading = true;
    this._topLearnersService.getTopLearners().then(
      (data: any) => {
        this.isTopLearnersLoading = false;
        if (data.length > 0) {
          for (let i = 0; i < data.length; i++) {
            data.Image = null;
            data.Designation = null;
          }
          this.globals.topLearnersData = data;
          this.topLearnersList = this.globals.topLearnersData;
          this.getTopLearnerInfo();
        }
        return this.topLearnersList;
      },
      error => {
        this.isTopLearnersLoading = false;
        this.topLearnersList = [];
        console.log('Error', error);
        return this.topLearnersList;
      }
    );
  }

  getTopLearnerInfo() {
    for (let i = 0; i < this.topLearnersList.length; i++) {
      if (this.globals.topLearnersData[i].Image == null) {
        this._graphSvc
          .getUserImage(this.globals.topLearnersData[i].MID)
          .subscribe(
            data => {
              this.globals.topLearnersData[i].Image = this.createImageURL(data);
            },
            error => {
              console.log('Error', error);
            }
          );
        this._graphSvc
          .getUserJobTitle(this.globals.topLearnersData[i].MID)
          .subscribe(
            data => {
              this.globals.topLearnersData[i].Designation = data.value;
            },
            error => {
              this.globals.topLearnersData[i].Designation = 'NA';
              console.log('Error', error);
            }
          );
      }
    }
  }

  createImageURL(imageBlob) {
    const imageURL = this._window.URL.createObjectURL(imageBlob);
    return this.sanitizer.bypassSecurityTrustUrl(imageURL);
  }

  next(count, isMobile) {
    if (!isMobile) {
      if (count + 1 < 4) {
        this.navCount = ++count;
        this.startCount = this.navCount * 4;
        this.endCount = this.navCount * 4 + 4;
      }
    } else {
      if (count + 1 < this.newAndTrending.length - 1) {
        this.navCount = ++count;
        this.startCount = this.navCount;
        this.endCount = this.startCount + 1;
      }
    }
  }
  previous(count, isMobile) {
    if (!isMobile) {
      if (count - 1 !== -1) {
        this.navCount = --count;
        this.startCount = this.navCount * 4;
        this.endCount = this.navCount * 4 + 4;
      }
    } else {
      if (count - 1 !== -1) {
        this.navCount = --count;
        this.startCount = this.navCount;
        this.endCount = this.navCount + 1;
      }
    }
  }

  openMgrFeedbackDialog() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.panelClass = 'popupDialogContainer';
    this.dialog.open(ManagerFeedbackComponent, dialogConfig);
  }

  getPreviousMonth() {
    const month = new Date().getMonth();
    switch (month) {
      case 0:
        this.previousMonth = 'December';
        break;
      case 1:
        this.previousMonth = 'January';
        break;
      case 2:
        this.previousMonth = 'February';
        break;
      case 3:
        this.previousMonth = 'March';
        break;
      case 4:
        this.previousMonth = 'April';
        break;
      case 5:
        this.previousMonth = 'May';
        break;
      case 6:
        this.previousMonth = 'June';
        break;
      case 7:
        this.previousMonth = 'July';
        break;
      case 8:
        this.previousMonth = 'August';
        break;
      case 9:
        this.previousMonth = 'September';
        break;
      case 10:
        this.previousMonth = 'October';
        break;
      case 11:
        this.previousMonth = 'November';
        break;
    }
  }

  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
  }

  uploadFileToActivity() {
    this._homeService.postFile(this.fileToUpload).subscribe(
      data => {
        // do something, if upload success
        alert('upload success');
      },
      error => {
        console.log(error);
      }
    );
  }

  getReleasePopupStatus() {
    if (this.globals.showReleasePopup == null) {
      this._homeService.getPopupStatusForRelease().subscribe(
        data => {
          if (data === true || data === 'true') {
            this.globals.showReleasePopup = true;
          }
        },
        error => {
          this.globals.showReleasePopup = false;
          console.log(error);
        }
      );
    }
  }
  openGeneralInfoPopup() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.panelClass = 'popupDialogContainer';
    this.trackNewFeaturesInsights('Home Page');
    this.dialog.open(GeneralInfoComponent, dialogConfig);
  }
  trackNewFeaturesInsights(location) {
    const insightPayload = {
      Action: "What's New on Yorbit Clicked",
      Location: location
    };
    this._insightService.trackEvent('NASSCOM Future Skills', insightPayload);
  }
}
