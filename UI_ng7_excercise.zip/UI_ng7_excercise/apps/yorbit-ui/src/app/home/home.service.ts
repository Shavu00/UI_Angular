import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { EnvironmentService } from '@YorbitWorkspace/global-environments';
import { catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HomeService {
  _baseURL: string;
  personalizedRecommendations: any;
  constructor(private _http: HttpClient, private _envSvc: EnvironmentService) {
    this._baseURL = this._envSvc.getEnvironment().apiUrl;
    this.personalizedRecommendations = null;
  }
  getRecommendedCourses(mid) {
    if (this.personalizedRecommendations == null) {
      const url = this._baseURL + 'recommendations/byLearner/' + mid;
      return this._http.get(url).toPromise();
    } else {
      return new Promise((res, rej) => {
        res(this.personalizedRecommendations);
      });
    }
  }
  getNewTrendingPackages() {
    const url = this._baseURL + 'HomePage/TrendingAndNew';
    return this._http.get<any>(url);
  }

  getTopLearners() {
    const url = this._baseURL + 'User/TopLearners';
    return this._http.get<any>(url);
  }

  postFile(fileToUpload: File) {
    const endpoint = this._baseURL + 'HomePage/FutureSkillRecommendations/Dump';
    const formData: FormData = new FormData();
    formData.append('fileKey', fileToUpload, fileToUpload.name);
    return this._http.post(endpoint, formData);
  }
  getPopupStatusForRelease() {
    const url = this._baseURL + 'HomePage/PopUpStatusForRelease';
    return this._http.get<any>(url);
  }
}
