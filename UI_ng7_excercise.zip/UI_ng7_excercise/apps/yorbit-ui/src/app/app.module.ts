import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NxModule } from '@nrwl/nx';
import { RouterModule } from '@angular/router';
import { ServiceWorkerModule } from '@angular/service-worker';
import {
  FlexLayoutModule,
  BREAKPOINT,
  DEFAULT_BREAKPOINTS
} from '@angular/flex-layout';
import { StoreModule } from '@ngrx/store';
import { StoreRouterConnectingModule } from '@ngrx/router-store';

import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AdalInterceptor } from 'adal-angular4';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { AppRoutesModule } from './app-routes.module';
import { environment } from '../environments/environment';
import {
  reusableUiRoutes,
  ReusableUiModule
} from '@YorbitWorkspace/reusable-ui';
import { GlobalEnvironmentsModule } from '@YorbitWorkspace/global-environments';
import { HeaderModule } from './header/header.module';
import { BrowseModule } from './browse/browse.module';
import { RootStoreModule } from './root-store/root-store.module';
import { rootReducer, rootEffect } from './root-store/root-store.model';
import { AppInsightModule } from '@YorbitWorkspace/app-insight';
import { CourseRequestModule } from './course-request/course-request.module';
import { CardFeatureModule } from './shared/card-feature/card-feature.module';
import { ContentTilesModule } from './shared/content-tiles/content-tiles.module';
import { LearningPathModule } from './learning-path/learning-path.module';
import { MyPageModule } from './my-page/my-page.module';
import { GraphModule } from '@YorbitWorkspace/graph';
import { WINDOW_PROVIDERS } from './shared/services/window.service';
import { ContentAddedCheckService } from './shared/services/content-added-check.service';
import { QuizModule } from './quiz/quiz.module';
import { GlobalPopupsModule } from './shared/global-popups/global-popups.module';
import { Globals } from './globals';
import { PowerbiModule } from './powerbi/powerbi.module';
import { YammerModule } from './shared/yammer/yammer.module';
import { HomeModule } from './home/home.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { ManagerFeedbackComponent } from './shared/global-popups/manager-feedback/manager-feedback.component';
import { PssModule } from './pss/pss.module';
import {
  DynamicComponentLoaderModule,
  DynamicComponentManifest
} from './dynamic-component-loader/dynamic-component-loader.module';
// This array defines which "componentId" maps to which lazy-loaded module.

import { AoModule } from './ao/ao.module';
import { AssignContentModule } from './shared/card-feature/assign-content/assign-content.module';
import { GuardFailPageModule } from './shared/guard-fail-page/guard-fail-page.module';
import { IdpModule } from './idp/idp.module';
import { ToastModule } from './toast/toast.module';
import {
  MatButtonModule,
  MatIconModule,
  MatDividerModule,
  MatSidenavModule,
  MatSnackBarModule
} from '@angular/material';
@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    HttpClientModule,
    NxModule.forRoot(),
    StoreModule.forRoot(rootReducer, {}),
    EffectsModule.forRoot(rootEffect),
    FlexLayoutModule,
    BrowserAnimationsModule, // new modules added here
    ServiceWorkerModule.register('/combined-service-worker.js', {
      enabled: environment.production
    }),
    StoreDevtoolsModule.instrument({
      maxAge: 25, // Retains last 25 states
      logOnly: environment.production // Restrict extension to log-only mode
    }),
    StoreRouterConnectingModule.forRoot(),
    ReusableUiModule,
    GlobalEnvironmentsModule,
    AppInsightModule,
    AppRoutesModule,
    RootStoreModule,
    BrowseModule,
    HeaderModule,
    CourseRequestModule,
    FormsModule,
    MyPageModule,
    GraphModule,
    LearningPathModule,
    CardFeatureModule,
    LearningPathModule,
    ContentTilesModule,
    QuizModule,
    GlobalPopupsModule,
    PowerbiModule,
    YammerModule,
    PssModule,
    HomeModule,
    GuardFailPageModule,
    IdpModule,
    ToastModule,
    DynamicComponentLoaderModule.forRoot(),
    AoModule,
    AssignContentModule,
    NgbModule,

    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    MatSidenavModule,
    MatSnackBarModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AdalInterceptor, multi: true },
    WINDOW_PROVIDERS,
    Globals,
    ContentAddedCheckService
  ],
  bootstrap: [AppComponent],
  exports: [AppRoutesModule],
  entryComponents: [ManagerFeedbackComponent]
})
export class AppModule {}
