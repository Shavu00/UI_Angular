import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AccountDashboardComponent } from './account-dashboard.component';
import { PipesModule } from '@YorbitWorkspace/pipes';
import { ReusableUiModule } from "@YorbitWorkspace/reusable-ui";

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    FlexLayoutModule,
    PipesModule,
    ReusableUiModule
  ],
  declarations: [AccountDashboardComponent],
  exports: [AccountDashboardComponent]
})
export class AccountDashboardModule { }
