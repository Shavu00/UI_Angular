import {
  Component,
  OnInit,
  Input,
  OnChanges,
  Output,
  EventEmitter
} from '@angular/core';
import { AccountService } from '../account.service';

@Component({
  selector: 'yorbit-account-dashboard',
  templateUrl: './account-dashboard.component.html',
  styleUrls: ['./account-dashboard.component.scss']
})
export class AccountDashboardComponent implements OnInit, OnChanges {
  @Input('selectedAccount') selectedAccount;
  @Input('selectedProject') selectedProject;
  @Output() routeFromDashboardView = new EventEmitter<any>();
  selectedProjectRole: any;
  projectRoles: any;
  isPageLoading: any;
  constructor(private accountService: AccountService) {
    this.projectRoles = [];
    this.isPageLoading = true;
  }
  ngOnChanges(changeObj) {
    if (changeObj['selectedAccount'] || changeObj['selectedProject']) {
      this.getProjectRole();
    }
  }

  ngOnInit() {
    // if (
    //   this.selectedAccount !== undefined &&
    //   this.selectedProject !== undefined
    // ) {
    //   this.getProjectRole();
    // }
  }
  getProjectRole() {
    this.isPageLoading = true;
    //get the project role
    this.accountService
      .getAvailableProjectRoleList(
        this.selectedAccount.AccountId,
        this.selectedProject.ProjectId
      )
      .subscribe(roles => {
        this.projectRoles = roles;
        this.isPageLoading = false;
        //get other data
        this.projectRoles.forEach(element => {
          this.getDashboardCount(element);
          this.getDashboardStatus(element);
        });
      });
  }
  getDashboardCount(projectRole) {
    this.accountService
      .getDashboardMappedData(projectRole.RoleId)
      .subscribe(count => {
        if (count === null) {
          projectRole.Minds_Count = 0;
          projectRole.Skills_Count = 0;
          projectRole.AccCourses_Count = 0;
        } else {
          projectRole.Minds_Count = count.Minds_Count;
          projectRole.Skills_Count = count.Skills_Count;
          projectRole.AccCourses_Count = count.AccCourses_Count;
        }
      });
  }
  getDashboardStatus(projectRole) {
    this.accountService
      .getProjectRoleStatus(projectRole.RoleId)
      .subscribe(status => {
        if (status === null) {
          projectRole.InProgressCount = 0;
          projectRole.CompletedCount = 0;
          projectRole.NotStartedCount = 0;
        } else {
          projectRole.InProgressCount = status.InProgress_Count;
          projectRole.CompletedCount = status.Completed_Count;
          projectRole.NotStartedCount = status.NotStarted_Count;
        }
      });
  }
  goToOtherTab(tab, role) {
    const obj = {
      tab: tab,
      projectRole: role
    };
    this.routeFromDashboardView.emit(obj);
  }
}
