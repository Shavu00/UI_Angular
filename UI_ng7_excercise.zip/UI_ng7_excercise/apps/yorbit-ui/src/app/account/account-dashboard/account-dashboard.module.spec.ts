import { AccountDashboardModule } from './account-dashboard.module';

describe('AccountDashboardModule', () => {
  let accountDashboardModule: AccountDashboardModule;

  beforeEach(() => {
    accountDashboardModule = new AccountDashboardModule();
  });

  it('should create an instance', () => {
    expect(accountDashboardModule).toBeTruthy();
  });
});
