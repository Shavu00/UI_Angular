import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccountPbiDashboardComponent } from './account-pbi-dashboard.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [AccountPbiDashboardComponent],
  exports: [AccountPbiDashboardComponent]
})
export class AccountPbiDashboardModule { }
