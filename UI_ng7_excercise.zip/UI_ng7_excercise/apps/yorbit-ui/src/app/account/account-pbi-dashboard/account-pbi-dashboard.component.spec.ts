import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountPbiDashboardComponent } from './account-pbi-dashboard.component';

describe('AccountPbiDashboardComponent', () => {
  let component: AccountPbiDashboardComponent;
  let fixture: ComponentFixture<AccountPbiDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountPbiDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountPbiDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
