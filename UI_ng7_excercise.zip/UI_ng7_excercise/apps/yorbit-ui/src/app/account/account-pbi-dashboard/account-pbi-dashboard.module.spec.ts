import { AccountPbiDashboardModule } from './account-pbi-dashboard.module';

describe('AccountPbiDashboardModule', () => {
  let accountPbiDashboardModule: AccountPbiDashboardModule;

  beforeEach(() => {
    accountPbiDashboardModule = new AccountPbiDashboardModule();
  });

  it('should create an instance', () => {
    expect(accountPbiDashboardModule).toBeTruthy();
  });
});
