import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account.service';
import { NgxPowerBiService } from 'ngx-powerbi';
import { AdalService } from 'adal-angular4';

@Component({
  selector: 'yorbit-account-pbi-dashboard',
  templateUrl: './account-pbi-dashboard.component.html',
  styleUrls: ['./account-pbi-dashboard.component.scss']
})
export class AccountPbiDashboardComponent implements OnInit {
  allowedGroupList: any;
  groupList: any;
  reportPopup: boolean;
  noGroupAvailable: boolean;
  noContentPermission: boolean;
  selectedDashboard: any;
  ngxPowerBiService: NgxPowerBiService;
  reportElement: any;
  reportTitle: string;
  constructor(
    private accountService: AccountService,
    private adalService: AdalService
  ) {
    this.allowedGroupList = [
      'bf235cde-e1a4-4fa0-87fb-15e3cf84dd8a',
      '01cdabfb-9695-4dd7-b361-8cb50ea4d516'
    ];
    this.groupList = [];
    this.ngxPowerBiService = new NgxPowerBiService();
  }

  ngOnInit() {
    this.reportPopup = false;
    this.noGroupAvailable = false;
    this.noContentPermission = false;
    this.accountService.getGroup().subscribe(
      (group: any) => {
        for (let i = 0; i < group.value.length; i++) {
          if (-1 !== this.allowedGroupList.indexOf(group.value[i].id)) {
            this.groupList.push(group.value[i]);
          }
        }
        if (0 === this.groupList.length) {
          this.TriggerError('noGroup');
        }
        this.groupList.forEach((element, key) => {
          this.accountService
            .getPowerBiByGroup(element.id, 'dashboards')
            .subscribe(
              (response: any) => {
                this.groupList[key].dashboard = response.value.sort(
                  this.nameSort
                );
                this.groupList[key].dashboard.sort(this.nameSort);
                for (let i = 0; i < this.groupList[key].dashboard.length; i++) {
                  if (
                    this.groupList[key].dashboard[i].displayName ===
                    'Account Dashboard'
                  ) {
                    this.loadDashboard(this.groupList[key].dashboard[i]);
                  }
                }
              },
              error => {
                if (group.id === this.groupList[0].id) {
                  this.noContentPermission = true;
                }
              }
            );
        });
        this.groupList.sort(this.nameSort);
      },
      error => {
        this.TriggerError('UserNotLicensed');
      }
    );
  }
  loadDashboard(dashboardResponse) {
    this.noContentPermission = false;
    this.adalService
      .acquireToken('https://analysis.windows.net/powerbi/api')
      .subscribe(accessToken => {
        const config = this.getConfig(
          'dashboard',
          dashboardResponse.embedUrl,
          dashboardResponse.id,
          accessToken
        );
        // Get a reference to the embedded dashboard HTML element
        const container = document.getElementById('accountPageDashboardEmbed');
        while (container.hasChildNodes()) {
          container.removeChild(container.firstChild);
        }

        const dashboardContainer = document.createElement('div');
        dashboardContainer.id = dashboardResponse.id;
        dashboardContainer.className = 'dashboardEmbed';
        dashboardContainer.style.width = '100%';
        dashboardContainer.style.height = '100%';
        container.appendChild(dashboardContainer);

        const dashboard = this.ngxPowerBiService.embed(
          dashboardContainer,
          config
        );
        this.selectedDashboard = dashboardResponse.id;

        dashboard.off('error');
        dashboard.on('error', function(event) {
          console.log(event.detail);
          this.TriggerError('dashboard');
          dashboard.off('error');
        });

        dashboard.off('tileClicked');
        dashboard.on('tileClicked', function(event) {
          this.loadReport(event.detail);
        });
      });
  }
  loadReport(data) {
    this.reportTitle = 'Getting Report...';
    this.reportPopup = true;
    const idObj = this.getParameter(data.reportEmbedUrl);

    this.accountService
      .getPowerBiByGroup(idObj.groupId, 'reports')
      .subscribe((response: any) => {
        // const ReportTile = $filter('filter')(response.value, {
        //   id: idObj.reportId
        // })[0];
        const ReportTile = response.value.filter(
          element => element.id === idObj.reportId
        )[0];
        this.reportTitle = ReportTile.name;
        this.adalService
          .acquireToken('https://analysis.windows.net/powerbi/api')
          .subscribe(accesstoken => {
            const config = this.getConfig(
              'report',
              ReportTile.embedUrl,
              ReportTile.id,
              accesstoken
            );
            config.pageName = data.pageName;

            const container = document.getElementById('reportEmbed');
            while (container.hasChildNodes()) {
              container.removeChild(container.firstChild);
            }

            const reportContainer = document.createElement('div');
            reportContainer.id = idObj.reportId;
            reportContainer.className = 'embedReport';
            reportContainer.style.width = '100%';
            reportContainer.style.height = '100%';
            container.appendChild(reportContainer);

            //var reportContainer = document.getElementById('reportEmbed')

            const report = this.ngxPowerBiService.embed(
              reportContainer,
              config
            );
            report.off('loaded');
            report.on('loaded', function() {
              this.reportElement = report;
            });
          });
      });
  }
  getConfig(contentType, embedUrl, id, accesstoken) {
    const config: any = {
      type: contentType,
      embedUrl: embedUrl,
      accessToken: accesstoken
    };
    if ('dashboard' === contentType) {
      //Dashboard
      config.dashboardId = id;
    } else {
      //Report
      config.id = id;
    }

    return config;
  }
  TriggerError(error) {
    switch (error) {
      case 'noGroup':
        this.noGroupAvailable = true;
        break;
      default:
        this.noContentPermission = true;
    }
  }
  getParameter(url) {
    const regexGroup = new RegExp(/[?&]groupId(=([^&#]*)|&|#|$)/);
    const regexReport = new RegExp(/[?&]reportId(=([^&#]*)|&|#|$)/);
    const obj = {
      groupId: '',
      reportId: ''
    };

    let result = regexGroup.exec(url);
    obj.groupId = result[2];
    result = regexReport.exec(url);
    obj.reportId = result[2];
    return obj;
  }
  closeReport() {
    this.reportPopup = false;
  }
  fullScreen() {
    this.reportElement.fullscreen();
  }
  nameSort(a, b) {
    let comparison = 0;
    const titleA = a.name || a.displayName;
    const titleB = b.name || b.displayName;
    if (titleA > titleB) {
      comparison = 1;
    } else if (titleA < titleB) {
      comparison = -1;
    }
    return comparison;
  }
}
