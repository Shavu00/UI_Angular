import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AccountService } from '../../account.service';

@Component({
  selector: 'yorbit-add-project-course',
  templateUrl: './add-project-course.component.html',
  styleUrls: ['./add-project-course.component.scss']
})
export class AddProjectCourseComponent implements OnInit {
  @Input('selectedAccount') selectedAccount;
  @Input('selectedProject') selectedProject;
  @Input('addedCourseForCreate') addedCourseForCreate;
  accountProjectCourseList: any;
  typingForCourseStarted: boolean;
  selectedAccountAndProjectCourse: any;
  selectedAccountAndProjectCourseName: any;
  addedProjectCourseList: any;
  @Output() courseSelectedForCreate = new EventEmitter<any>();
  constructor(private accountService: AccountService) {
    this.accountProjectCourseList = [];
    this.addedProjectCourseList = [];
  }

  ngOnInit() {
    //console.log('addedCourseForCreate', this.addedCourseForCreate);
    this.addedProjectCourseList = this.addedCourseForCreate;
    this.typingForCourseStarted = false;
    //get all account/project course
    this.accountService
      .getAccountProjectCourseList(
        this.selectedAccount.AccountId,
        this.selectedProject.ProjectId
      )
      .subscribe(course => {
        //console.log(course);
        course.AccountCourseList.forEach(element => {
          element.isAccountOrProject = 'Account';
          this.accountProjectCourseList.push(element);
        });
        course.ProjectCourseList.forEach(element => {
          element.isAccountOrProject = 'Project';
          this.accountProjectCourseList.push(element);
        });
        //remove the existing one
        if (this.addedProjectCourseList.length !== 0) {
          this.addedProjectCourseList.forEach(element => {
            const index = this.accountProjectCourseList
              .map(function(x) {
                return x.CourseUniqueId;
              })
              .indexOf(element.CourseUniqueId);
            this.accountProjectCourseList.splice(index, 1);
          });
        }
      });
  }
  filterAccountAndProjectCourse(skill) {
    this.typingForCourseStarted = true;
  }
  closeSuggestionBox() {
    setTimeout(() => {
      this.typingForCourseStarted = false;
    }, 1000);
  }
  suggestedCourseSelected(course) {
    this.selectedAccountAndProjectCourse = course;
    this.selectedAccountAndProjectCourseName = course.CourseName;
  }
  addCourse() {
    if (this.selectedAccountAndProjectCourse !== undefined) {
      this.addedProjectCourseList.push(this.selectedAccountAndProjectCourse);
      const index = this.accountProjectCourseList
        .map(function(x) {
          return x.CourseUniqueId;
        })
        .indexOf(this.selectedAccountAndProjectCourse.CourseUniqueId);
      this.accountProjectCourseList.splice(index, 1);
      this.selectedAccountAndProjectCourse = undefined;
      this.selectedAccountAndProjectCourseName = '';
      this.courseSelectedForCreate.emit(this.addedProjectCourseList);
    }
  }
  removeAccountProjectCourse(pos, course) {
    this.addedProjectCourseList.splice(pos, 1);
    this.accountProjectCourseList.push(course);
    this.courseSelectedForCreate.emit(this.addedProjectCourseList);
  }
}
