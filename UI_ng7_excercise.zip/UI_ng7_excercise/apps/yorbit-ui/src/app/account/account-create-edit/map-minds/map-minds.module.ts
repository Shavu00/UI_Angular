import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MapMindsComponent } from './map-minds.component';
import { PipesModule } from '@YorbitWorkspace/pipes';
import { MatIconModule } from '@angular/material';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    FlexLayoutModule,
    MatIconModule,
    PipesModule
  ],
  declarations: [MapMindsComponent],
  exports: [MapMindsComponent]
})
export class MapMindsModule { }
