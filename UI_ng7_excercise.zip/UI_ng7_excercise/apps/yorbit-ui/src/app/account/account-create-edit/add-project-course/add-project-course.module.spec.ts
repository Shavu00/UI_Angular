import { AddProjectCourseModule } from './add-project-course.module';

describe('AddProjectCourseModule', () => {
  let addProjectCourseModule: AddProjectCourseModule;

  beforeEach(() => {
    addProjectCourseModule = new AddProjectCourseModule();
  });

  it('should create an instance', () => {
    expect(addProjectCourseModule).toBeTruthy();
  });
});
