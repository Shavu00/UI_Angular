import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { Store } from '@ngrx/store';
import { GraphDataService } from '@YorbitWorkspace/graph';
import { AccountService } from '../account.service';

@Component({
  selector: 'yorbit-account-create-edit',
  templateUrl: './account-create-edit.component.html',
  styleUrls: ['./account-create-edit.component.scss']
})
export class AccountCreateEditComponent implements OnInit, OnChanges {
  selectedProjectRole: any;
  selectedTabName: string;
  createProjectRoleClicked: boolean;
  availableProjectRoleList: any;
  yorbitCourseList: any;
  enteredSkillName: string;
  typingForSkillStarted: boolean;
  selectedExpertiseList: any;
  selectedCourseList: any;
  selectedExpertiseFromSkill: any;
  selectedCourseFromSkill: any;
  filteredSkillList: any;
  selectedAcademy: string;
  selectedGenre: string;
  accountProjectCourseList: any;
  typingForCourseStarted: boolean;
  selectedAccountAndProjectCourse: any;
  selectedAccountAndProjectCourseName: any;
  typingForMindStarted: boolean;
  selectedMindsForAdd: any;
  selectedMindsNameForAdd: any;
  listOfMindsToAdd: any;
  addedMindsList: any;
  panelOpenState: any;
  showActionItems: any;
  addedSkillsForCreate: any;
  addedCourseForCreate: any;
  addedMindsForCreate: any;
  selectedProjectRoleForEdit: any;
  oldSkillList: any;
  oldCourseList: any;
  oldMindList: any;
  @Input('selectedAccount') selectedAccount;
  @Input('selectedProject') selectedProject;
  logedInUserId: string;
  saveButtonTitle: string;
  disableCreateButton: boolean;
  showSaveAndCancelBtn: boolean;
  isPageLoading: boolean;
  constructor(
    private accountService: AccountService,
    private appStore: Store<any>,
    private _graphSvc: GraphDataService
  ) {
    this.availableProjectRoleList = [];
    this.yorbitCourseList = [];
    this.selectedExpertiseList = [];
    this.selectedCourseList = [];
    this.filteredSkillList = [];
    this.accountProjectCourseList = [];
    this.listOfMindsToAdd = [];
    this.addedMindsList = [];
    this.panelOpenState = [];
    this.showActionItems = [];
    this.addedSkillsForCreate = [];
    this.addedCourseForCreate = [];
    this.addedMindsForCreate = [];
    this.saveButtonTitle = 'Save';
    this.oldSkillList = [];
    this.oldCourseList = [];
    this.oldMindList = [];
    this.disableCreateButton = true;
    this.showSaveAndCancelBtn = false;
    this.isPageLoading = true;
  }
  ngOnChanges(changeObj) {
    if (changeObj['selectedAccount'] || changeObj['selectedProject']) {
      // get available project role
      this.getProjectRole();
      this.onfirstLoad();
    }
  }
  ngOnInit() {
    this.appStore.select('userDetails').subscribe(userDetails => {
      if (userDetails.user.loaded) {
        this.logedInUserId = userDetails.user.data.id;
      }
    });
    // get available project role
    this.getProjectRole();
    this.onfirstLoad();
  }
  onfirstLoad() {
    this.activeTabs('course');
    this.createProjectRoleClicked = false;
    this.typingForSkillStarted = false;
    this.selectedExpertiseList = [{ Expertise: 'Select Expertise' }];
    this.selectedCourseList = [{ CourseName: 'Select Course' }];
    this.selectedExpertiseFromSkill = this.selectedExpertiseList[0];
    this.selectedCourseFromSkill = this.selectedCourseList[0];
    //get all yorbit course
    this.accountService.getYorbitCourseList().subscribe(course => {
      this.yorbitCourseList = Object.assign([], course);
    });
    this.typingForCourseStarted = false;
    //get all account/project course
    this.accountService
      .getAccountProjectCourseList(
        this.selectedAccount.AccountId,
        this.selectedProject.ProjectId
      )
      .subscribe(course => {
        //console.log(course);
        course.AccountCourseList.forEach(element => {
          element.isAccountOrProject = 'Account';
          this.accountProjectCourseList.push(element);
        });
        course.ProjectCourseList.forEach(element => {
          element.isAccountOrProject = 'Project';
          this.accountProjectCourseList.push(element);
        });
        //console.log(this.accountProjectCourseList);
        this.accountProjectCourseList = this.accountService.removeDuplicatesObject(
          this.accountProjectCourseList,
          'CourseUniqueId'
        );
      });
    this.typingForMindStarted = false;
    this.selectedMindsNameForAdd = '';
    //get all minds
    this.accountService
      .getMindsListForAccountAndProject(
        this.selectedAccount.AccountId,
        this.selectedProject.ProjectId
      )
      .subscribe(minds => {
        this.listOfMindsToAdd = minds;
      });
  }
  getProjectRole() {
    this.accountService
      .getAvailableProjectRoleList(
        this.selectedAccount.AccountId,
        this.selectedProject.ProjectId
      )
      .subscribe(projectRole => {
        this.availableProjectRoleList = projectRole;
        this.isPageLoading = false;
        //console.log('available project role list', projectRole);
        this.availableProjectRoleList.forEach((ele, key) => {
          ele.MindsNameList = [];
          ele.MindsList.forEach(element => {
            // get name for each mid
            this._graphSvc.getUserName(element).subscribe(
              data => {
                const obj = { MID: element, MindName: data.value };
                this.availableProjectRoleList[key].MindsNameList.push(obj);
                this.availableProjectRoleList[
                  key
                ].MindsNameList = this.accountService.removeDuplicatesObject(
                  this.availableProjectRoleList[key].MindsNameList,
                  'MID'
                );
              },
              error => {
                const obj = { MID: element, MindName: element };
                this.availableProjectRoleList[key].MindsNameList.push(obj);
                this.availableProjectRoleList[
                  key
                ].MindsNameList = this.accountService.removeDuplicatesObject(
                  this.availableProjectRoleList[key].MindsNameList,
                  'MID'
                );
              }
            );
          });
        });
      });
  }
  activeTabs(tabName) {
    this.selectedTabName = tabName;
  }
  toggleAccordian(state, index) {
    if (state === 'open') {
      this.panelOpenState = [];
      this.panelOpenState[index] = true;
    } else {
      this.selectedProjectRoleForEdit = undefined;
      this.panelOpenState[index] = false;
      this.showActionItems[index] = false;
    }
  }
  filterProjectRole(role) {
    //console.log(role);
    if (this.availableProjectRoleList.length === 0) {
      if (
        this.selectedProjectRole === '' ||
        this.selectedProjectRole === undefined
      ) {
        this.disableCreateButton = true;
        this.showSaveAndCancelBtn = false;
      } else {
        this.disableCreateButton = false;
      }
    } else {
      let count = 0;
      this.availableProjectRoleList.forEach(element => {
        if (element.RoleName === role) {
          count++;
        }
        if (count > 0) {
          this.disableCreateButton = true;
        } else if (count === 0) {
          this.disableCreateButton = false;
        }
      });
    }
  }
  createProjectRole() {
    if (
      this.selectedProjectRole !== '' &&
      this.selectedProjectRole !== undefined &&
      !this.disableCreateButton
    ) {
      this.createProjectRoleClicked = true;
      this.showSaveAndCancelBtn = true;
    }
  }
  editProjectRole() {
    this.createProjectRoleClicked = false;
    this.showSaveAndCancelBtn = false;
  }
  editClicked(index, role) {
    this.toggleAccordian('open', index);
    this.showActionItems[index] = true;
    // remove existing skill
    this.removeExistingSkill(role);
    // remove existing course
    this.removeExistingCourse(role);
    // remove existing mind
    this.removeExistingMind(role);
    this.selectedProjectRoleForEdit = role;
    this.oldSkillList = role.YorbitSkillList.slice();
    this.oldCourseList = role.ProjectCourseList.slice();
    this.oldMindList = role.MindsNameList.slice();
  }
  removeExistingSkill(role) {
    //console.log(role.YorbitSkillList);
    role.YorbitSkillList.forEach(element => {
      this.yorbitCourseList.forEach((ele, key) => {
        if (element.Skill === ele.Skill) {
          if (ele.SkillDataList.length === 1) {
            ele.SkillDataList.forEach(el => {
              if (el.CourseList.length === 1) {
                this.yorbitCourseList.splice(key, 1);
              } else {
                el.CourseList.forEach((e, k) => {
                  if (e.CourseUniqueId === element.CourseUniqueId) {
                    el.CourseList.splice(k, 1);
                  }
                });
              }
            });
          } else {
            ele.SkillDataList.forEach((el, ke) => {
              if (
                el.Academy === element.Academy &&
                el.Genre === element.Genre
              ) {
                if (el.CourseList.length === 1) {
                  ele.SkillDataList.splice(ke, 1);
                } else {
                  el.CourseList.forEach((e, k) => {
                    if (el.CourseUniqueId === element.CourseUniqueId) {
                      el.CourseList.splice(k, 1);
                    }
                  });
                }
              }
            });
          }
        }
      });
    });
  }
  removeExistingCourse(role) {
    role.ProjectCourseList.forEach(element => {
      this.accountProjectCourseList.forEach((ele, key) => {
        if (element.CourseUniqueId === ele.CourseUniqueId) {
          this.accountProjectCourseList.splice(key, 1);
        }
      });
    });
  }
  removeExistingMind(role) {
    role.MindsNameList.forEach(element => {
      this.listOfMindsToAdd.forEach((ele, key) => {
        if (element.MID === ele.MID) {
          this.listOfMindsToAdd.splice(key, 1);
        }
      });
    });
  }
  filterSkillList(skill) {
    this.typingForSkillStarted = true;
    this.typingForCourseStarted = false;
    this.typingForMindStarted = false;
    this.selectedExpertiseList = [{ Expertise: 'Select Expertise' }];
    this.selectedCourseList = [{ CourseName: 'Select Course' }];
    this.selectedExpertiseFromSkill = this.selectedExpertiseList[0];
    this.selectedCourseFromSkill = this.selectedCourseList[0];
  }
  filterAccountAndProjectCourse(course) {
    this.typingForSkillStarted = false;
    this.typingForCourseStarted = true;
    this.typingForMindStarted = false;
  }
  filterMind(mind) {
    this.typingForSkillStarted = false;
    this.typingForCourseStarted = false;
    this.typingForMindStarted = true;
  }
  closeSuggestionBox() {
    setTimeout(() => {
      this.typingForSkillStarted = false;
      this.typingForCourseStarted = false;
      this.typingForMindStarted = false;
    }, 1000);
  }
  getExpertiseForSkill(course) {
    this.selectedAcademy = course.acadGenre.Academy;
    this.selectedGenre = course.acadGenre.Genre;
    this.filteredSkillList = course.acadGenre;
    this.enteredSkillName = course.selectedSkill;
    this.selectedExpertiseList = [];
    course.acadGenre.CourseList.forEach(element => {
      const obj = { Expertise: element.Expertise };
      this.selectedExpertiseList.push(obj);
    });
    this.selectedExpertiseList = this.accountService.removeDuplicatesObject(
      this.selectedExpertiseList,
      'Expertise'
    );
    this.selectedExpertiseFromSkill = this.selectedExpertiseList[0];
    //call to update course list
    this.filterCourseByExpertise();
  }
  filterCourseByExpertise() {
    this.selectedCourseList = [];
    this.filteredSkillList.CourseList.forEach(element => {
      if (element.Expertise === this.selectedExpertiseFromSkill.Expertise) {
        const obj = {
          CourseName: element.CourseName,
          CourseUniqueId: element.CourseUniqueId
        };
        this.selectedCourseList.push(obj);
      }
    });
    this.selectedCourseFromSkill = this.selectedCourseList[0];
  }
  addSkill(role) {
    if (
      this.selectedExpertiseFromSkill.Expertise === 'Select Expertise' ||
      this.selectedCourseList.CourseName === 'Select Course'
    ) {
      // do not push anything
    } else {
      const isExist = this.checkForExistingSkill(role.YorbitSkillList);
      if (isExist) {
        //do not push anything
      } else {
        this.showSaveAndCancelBtn = true;
        const obj = {
          Academy: this.selectedAcademy,
          Genre: this.selectedGenre,
          Skill: this.enteredSkillName,
          Expertise: this.selectedExpertiseFromSkill.Expertise,
          CourseName: this.selectedCourseFromSkill.CourseName,
          CourseUniqueId: this.selectedCourseFromSkill.CourseUniqueId
        };
        role.YorbitSkillList.push(obj);
        //remove added course from course list
        this.removeCourseFromMainList(obj);
      }
      this.enteredSkillName = '';
      this.selectedExpertiseList = [{ Expertise: 'Select Expertise' }];
      this.selectedCourseList = [{ CourseName: 'Select Course' }];
      this.selectedExpertiseFromSkill = this.selectedExpertiseList[0];
      this.selectedCourseFromSkill = this.selectedCourseList[0];
    }
  }
  checkForExistingSkill(array) {
    let status;
    for (let i = 0; i < array.length; i++) {
      if (
        array[i].Skill === this.enteredSkillName &&
        array[i].Expertise === this.selectedExpertiseFromSkill.Expertise &&
        array[i].CourseName === this.selectedCourseFromSkill.CourseName &&
        array[i].CourseUniqueId === this.selectedCourseFromSkill.CourseUniqueId
      ) {
        status = true;
        break;
      } else {
        status = false;
      }
    }
    return status;
  }
  removeCourseFromMainList(obj) {
    this.yorbitCourseList.forEach((element, key) => {
      if (obj.Skill === element.Skill) {
        if (element.SkillDataList.length === 1) {
          element.SkillDataList.forEach(ele => {
            if (ele.CourseList.length === 1) {
              this.yorbitCourseList.splice(key, 1);
            } else {
              ele.CourseList.forEach((el, k) => {
                if (el.CourseUniqueId === obj.CourseUniqueId) {
                  ele.CourseList.splice(k, 1);
                }
              });
            }
          });
        } else {
          element.SkillDataList.forEach((ele, ke) => {
            if (ele.Academy === obj.Academy && ele.Genre === obj.Genre) {
              if (ele.CourseList.length === 1) {
                element.SkillDataList.splice(ke, 1);
              } else {
                ele.CourseList.forEach((el, k) => {
                  if (ele.CourseUniqueId === obj.CourseUniqueId) {
                    ele.CourseList.splice(k, 1);
                  }
                });
              }
            }
          });
        }
      }
    });
  }
  removeSkill(index, skill, role) {
    this.showSaveAndCancelBtn = true;
    role.YorbitSkillList.splice(index, 1);
    let skillToAddFromNew;
    let courseToAddFromNew;
    this.yorbitCourseList.forEach(element => {
      if (element.Skill === skill.Skill) {
        skillToAddFromNew = element;
      }
    });
    if (skillToAddFromNew !== undefined) {
      skillToAddFromNew.SkillDataList.forEach(element => {
        if (
          element.Academy === skill.Academy &&
          element.Genre === skill.Genre
        ) {
          courseToAddFromNew = element;
        }
      });
    }
    if (skillToAddFromNew === undefined) {
      const wholeObj = {
        Skill: skill.Skill,
        SkillDataList: [
          {
            Academy: skill.Academy,
            Genre: skill.Genre,
            CourseList: [
              {
                CourseName: skill.CourseName,
                CourseUniqueId: skill.CourseUniqueId,
                Expertise: skill.Expertise,
                Academy: skill.Academy,
                Genre: skill.Genre
              }
            ]
          }
        ]
      };
      this.yorbitCourseList.push(wholeObj);
    } else {
      if (courseToAddFromNew === undefined) {
        const wholeObj = {
          Academy: skill.Academy,
          Genre: skill.Genre,
          CourseList: [
            {
              CourseName: skill.CourseName,
              CourseUniqueId: skill.CourseUniqueId,
              Expertise: skill.Expertise,
              Academy: skill.Academy,
              Genre: skill.Genre
            }
          ]
        };
        const found = this.yorbitCourseList.find(function(item) {
          return item.Skill === skill.Skill;
        });
        const pos = this.yorbitCourseList.indexOf(found);
        this.yorbitCourseList[pos].SkillDataList.push(wholeObj);
        // till here
      } else {
        //call to add partial object to skill list
        this.addPartialObjToSkillList(skill);
      }
    }
  }
  addPartialObjToSkillList(skill) {
    const partialObj = {
      CourseName: skill.CourseName,
      CourseUniqueId: skill.CourseUniqueId,
      Expertise: skill.Expertise,
      Academy: skill.Academy,
      Genre: skill.Genre
    };
    const found = this.yorbitCourseList.find(function(item) {
      return item.Skill === skill.Skill;
    });
    const index = this.yorbitCourseList.indexOf(found);
    const found2 = this.yorbitCourseList[index].SkillDataList.find(function(
      item
    ) {
      return item.Academy === skill.Academy && item.Genre === skill.Genre;
    });
    const index2 = this.yorbitCourseList[index].SkillDataList.indexOf(found2);
    if (index2 === -1) {
      const partialObjForSkill = {
        Academy: skill.Academy,
        Genre: skill.Genre,
        CourseList: [
          {
            CourseName: skill.CourseName,
            CourseUniqueId: skill.CourseUniqueId,
            Expertise: skill.Expertise,
            Academy: skill.Academy,
            Genre: skill.Genre
          }
        ]
      };
      this.yorbitCourseList[index].SkillDataList.push(partialObjForSkill);
    } else {
      this.yorbitCourseList[index].SkillDataList[index2].CourseList.push(
        partialObj
      );
    }
  }
  suggestedCourseSelected(course) {
    this.selectedAccountAndProjectCourse = course;
    this.selectedAccountAndProjectCourseName = course.CourseName;
  }
  addCourse(role) {
    if (this.selectedAccountAndProjectCourse !== undefined) {
      this.showSaveAndCancelBtn = true;
      role.ProjectCourseList.push(this.selectedAccountAndProjectCourse);
      const index = this.accountProjectCourseList
        .map(function(x) {
          return x.CourseUniqueId;
        })
        .indexOf(this.selectedAccountAndProjectCourse.CourseUniqueId);
      this.accountProjectCourseList.splice(index, 1);
      this.selectedAccountAndProjectCourseName = '';
      this.selectedAccountAndProjectCourse = undefined;
    }
  }
  removeAccountProjectCourse(pos, course, role) {
    this.showSaveAndCancelBtn = true;
    role.ProjectCourseList.splice(pos, 1);
    this.accountProjectCourseList.push(course);
  }
  suggestedMindSelected(mind) {
    //console.log(mind);
    this.selectedMindsForAdd = mind;
    this.selectedMindsNameForAdd = mind.MindName;
  }
  addMind(role) {
    if (this.selectedMindsForAdd !== undefined) {
      this.showSaveAndCancelBtn = true;
      role.MindsNameList.push(this.selectedMindsForAdd);
      role.MindsList.push(this.selectedMindsForAdd.MID);
      const index = this.listOfMindsToAdd
        .map(function(x) {
          return x.MID;
        })
        .indexOf(this.selectedMindsForAdd.MID);
      this.listOfMindsToAdd.splice(index, 1);
      this.selectedMindsNameForAdd = '';
      this.selectedMindsForAdd = undefined;
    }
  }
  removeMind(pos, mind, role) {
    this.showSaveAndCancelBtn = true;
    role.MindsList.splice(pos, 1);
    role.MindsNameList.splice(pos, 1);
    this.listOfMindsToAdd.push(mind);
  }
  skillSelectedForCreate(addedSkills) {
    this.addedSkillsForCreate = addedSkills;
  }
  courseSelectedForCreate(addedCourses) {
    this.addedCourseForCreate = addedCourses;
  }
  mindSelectedForCreate(addedMinds) {
    this.addedMindsForCreate = addedMinds;
  }
  cancel() {
    this.selectedExpertiseList = [];
    this.selectedCourseList = [];
    this.filteredSkillList = [];
    this.addedMindsList = [];
    this.panelOpenState = [];
    this.showActionItems = [];
    this.addedSkillsForCreate = [];
    this.addedCourseForCreate = [];
    this.addedMindsForCreate = [];
    this.saveButtonTitle = 'Save';
    this.disableCreateButton = true;
    this.showSaveAndCancelBtn = false;
    // get available project role
    this.getProjectRole();
    this.onfirstLoad();
  }
  saveProjectRole() {
    this.saveButtonTitle = 'Saving...';
    if (this.createProjectRoleClicked) {
      this.callApiToCreateProjectRole();
    } else {
      this.callApiToSaveProjectRole();
    }
  }
  callApiToCreateProjectRole() {
    const skillList = [];
    const courseList = [];
    const mindList = [];
    this.addedSkillsForCreate.forEach(element => {
      skillList.push(element.CourseUniqueId);
    });
    this.addedCourseForCreate.forEach(element => {
      courseList.push(element.CourseUniqueId);
    });
    this.addedMindsForCreate.forEach(element => {
      mindList.push(element.MID);
    });
    const todaysDate = new Date()
      .toISOString()
      .slice(0, 19)
      .replace('T', ' ');
    const obj = {
      Name: this.selectedProjectRole,
      ProjectRoleId: 0,
      ProjectId: this.selectedProject.ProjectId,
      AccountId: this.selectedAccount.AccountId,
      IsDeleted: false,
      CreatedDate: todaysDate,
      ModifiedDate: todaysDate,
      CreatedBy: this.logedInUserId,
      YorbitCourseList: skillList,
      AccountCourseList: courseList,
      TaggedMinds: mindList
    };
    // call api to create project role
    this.accountService.createProjectRole(obj).subscribe(res => {
      this.saveButtonTitle = 'Save';
      this.selectedProjectRole = '';
      this.createProjectRoleClicked = false;
      // get available project role
      this.getProjectRole();
      this.showSaveAndCancelBtn = false;
    });
  }
  callApiToSaveProjectRole() {
    let skillList = [];
    let courseList = [];
    let mindList = [];
    const index = this.availableProjectRoleList.indexOf(
      this.selectedProjectRoleForEdit
    );
    //for skill
    if (this.availableProjectRoleList[index].YorbitSkillList.length === 0) {
      skillList = [null];
    } else {
      const status = this.compareTwoArrays(
        false,
        this.oldSkillList,
        this.availableProjectRoleList[index].YorbitSkillList
      );
      if (status) {
        skillList = [];
      } else {
        this.availableProjectRoleList[index].YorbitSkillList.forEach(
          element => {
            skillList.push(element.CourseUniqueId);
          }
        );
      }
    }
    //for project course
    if (this.availableProjectRoleList[index].ProjectCourseList.length === 0) {
      courseList = [null];
    } else {
      const status = this.compareTwoArrays(
        false,
        this.oldCourseList,
        this.availableProjectRoleList[index].ProjectCourseList
      );
      if (status) {
        courseList = [];
      } else {
        this.availableProjectRoleList[index].ProjectCourseList.forEach(
          element => {
            courseList.push(element.CourseUniqueId);
          }
        );
      }
    }
    //for minds
    if (this.availableProjectRoleList[index].MindsNameList.length === 0) {
      mindList = [null];
    } else {
      const status = this.compareTwoArrays(
        true,
        this.oldMindList,
        this.availableProjectRoleList[index].MindsNameList
      );
      if (status) {
        mindList = [];
      } else {
        this.availableProjectRoleList[index].MindsNameList.forEach(element => {
          mindList.push(element.MID);
        });
      }
    }
    const todaysDate = new Date()
      .toISOString()
      .slice(0, 19)
      .replace('T', ' ');
    const obj = {
      Name: this.selectedProjectRoleForEdit.RoleName,
      ProjectRoleId: this.selectedProjectRoleForEdit.RoleId,
      ProjectId: this.selectedProject.ProjectId,
      AccountId: this.selectedAccount.AccountId,
      IsDeleted: false,
      CreatedDate: '',
      ModifiedDate: todaysDate,
      CreatedBy: this.logedInUserId,
      YorbitCourseList: skillList,
      AccountCourseList: courseList,
      TaggedMinds: mindList
    };
    // call api
    this.accountService.updateProjectRole(obj).subscribe(res => {
      this.saveButtonTitle = 'Save';
      // get available project role
      this.getProjectRole();
      this.showSaveAndCancelBtn = false;
      this.panelOpenState = [];
      this.selectedProjectRoleForEdit = undefined;
    });
  }
  compareTwoArrays(isMind, oldArray, newArray) {
    let objectsAreSame = true;
    if (oldArray.length !== newArray.length) {
      objectsAreSame = false;
    } else {
      if (isMind) {
        for (const MID in oldArray) {
          if (oldArray[MID] !== newArray[MID]) {
            objectsAreSame = false;
            break;
          }
        }
        return objectsAreSame;
      } else {
        for (const CourseUniqueId in oldArray) {
          if (oldArray[CourseUniqueId] !== newArray[CourseUniqueId]) {
            objectsAreSame = false;
            break;
          }
        }
        return objectsAreSame;
      }
    }
  }
}
