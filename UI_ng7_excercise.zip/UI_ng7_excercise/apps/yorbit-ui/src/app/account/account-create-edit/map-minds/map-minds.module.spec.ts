import { MapMindsModule } from './map-minds.module';

describe('MapMindsModule', () => {
  let mapMindsModule: MapMindsModule;

  beforeEach(() => {
    mapMindsModule = new MapMindsModule();
  });

  it('should create an instance', () => {
    expect(mapMindsModule).toBeTruthy();
  });
});
