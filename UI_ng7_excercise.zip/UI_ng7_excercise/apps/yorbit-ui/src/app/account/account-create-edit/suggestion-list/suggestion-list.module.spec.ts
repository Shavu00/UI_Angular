import { SuggestionListModule } from './suggestion-list.module';

describe('SuggestionListModule', () => {
  let suggestionListModule: SuggestionListModule;

  beforeEach(() => {
    suggestionListModule = new SuggestionListModule();
  });

  it('should create an instance', () => {
    expect(suggestionListModule).toBeTruthy();
  });
});
