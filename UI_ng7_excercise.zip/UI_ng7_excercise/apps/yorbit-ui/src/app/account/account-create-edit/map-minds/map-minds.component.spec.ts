import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MapMindsComponent } from './map-minds.component';

describe('MapMindsComponent', () => {
  let component: MapMindsComponent;
  let fixture: ComponentFixture<MapMindsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MapMindsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MapMindsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
