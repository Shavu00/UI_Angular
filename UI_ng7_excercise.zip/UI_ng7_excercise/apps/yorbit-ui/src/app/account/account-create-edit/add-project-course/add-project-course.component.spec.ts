import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddProjectCourseComponent } from './add-project-course.component';

describe('AddProjectCourseComponent', () => {
  let component: AddProjectCourseComponent;
  let fixture: ComponentFixture<AddProjectCourseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddProjectCourseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddProjectCourseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
