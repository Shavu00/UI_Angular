import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SuggestionListModule } from '../suggestion-list/suggestion-list.module';
import { AddProjectCourseComponent } from './add-project-course.component';
import { MatIconModule } from '@angular/material';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    FlexLayoutModule,
    MatIconModule,
    SuggestionListModule
  ],
  declarations: [AddProjectCourseComponent],
  exports: [AddProjectCourseComponent]
})
export class AddProjectCourseModule { }
