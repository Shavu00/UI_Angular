import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { AccountService } from '../../account.service';

@Component({
  selector: 'yorbit-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.scss']
})
export class AddCourseComponent implements OnInit {
  yorbitOldCourseList: any;
  yorbitCourseList: any;
  enteredSkillName: string;
  typingForSkillStarted: boolean;
  selectedExpertiseList: any;
  selectedCourseList: any;
  selectedExpertiseFromSkill: any;
  selectedCourseFromSkill: any;
  filteredSkillList: any;
  addedSkillList: any;
  selectedAcademy: string;
  selectedGenre: string;
  @Input('addedSkillsForCreate') addedSkillsForCreate;
  @Output() skillSelectedForCreate = new EventEmitter<any>();
  constructor(private accountService: AccountService) {
    this.yorbitOldCourseList = [];
    this.yorbitCourseList = [];
    this.selectedExpertiseList = [];
    this.selectedCourseList = [];
    this.filteredSkillList = [];
    this.addedSkillList = [];
  }

  ngOnInit() {
    //console.log('addedSkillsForCreate', this.addedSkillsForCreate);
    this.addedSkillList = this.addedSkillsForCreate;
    this.typingForSkillStarted = false;
    this.selectedExpertiseList = [{ Expertise: 'Select Expertise' }];
    this.selectedCourseList = [{ CourseName: 'Select Course' }];
    this.selectedExpertiseFromSkill = this.selectedExpertiseList[0];
    this.selectedCourseFromSkill = this.selectedCourseList[0];
    //get all yorbit course
    this.accountService.getYorbitCourseList().subscribe(course => {
      this.yorbitOldCourseList = course;
      this.yorbitCourseList = Object.assign([], this.yorbitOldCourseList);
      if (this.addedSkillList.length !== 0) {
        this.addedSkillList.forEach(element => {
          this.removeCourseFromMainList(element);
        });
      }
    });
  }
  filterSkillList(skill) {
    this.typingForSkillStarted = true;
    this.selectedExpertiseList = [{ Expertise: 'Select Expertise' }];
    this.selectedCourseList = [{ CourseName: 'Select Course' }];
    this.selectedExpertiseFromSkill = this.selectedExpertiseList[0];
    this.selectedCourseFromSkill = this.selectedCourseList[0];
  }
  closeSuggestionBox() {
    setTimeout(() => {
      this.typingForSkillStarted = false;
    }, 1000);
  }
  getExpertiseForSkill(course) {
    //console.log(course);
    this.selectedAcademy = course.acadGenre.Academy;
    this.selectedGenre = course.acadGenre.Genre;
    this.filteredSkillList = course.acadGenre;
    this.enteredSkillName = course.selectedSkill;
    this.selectedExpertiseList = [];
    course.acadGenre.CourseList.forEach(element => {
      const obj = { Expertise: element.Expertise };
      this.selectedExpertiseList.push(obj);
    });
    this.selectedExpertiseList = this.accountService.removeDuplicatesObject(
      this.selectedExpertiseList,
      'Expertise'
    );
    this.selectedExpertiseFromSkill = this.selectedExpertiseList[0];
    //call to update course list
    this.filterCourseByExpertise();
  }
  filterCourseByExpertise() {
    this.selectedCourseList = [];
    this.filteredSkillList.CourseList.forEach(element => {
      if (element.Expertise === this.selectedExpertiseFromSkill.Expertise) {
        const obj = {
          CourseName: element.CourseName,
          CourseUniqueId: element.CourseUniqueId
        };
        this.selectedCourseList.push(obj);
      }
    });
    this.selectedCourseFromSkill = this.selectedCourseList[0];
  }
  addSkill() {
    if (
      this.selectedExpertiseFromSkill.Expertise === 'Select Expertise' ||
      this.selectedCourseList.CourseName === 'Select Course'
    ) {
      // do not push anything
    } else {
      if (this.addedSkillList.length === 0) {
        const obj = {
          Academy: this.selectedAcademy,
          Genre: this.selectedGenre,
          Skill: this.enteredSkillName,
          Expertise: this.selectedExpertiseFromSkill.Expertise,
          CourseName: this.selectedCourseFromSkill.CourseName,
          CourseUniqueId: this.selectedCourseFromSkill.CourseUniqueId
        };
        this.addedSkillList.push(obj);
        //remove added course from course list
        this.removeCourseFromMainList(obj);
      } else {
        const isExist = this.checkForExistingSkill(this.addedSkillList);
        if (isExist) {
          //do not push anything
        } else {
          const obj = {
            Academy: this.selectedAcademy,
            Genre: this.selectedGenre,
            Skill: this.enteredSkillName,
            Expertise: this.selectedExpertiseFromSkill.Expertise,
            CourseName: this.selectedCourseFromSkill.CourseName,
            CourseUniqueId: this.selectedCourseFromSkill.CourseUniqueId
          };
          this.addedSkillList.push(obj);
          //remove added course from course list
          this.removeCourseFromMainList(obj);
        }
      }
      this.skillSelectedForCreate.emit(this.addedSkillList);
      this.enteredSkillName = '';
      this.selectedExpertiseList = [{ Expertise: 'Select Expertise' }];
      this.selectedCourseList = [{ CourseName: 'Select Course' }];
      this.selectedExpertiseFromSkill = this.selectedExpertiseList[0];
      this.selectedCourseFromSkill = this.selectedCourseList[0];
    }
  }
  checkForExistingSkill(array) {
    let status;
    for (let i = 0; i < array.length; i++) {
      if (
        array[i].Skill === this.enteredSkillName &&
        array[i].Expertise === this.selectedExpertiseFromSkill.Expertise &&
        array[i].CourseName === this.selectedCourseFromSkill.CourseName &&
        array[i].CourseUniqueId === this.selectedCourseFromSkill.CourseUniqueId
      ) {
        status = true;
        break;
      } else {
        status = false;
      }
    }
    return status;
  }
  removeCourseFromMainList(obj) {
    this.yorbitCourseList.forEach((element, key) => {
      if (obj.Skill === element.Skill) {
        if (element.SkillDataList.length === 1) {
          element.SkillDataList.forEach(ele => {
            if (ele.CourseList.length === 1) {
              this.yorbitCourseList.splice(key, 1);
            } else {
              ele.CourseList.forEach((el, k) => {
                if (el.CourseUniqueId === obj.CourseUniqueId) {
                  ele.CourseList.splice(k, 1);
                }
              });
            }
          });
        } else {
          element.SkillDataList.forEach((ele, ke) => {
            if (ele.Academy === obj.Academy && ele.Genre === obj.Genre) {
              if (ele.CourseList.length === 1) {
                element.SkillDataList.splice(ke, 1);
              } else {
                ele.CourseList.forEach((el, k) => {
                  if (ele.CourseUniqueId === obj.CourseUniqueId) {
                    ele.CourseList.splice(k, 1);
                  }
                });
              }
            }
          });
        }
      }
    });
  }
  removeSkill(index, skill) {
    this.addedSkillList.splice(index, 1);
    this.skillSelectedForCreate.emit(this.addedSkillList);
    let skillToAddFromNew;
    let courseToAddFromNew;
    this.yorbitCourseList.forEach(element => {
      if (element.Skill === skill.Skill) {
        skillToAddFromNew = element;
      }
    });
    if (skillToAddFromNew !== undefined) {
      skillToAddFromNew.SkillDataList.forEach(element => {
        if (
          element.Academy === skill.Academy &&
          element.Genre === skill.Genre
        ) {
          courseToAddFromNew = element;
        }
      });
    }
    if (skillToAddFromNew === undefined) {
      const wholeObj = {
        Skill: skill.Skill,
        SkillDataList: [
          {
            Academy: skill.Academy,
            Genre: skill.Genre,
            CourseList: [
              {
                CourseName: skill.CourseName,
                CourseUniqueId: skill.CourseUniqueId,
                Expertise: skill.Expertise,
                Academy: skill.Academy,
                Genre: skill.Genre
              }
            ]
          }
        ]
      };
      this.yorbitCourseList.push(wholeObj);
    } else {
      if (courseToAddFromNew === undefined) {
        const wholeObj = {
          Academy: skill.Academy,
          Genre: skill.Genre,
          CourseList: [
            {
              CourseName: skill.CourseName,
              CourseUniqueId: skill.CourseUniqueId,
              Expertise: skill.Expertise,
              Academy: skill.Academy,
              Genre: skill.Genre
            }
          ]
        };
        const found = this.yorbitCourseList.find(function(item) {
          return item.Skill === skill.Skill;
        });
        const pos = this.yorbitCourseList.indexOf(found);
        this.yorbitCourseList[pos].SkillDataList.push(wholeObj);
        // till here
      } else {
        //call to add partial object to skill list
        this.addPartialObjToSkillList(skill);
      }
    }
  }
  addPartialObjToSkillList(skill) {
    const partialObj = {
      CourseName: skill.CourseName,
      CourseUniqueId: skill.CourseUniqueId,
      Expertise: skill.Expertise,
      Academy: skill.Academy,
      Genre: skill.Genre
    };
    const found = this.yorbitCourseList.find(function(item) {
      return item.Skill === skill.Skill;
    });
    const index = this.yorbitCourseList.indexOf(found);
    const found2 = this.yorbitCourseList[index].SkillDataList.find(function(
      item
    ) {
      return item.Academy === skill.Academy && item.Genre === skill.Genre;
    });
    const index2 = this.yorbitCourseList[index].SkillDataList.indexOf(found2);
    if (index2 === -1) {
      const partialObjForSkill = {
        Academy: skill.Academy,
        Genre: skill.Genre,
        CourseList: [
          {
            CourseName: skill.CourseName,
            CourseUniqueId: skill.CourseUniqueId,
            Expertise: skill.Expertise,
            Academy: skill.Academy,
            Genre: skill.Genre
          }
        ]
      };
      this.yorbitCourseList[index].SkillDataList.push(partialObjForSkill);
    } else {
      this.yorbitCourseList[index].SkillDataList[index2].CourseList.push(
        partialObj
      );
    }
  }
}
