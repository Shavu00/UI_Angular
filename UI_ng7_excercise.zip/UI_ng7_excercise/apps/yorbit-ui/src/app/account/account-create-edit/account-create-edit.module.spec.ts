import { AccountCreateEditModule } from './account-create-edit.module';

describe('AccountCreateEditModule', () => {
  let accountCreateEditModule: AccountCreateEditModule;

  beforeEach(() => {
    accountCreateEditModule = new AccountCreateEditModule();
  });

  it('should create an instance', () => {
    expect(accountCreateEditModule).toBeTruthy();
  });
});
