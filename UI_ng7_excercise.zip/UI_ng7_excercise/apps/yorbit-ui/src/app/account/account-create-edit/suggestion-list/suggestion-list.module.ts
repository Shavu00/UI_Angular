import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SuggestionListComponent } from './suggestion-list.component';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule
  ],
  declarations: [SuggestionListComponent],
  exports: [SuggestionListComponent]
})
export class SuggestionListModule { }
