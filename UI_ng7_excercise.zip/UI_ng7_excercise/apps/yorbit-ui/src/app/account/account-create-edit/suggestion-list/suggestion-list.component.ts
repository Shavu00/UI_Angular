import {
  Component,
  OnInit,
  Input,
  OnChanges,
  Output,
  EventEmitter
} from '@angular/core';

@Component({
  selector: 'yorbit-suggestion-list',
  templateUrl: './suggestion-list.component.html',
  styleUrls: ['./suggestion-list.component.scss']
})
export class SuggestionListComponent implements OnInit, OnChanges {
  @Input() suggestionData;
  @Input() suggestionPlace;
  @Input() filter;
  @Input() type;
  @Output() skillFilterSelected = new EventEmitter<any>();
  @Output() courseFilterSelected = new EventEmitter<any>();
  @Output() mindFilterSelected = new EventEmitter<any>();
  filterdSkillList: any;
  filterdCourseList: any;
  filterdMindList: any;
  constructor() {
    this.filterdSkillList = [];
    this.filterdCourseList = [];
    this.filterdMindList = [];
  }
  ngOnChanges(changeObj) {
    if (changeObj['filter']) {
      if (this.type === 'skill') {
        if (this.filter !== undefined) {
          this.filterdSkillList = Object.assign([], this.suggestionData).filter(
            item =>
              item.Skill.toLowerCase().indexOf(this.filter.toLowerCase()) > -1
          );
        } else {
          this.filterdSkillList = Object.assign([], this.suggestionData);
        }
      } else if (this.type === 'course') {
        if (this.filter !== undefined) {
          this.filterdCourseList = Object.assign(
            [],
            this.suggestionData
          ).filter(
            item =>
              item.CourseName.toLowerCase().indexOf(this.filter.toLowerCase()) >
              -1
          );
        } else {
          this.filterdCourseList = Object.assign([], this.suggestionData);
        }
      } else if (this.type === 'mind') {
        if (this.filter !== undefined) {
          this.filterdMindList = Object.assign([], this.suggestionData).filter(
            item =>
              item.MindName.toLowerCase().indexOf(this.filter.toLowerCase()) >
              -1
          );
        } else {
          this.filterdMindList = Object.assign([], this.suggestionData);
        }
      }
    }
  }
  ngOnInit() {}
  skillSelected(skill, acadGenre) {
    const obj = {
      selectedSkill: skill,
      acadGenre: acadGenre
    };
    this.skillFilterSelected.emit(obj);
  }
  courseSelected(course) {
    this.courseFilterSelected.emit(course);
  }
  mindSelected(mind) {
    this.mindFilterSelected.emit(mind);
  }
}
