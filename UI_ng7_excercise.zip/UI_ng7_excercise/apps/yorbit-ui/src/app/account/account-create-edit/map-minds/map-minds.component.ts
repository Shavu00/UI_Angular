import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AccountService } from '../../account.service';

@Component({
  selector: 'yorbit-map-minds',
  templateUrl: './map-minds.component.html',
  styleUrls: ['./map-minds.component.scss']
})
export class MapMindsComponent implements OnInit {
  @Input('selectedAccount') selectedAccount;
  @Input('selectedProject') selectedProject;
  @Input('addedMindsForCreate') addedMindsForCreate;
  listOfMindsToAdd: any;
  selectedMindsNameForAdd: any;
  checkBoxForMinds: any;
  addedMindsList: any;
  @Output() mindSelectedForCreate = new EventEmitter<any>();
  constructor(private accountService: AccountService) {
    this.listOfMindsToAdd = [];
    this.checkBoxForMinds = [];
    this.addedMindsList = [];
  }

  ngOnInit() {
    //console.log('addedMindsForCreate', this.addedMindsForCreate);
    this.addedMindsList = this.addedMindsForCreate;
    this.selectedMindsNameForAdd = '';
    //get all account/project course
    this.accountService
      .getMindsListForAccountAndProject(
        this.selectedAccount.AccountId,
        this.selectedProject.ProjectId
      )
      .subscribe(minds => {
        this.listOfMindsToAdd = minds;
        if (this.addedMindsList.length !== 0) {
          this.addedMindsList.forEach(element => {
            this.checkBoxForMinds[element.MID] = true;
          });
        }
      });
  }
  addMind(mind, flag) {
    if (flag) {
      this.addedMindsList.push(mind);
    } else {
      const index = this.addedMindsList
        .map(function(x) {
          return x.MID;
        })
        .indexOf(mind.MID);
      this.addedMindsList.splice(index, 1);
    }
    this.mindSelectedForCreate.emit(this.addedMindsList);
  }
  removeMind(index, mind) {
    this.addedMindsList.splice(index, 1);
    this.checkBoxForMinds[mind.MID] = false;
    this.mindSelectedForCreate.emit(this.addedMindsList);
  }
}
