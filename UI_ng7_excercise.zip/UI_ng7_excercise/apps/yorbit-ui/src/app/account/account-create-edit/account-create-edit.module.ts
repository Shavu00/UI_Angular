import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AddCourseModule } from "./add-course/add-course.module";
import { AddProjectCourseModule } from "./add-project-course/add-project-course.module";
import { MapMindsModule } from "./map-minds/map-minds.module";
import { SuggestionListModule } from './suggestion-list/suggestion-list.module';
import { PipesModule } from '@YorbitWorkspace/pipes';
import { AccountCreateEditComponent } from './account-create-edit.component';
import { ReusableUiModule } from "@YorbitWorkspace/reusable-ui";
import { MatIconModule, MatExpansionModule } from '@angular/material';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    FlexLayoutModule,
    MatIconModule,
    MatExpansionModule,
    AddCourseModule,
    AddProjectCourseModule,
    MapMindsModule,
    SuggestionListModule,
    PipesModule,
    ReusableUiModule
  ],
  declarations: [AccountCreateEditComponent],
  exports: [AccountCreateEditComponent]
})
export class AccountCreateEditModule { }
