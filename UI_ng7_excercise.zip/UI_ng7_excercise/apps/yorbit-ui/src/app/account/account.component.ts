import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AccountService } from './account.service';
import { Subscriber } from 'rxjs';
import { HeaderService } from '../header/header.service';
import { AppInsightService } from '@YorbitWorkspace/app-insight';
import { AuthService } from '@YorbitWorkspace/auth';
@Component({
  selector: 'yorbit-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss']
})
export class AccountComponent implements OnInit, OnDestroy {
  showSkillPlan: boolean;
  selectedTabName: string;
  accountsAndProjectList: any;
  selectedAccount: any;
  selectedProject: any;
  availableProjectList: any;
  selectedProjectRole: any;
  isAdmin: boolean;
  hideAccountView: boolean;
  accountPageSubscriptions: any;
  constructor(
    private accountService: AccountService,
    private router: Router,
    private route: ActivatedRoute,
    private headerService: HeaderService,
    private _InsightService: AppInsightService,
    private authService: AuthService
  ) {
    this.accountsAndProjectList = [];
    this.isAdmin = false;
    this.hideAccountView = false;
    //this.getAccountAndProjectList();
    this.accountPageSubscriptions = {};
    // router.events.subscribe(val => {
    // });
  }

  ngOnInit() {
    this.getAccountAndProjectList();
  }
  getAccountAndProjectList() {
    this.showSkillPlan = true;
    this.activeTabs('dashboard');
    //get account and projects list
    this.accountsAndProjectList = this.headerService.getSavedAccountData();
    if (
      this.accountsAndProjectList === null ||
      this.accountsAndProjectList.length === 0
    ) {
      this.accountPageSubscriptions = this.accountService
        .getUsersAccountAndProjectList()
        .subscribe(list => {
          this.accountsAndProjectList = list;
          if (
            this.accountsAndProjectList != null &&
            this.accountsAndProjectList.length !== 0
          ) {
            this.accountsAndProjectList.sort(this.sortByAccountName);
            //console.log( "accounts and projects list after sort:", this.accountsAndProjectList );
            for (let i = 0; i < this.accountsAndProjectList.length; i++) {
              if (
                this.route.snapshot.params['id'] ===
                this.accountsAndProjectList[i].AccountId
              ) {
                this.selectedAccount = this.accountsAndProjectList[i];
                if (this.selectedAccount.AccountId === 'Mi_Footprints') {
                  this.hideAccountView = true;
                }
              }
            }
            //this.selectedAccount = this.accountsAndProjectList[0];
            //call to update project list
            this.accountSelected();
          } else {
            // $window.location.href = '/unauthorized.html';
          }
        });
    } else {
      for (let i = 0; i < this.accountsAndProjectList.length; i++) {
        if (
          this.route.snapshot.params['id'] ===
          this.accountsAndProjectList[i].AccountId
        ) {
          this.selectedAccount = this.accountsAndProjectList[i];
          if (this.selectedAccount.AccountId === 'Mi_Footprints') {
            this.hideAccountView = true;
          }
        }
      }
      //call to update project list
      this.accountSelected();
    }
  }
  sortByAccountName(a, b) {
    const nameA = a.AccountName.toLowerCase(),
      nameB = b.AccountName.toLowerCase();
    if (nameA < nameB)
      //sort string ascending
      return -1;
    if (nameA > nameB) return 1;
    return 0; //default return value (no sorting)
  }
  accountSelected() {
    //console.log('selected account:', this.selectedAccount);
    if (this.selectedAccount.AccountId === 'Mi_Footprints') {
      this.hideAccountView = true;
    } else {
      this.hideAccountView = false;
      this.activeTabs('dashboard');
      //empty the project list
      this.availableProjectList = [];
      if (
        this.selectedAccount.IsACM === 'ACM' &&
        this.selectedAccount.ProjectList.length !== 0
      ) {
        this.selectedAccount.ProjectList.sort(this.sortByProjectName);
        this.availableProjectList = this.selectedAccount.ProjectList;
        this.selectedProject = this.availableProjectList[0];
        this.isAdmin = true;
      } else if (
        this.selectedAccount.IsACM === 'ACM' &&
        this.selectedAccount.ProjectList.length === 0
      ) {
        this.selectedProject = 'NA';
        this.isAdmin = true;
      } else if (this.selectedAccount.IsACM === null) {
        if (this.selectedAccount.ProjectList.length === 0) {
          this.selectedProject = 'NA';
          this.isAdmin = false;
        } else {
          this.selectedAccount.ProjectList.sort(this.sortByProjectName);
          this.availableProjectList = this.selectedAccount.ProjectList;
          this.selectedProject = this.availableProjectList[0];
          if (this.selectedProject.IsPCMOrTM === null) {
            this.selectedProject = 'NA';
            this.isAdmin = false;
          } else {
            this.projectSelected();
          }
        }
      }
    }
    this.router.navigate(['account/', this.selectedAccount.AccountId]);
  }
  sortByProjectName(a, b) {
    const nameA = a.ProjectName.toLowerCase(),
      nameB = b.ProjectName.toLowerCase();
    if (nameA < nameB)
      //sort string ascending
      return -1;
    if (nameA > nameB) return 1;
    return 0; //default return value (no sorting)
  }
  projectSelected() {
    this.activeTabs('dashboard');
    if (
      this.selectedAccount.IsACM === 'ACM' ||
      this.selectedProject.IsPCMOrTM === 'PCM'
    ) {
      this.isAdmin = true;
    } else {
      this.isAdmin = false;
    }
    // $rootScope.dontChangeAnythingAfterCancelInAccountPage = false;
  }
  toggleSkillPlan() {
    if (this.showSkillPlan) {
      this.showSkillPlan = false;
    } else {
      this.activeTabs('dashboard');
      this.showSkillPlan = true;
    }
  }
  activeTabs(tabName) {
    this.selectedTabName = tabName;
  }
  goToOtherTab(data) {
    //console.log(data);
    this.selectedProjectRole = data.projectRole;
    this.activeTabs(data.tab);
  }
  showAccountDashboard() {
    this.selectedTabName = 'accountDashboard';
    this.showSkillPlan = false;
  }
  openMiFootprintLink() {
    this.authService.getUserInfo().subscribe(arg => {
      const insightPayload = {
        Action: 'Link Clicked',
        Mid: arg.userName,
        AccountName: this.selectedAccount.AccountName,
        AccountId: this.selectedAccount.AccountId
      };
      this._InsightService.trackEvent('Mi Footprints', insightPayload);
    });

    const url = 'https://mindtree.appzoojoo.be/mission?s=mifootprints';
    window.open(url, '_blank');
  }
  ngOnDestroy() {
    this.unsubscribeAllSubscriptions();
  }
  unsubscribeAllSubscriptions() {
    for (let subscriberKey in this.accountPageSubscriptions) {
      let subscriber = this.accountPageSubscriptions[subscriberKey];
      if (subscriber instanceof Subscriber) {
        subscriber.unsubscribe();
      }
    }
  }
}
