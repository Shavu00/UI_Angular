import {
  Component,
  OnInit,
  Input,
  OnChanges,
  Output,
  EventEmitter
} from '@angular/core';
import { GraphDataService } from '@YorbitWorkspace/graph';
import { AccountService } from '../account.service';

@Component({
  selector: 'yorbit-account-view-skill',
  templateUrl: './account-view-skill.component.html',
  styleUrls: ['./account-view-skill.component.scss']
})
export class AccountViewSkillComponent implements OnInit, OnChanges {
  @Input('selectedAccount') selectedAccount;
  @Input('selectedProject') selectedProject;
  @Input('passedProjectRole') passedProjectRole;
  @Output() routeFromViewSkill = new EventEmitter<any>();
  selectedProjectRole: any;
  projectRoleList: any;
  listOfExpectedExpertise: any;
  projectRoleDetails: any;
  skillStatusDetails: any;
  listOfMinds: any;
  listOfStatus: any;
  isPageLoading: boolean;
  constructor(
    private accountService: AccountService,
    private _graphSvc: GraphDataService
  ) {
    this.projectRoleList = [];
    this.isPageLoading = true;
    this.resetVariable();
  }

  resetVariable() {
    this.listOfExpectedExpertise = [];
    this.projectRoleDetails = [];
    this.skillStatusDetails = [];
    this.skillStatusDetails.push({
      Skill: 'Minds List',
      CourseName: ''
    });
    this.listOfMinds = [];
    this.listOfStatus = [];
  }
  ngOnChanges(changeObj) {
    if (changeObj['selectedAccount'] || changeObj['selectedProject']) {
      //this.getProjectRoleList();
    }
  }
  ngOnInit() {
    this.getProjectRoleList();
  }
  getProjectRoleList() {
    this.accountService
      .getRoles(this.selectedAccount.AccountId, this.selectedProject.ProjectId)
      .subscribe(roles => {
        this.projectRoleList = roles;
        if (this.passedProjectRole === undefined) {
          this.selectedProjectRole = this.projectRoleList[0];
        } else {
          this.projectRoleList.forEach((element, index) => {
            if (element.RoleId === this.passedProjectRole.RoleId) {
              this.selectedProjectRole = this.projectRoleList[index];
            }
          });
        }
        if (this.projectRoleList.length !== 0) {
          this.getRoleDetails();
          this.getProjectRoleDetailsStatus();
        }
      });
  }
  getRoleDetails() {
    this.accountService
      .getRoleDetails(this.selectedProjectRole.RoleId)
      .subscribe(details => {
        //console.log('skill role details', details);
        this.projectRoleDetails = details;
        //sort the skill list
        this.projectRoleDetails.YorbitSkillList.sort(function(a, b) {
          if (a.Skill < b.Skill) return -1;
          if (a.Skill > b.Skill) return 1;
          return 0;
        });
        //get the expected expertise
        this.projectRoleDetails.YorbitSkillList.forEach(element => {
          const obj = {
            Skill: element.Skill,
            Expertise: element.Expertise,
            CourseName: element.CourseName,
            CourseUniqueId: element.CourseUniqueId
          };
          this.listOfExpectedExpertise.push(obj);
        });
      });
  }
  getProjectRoleDetailsStatus() {
    this.accountService
      .getRoleDetailsStatus(this.selectedProjectRole.RoleId)
      .subscribe(status => {
        //console.log('skill status details', status);
        //console.log('listOfExpectedExpertise', this.listOfExpectedExpertise);
        this.listOfStatus = Object.assign([], status);
        this.listOfStatus.sort(function(a, b) {
          if (a.UserId < b.UserId) return -1;
          if (a.UserId > b.UserId) return 1;
          return 0;
        });
        this.listOfStatus.forEach(element => {
          // get name for each mid
          this._graphSvc.getUserName(element.UserId).subscribe(data => {
            element.UserName = data.value;
            this.listOfMinds.push(element);
            this.isPageLoading = false;
            this.listOfMinds = this.accountService.removeDuplicatesObject(
              this.listOfMinds,
              'UserId'
            );
            //sort the minds
            this.listOfMinds.sort(function(a, b) {
              if (a.UserId < b.UserId) return -1;
              if (a.UserId > b.UserId) return 1;
              return 0;
            });
            //sort the skill list
            element.SkillStatus.sort(function(a, b) {
              if (a.Skill < b.Skill) return -1;
              if (a.Skill > b.Skill) return 1;
              return 0;
            });
            //add expected expertise to status list
            element.SkillStatus.forEach(ele => {
              this.listOfExpectedExpertise.forEach(e => {
                if (ele.Skill === e.Skill) {
                  const obj = {
                    ActionStatus: ele.ActionStatus,
                    ActualExpertise: ele.ActualExpertise,
                    CourseName: e.CourseName,
                    CourseUniqueId: e.CourseUniqueId,
                    ExpectedExpertise: e.Expertise,
                    InLearningPath: ele.InLearningPath,
                    IsCompleted: ele.IsCompleted,
                    Skill: ele.Skill,
                    notActioned: ele.notActioned
                  };
                  this.skillStatusDetails.push(obj);
                }
              });
            });
            this.skillStatusDetails = this.accountService.removeDuplicatesObject(
              this.skillStatusDetails,
              'CourseUniqueId'
            );
            //console.log('skillStatusDetails', this.skillStatusDetails);
          });
        });
        //console.log('skillStatusDetails', this.skillStatusDetails);
        //console.log('skill status details', this.listOfStatus);
        this.listOfStatus.forEach(element => {
          this.updateColorAndSymbol(element.SkillStatus);
        });
        //this.updateColorAndSymbol(this.skillStatusDetails);
      });
  }
  updateColorAndSymbol(array) {
    array.forEach(ele => {
      if (
        ele.ActualExpertise < ele.ExpectedExpertise ||
        ((ele.ActionStatus === 'NOTASSIGNED' || ele.ActionStatus === '') &&
          !ele.InLearningPath)
      ) {
        ele.notActioned = true;
      } else {
        ele.notActioned = false;
      }
      if (ele.IsCompleted) {
        if (ele.ActualExpertise >= ele.ExpectedExpertise) {
          ele.expertiseColor = ele.ExpectedExpertise;
        } else {
          ele.expertiseColor = ele.ActualExpertise;
        }
      }
    });
  }
  roleSelected() {
    this.isPageLoading = true;
    this.resetVariable();
    this.getRoleDetails();
    this.getProjectRoleDetailsStatus();
  }
  goToCreateEditTab() {
    const obj = {
      tab: 'create',
      projectRole: ''
    };
    this.routeFromViewSkill.emit(obj);
  }
}
