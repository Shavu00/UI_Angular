import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AccountViewSkillComponent } from './account-view-skill.component';
import { ReusableUiModule } from "@YorbitWorkspace/reusable-ui";

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    FlexLayoutModule,
    ReusableUiModule
  ],
  declarations: [AccountViewSkillComponent],
  exports: [AccountViewSkillComponent]
})
export class AccountViewSkillModule { }
