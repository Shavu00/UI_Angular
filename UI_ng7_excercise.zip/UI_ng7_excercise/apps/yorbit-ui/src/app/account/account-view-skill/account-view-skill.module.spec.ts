import { AccountViewSkillModule } from './account-view-skill.module';

describe('AccountViewSkillModule', () => {
  let accountViewSkillModule: AccountViewSkillModule;

  beforeEach(() => {
    accountViewSkillModule = new AccountViewSkillModule();
  });

  it('should create an instance', () => {
    expect(accountViewSkillModule).toBeTruthy();
  });
});
