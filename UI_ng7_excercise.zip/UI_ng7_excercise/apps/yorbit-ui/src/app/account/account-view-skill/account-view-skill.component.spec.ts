import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountViewSkillComponent } from './account-view-skill.component';

describe('AccountViewSkillComponent', () => {
  let component: AccountViewSkillComponent;
  let fixture: ComponentFixture<AccountViewSkillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountViewSkillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountViewSkillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
