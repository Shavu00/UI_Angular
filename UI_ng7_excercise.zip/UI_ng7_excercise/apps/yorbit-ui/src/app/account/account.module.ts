import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatIconModule } from '@angular/material';
import { AccountComponent } from './account.component';
import { AccountRoutingModule } from './account.routing';
import { AccountDashboardModule } from './account-dashboard/account-dashboard.module';
import { AccountCreateEditModule } from './account-create-edit/account-create-edit.module';
import { AccountViewSkillModule } from './account-view-skill/account-view-skill.module';
import { AccountAssignCourseModule } from './account-assign-course/account-assign-course.module';
import { AccountPbiDashboardModule } from './account-pbi-dashboard/account-pbi-dashboard.module';
import { BrowseModule } from '../browse/browse.module';
@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    AccountRoutingModule,
    MatIconModule,
    FlexLayoutModule,
    AccountDashboardModule,
    AccountCreateEditModule,
    AccountViewSkillModule,
    AccountAssignCourseModule,
    AccountPbiDashboardModule,
    BrowseModule
  ],
  declarations: [AccountComponent]
})
export class AccountModule {}
