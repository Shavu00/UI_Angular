import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountAssignMindsPopupComponent } from './account-assign-minds-popup.component';

describe('AccountAssignMindsPopupComponent', () => {
  let component: AccountAssignMindsPopupComponent;
  let fixture: ComponentFixture<AccountAssignMindsPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountAssignMindsPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountAssignMindsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
