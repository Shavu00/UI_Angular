import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AccountGapMindsModule } from './account-gap-minds/account-gap-minds.module';
import { AccountNonGapMindsModule } from './account-non-gap-minds/account-non-gap-minds.module';
import { AccountAssignCourseComponent } from './account-assign-course.component';
import { ReusableUiModule } from '@YorbitWorkspace/reusable-ui';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    FlexLayoutModule,
    AccountGapMindsModule,
    AccountNonGapMindsModule,
    ReusableUiModule
  ],
  declarations: [AccountAssignCourseComponent],
  exports: [AccountAssignCourseComponent]
})
export class AccountAssignCourseModule {}
