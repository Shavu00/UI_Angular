import { AccountNonGapMindsModule } from './account-non-gap-minds.module';

describe('AccountNonGapMindsModule', () => {
  let accountNonGapMindsModule: AccountNonGapMindsModule;

  beforeEach(() => {
    accountNonGapMindsModule = new AccountNonGapMindsModule();
  });

  it('should create an instance', () => {
    expect(accountNonGapMindsModule).toBeTruthy();
  });
});
