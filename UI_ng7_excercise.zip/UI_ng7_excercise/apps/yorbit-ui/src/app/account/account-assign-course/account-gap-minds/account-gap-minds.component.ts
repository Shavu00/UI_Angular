import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { FormControl } from '@angular/forms';
import { AccountAssignMindsPopupComponent } from '../account-assign-minds-popup/account-assign-minds-popup.component';
import { Store } from '@ngrx/store';
import { AccountService } from '../../account.service';

@Component({
  selector: 'yorbit-account-gap-minds',
  templateUrl: './account-gap-minds.component.html',
  styleUrls: ['./account-gap-minds.component.scss']
})
export class AccountGapMindsComponent implements OnInit, OnChanges {
  @Input('selectedAccount') selectedAccount;
  @Input('selectedProject') selectedProject;
  @Input('selectedProjectRole') selectedProjectRole;
  mindList = new FormControl();
  skillList = new FormControl();
  courseList = new FormControl();
  listOfGapMindsCopy: any;
  listOfGapMinds: any;
  selectedSkillForAssign: any;
  selectedCourseForAssign: any;
  skillSelectAll: boolean;
  courseSelectAll: boolean;
  availableMindsList: any;
  availableSkillList: any;
  availableCourseList: any;
  selectedFilterMind: any;
  selectedFilterSkill: any;
  selectedFilterCourse: any;
  dropdownSettingsForMinds: Object;
  dropdownSettingsForSkills: Object;
  dropdownSettingsForCourses: Object;
  assignmentDataList: any;
  logedInUserId: string;
  listOfSelectedSkill: any;
  listOfSelectedCourse: any;
  assignBtnTitle: string;
  isPageLoading: boolean;
  constructor(
    private accountService: AccountService,
    private appStore: Store<any>,
    private _popup: MatDialog
  ) {
    this.listOfGapMindsCopy = [];
    this.listOfGapMinds = [];
    this.selectedSkillForAssign = [];
    this.selectedCourseForAssign = [];
    this.availableMindsList = [];
    this.availableSkillList = [];
    this.availableCourseList = [];
    this.resetAllVariable();
    this.dropdownSettingsForMinds = {
      singleSelection: false,
      idField: 'MID',
      textField: 'MindName',
      enableCheckAll: false,
      itemsShowLimit: 1,
      allowSearchFilter: true
    };
    this.dropdownSettingsForSkills = {
      singleSelection: false,
      idField: 'CourseUniqueId',
      textField: 'Skill',
      enableCheckAll: false,
      itemsShowLimit: 1,
      allowSearchFilter: true
    };
    this.dropdownSettingsForCourses = {
      singleSelection: false,
      idField: 'CourseUniqueId',
      textField: 'CourseName',
      enableCheckAll: false,
      itemsShowLimit: 1,
      allowSearchFilter: true
    };
    this.isPageLoading = true;
  }
  ngOnChanges(changeObj) {
    if (changeObj['selectedProjectRole']) {
      this.isPageLoading = true;
      this.appStore.select('userDetails').subscribe(userDetails => {
        if (userDetails.user.loaded) {
          this.logedInUserId = userDetails.user.data.id;
        }
      });
      this.getGapMindsDetails();
    }
  }
  getGapMindsDetails() {
    this.accountService
      .getGapMindDetails(this.selectedProjectRole.RoleId)
      .subscribe(gaps => {
        //console.log('list of gap minds', gaps);
        //clear the prev value
        this.availableMindsList = [];
        this.availableSkillList = [];
        this.availableCourseList = [];
        //
        this.listOfGapMindsCopy = gaps;
        this.isPageLoading = false;
        this.listOfGapMinds = Object.assign([], this.listOfGapMindsCopy);
        this.listOfGapMinds.forEach(element => {
          this.selectedSkillForAssign[element.MID] = [];
          this.selectedCourseForAssign[element.MID] = [];
          this.availableMindsList.push(element);
          element.YorbitSkillListCopy = [];
          element.ProjectCourseListCopy = [];
          this.updateSkillList(element);
          this.updateCourseList(element);
        });
      });
  }
  ngOnInit() {
    //this.getGapMindsDetails();
  }
  filterByMind() {
    //console.log(this.selectedFilterMind);
    this.skillSelectAll = false;
    this.courseSelectAll = false;
    this.selectedSkillForAssign = [];
    this.selectedCourseForAssign = [];
    // this.availableSkillList = [];
    // this.availableCourseList = [];
    // this.selectedFilterSkill = [];
    // this.selectedFilterCourse = [];
    // this.listOfGapMinds = [];
    // if (this.selectedFilterMind.length === 0) {
    //   this.listOfGapMinds = this.listOfGapMindsCopy;
    this.listOfGapMinds.forEach(element => {
      this.selectedSkillForAssign[element.MID] = [];
      this.selectedCourseForAssign[element.MID] = [];
      //this.availableMindsList.push(element);
      // element.YorbitSkillListCopy = [];
      // element.ProjectCourseListCopy = [];
      // this.checkToUpdateSkillFilter(element);
      // this.checkToUpdateCourseFilter(element);
    });
    // } else {
    //   this.configureFilterForMind();
    // }
  }
  configureFilterForMind() {
    this.listOfGapMindsCopy.forEach(element => {
      this.selectedSkillForAssign[element.MID] = [];
      this.selectedCourseForAssign[element.MID] = [];
      this.selectedFilterMind.forEach(ele => {
        if (element.MID === ele.MID) {
          this.listOfGapMinds.push(element);
          this.availableMindsList.push(element);
          element.YorbitSkillListCopy = [];
          element.ProjectCourseListCopy = [];
          this.checkToUpdateSkillFilter(element);
          this.checkToUpdateCourseFilter(element);
        }
      });
    });
  }
  checkToUpdateMindFilter(element) {
    if (this.selectedFilterMind.length === 0) {
      this.listOfGapMinds.push(element);
      this.availableMindsList.push(element);
    } else {
      this.selectedFilterMind.forEach(el => {
        if (el.MID === element.MID) {
          this.listOfGapMinds.push(element);
          this.availableMindsList.push(element);
        }
      });
    }
  }
  checkToUpdateSkillFilter(element) {
    if (this.selectedFilterSkill.length === 0) {
      this.updateSkillList(element);
    } else {
      this.selectedFilterSkill.forEach(el => {
        element.YorbitSkillList.forEach(e => {
          if (el.Skill === e.Skill) {
            element.YorbitSkillListCopy.push(e);
            this.availableSkillList.push(e);
          }
        });
      });
    }
  }
  checkToUpdateCourseFilter(element) {
    if (this.selectedFilterCourse.length === 0) {
      this.updateCourseList(element);
    } else {
      this.selectedFilterCourse.forEach(el => {
        element.ProjectCourseList.forEach(e => {
          if (el.CourseUniqueId === e.CourseUniqueId) {
            element.ProjectCourseListCopy.push(e);
            this.availableCourseList.push(e);
          }
        });
      });
    }
  }
  filterBySkill() {
    //console.log(this.selectedFilterSkill);
    this.skillSelectAll = false;
    this.courseSelectAll = false;
    this.selectedSkillForAssign = [];
    this.selectedCourseForAssign = [];
    // this.availableMindsList = [];
    // this.availableCourseList = [];
    // this.selectedFilterMind = [];
    // this.selectedFilterCourse = [];
    // this.listOfGapMinds = [];
    // if (this.selectedFilterSkill.length === 0) {
    //this.listOfGapMinds = this.listOfGapMindsCopy;
    this.listOfGapMindsCopy.forEach(element => {
      this.selectedSkillForAssign[element.MID] = [];
      this.selectedCourseForAssign[element.MID] = [];
      // this.checkToUpdateMindFilter(element);
      // element.YorbitSkillListCopy = [];
      // element.ProjectCourseListCopy = [];
      // this.updateSkillList(element);
      // this.checkToUpdateCourseFilter(element);
    });
    // } else {
    //   this.configureFilterForSkill();
    // }
  }
  configureFilterForSkill() {
    this.listOfGapMindsCopy.forEach(element => {
      this.selectedSkillForAssign[element.MID] = [];
      this.selectedCourseForAssign[element.MID] = [];
      element.YorbitSkillListCopy = [];
      element.ProjectCourseListCopy = [];
      this.selectedFilterSkill.forEach(ele => {
        element.YorbitSkillList.forEach(e => {
          if (ele.Skill === e.Skill) {
            element.YorbitSkillListCopy.push(e);
            this.availableSkillList.push(e);
            this.checkToUpdateMindFilter(element);
            this.checkToUpdateCourseFilter(element);
          }
        });
      });
    });
  }
  filterByCourse() {
    //console.log(this.selectedFilterCourse);
    this.skillSelectAll = false;
    this.courseSelectAll = false;
    this.selectedSkillForAssign = [];
    this.selectedCourseForAssign = [];
    // this.availableMindsList = [];
    // this.availableSkillList = [];
    // this.selectedFilterMind = [];
    // this.selectedFilterSkill = [];
    // this.listOfGapMinds = [];
    // if (this.selectedFilterCourse.length === 0) {
    //this.listOfGapMinds = this.listOfGapMindsCopy;
    this.listOfGapMindsCopy.forEach(element => {
      this.selectedSkillForAssign[element.MID] = [];
      this.selectedCourseForAssign[element.MID] = [];
      // this.checkToUpdateMindFilter(element);
      // element.YorbitSkillListCopy = [];
      // element.ProjectCourseListCopy = [];
      // this.checkToUpdateSkillFilter(element);
      // this.updateCourseList(element);
    });
    // } else {
    //   this.configureFilterForCourse();
    // }
  }
  configureFilterForCourse() {
    this.listOfGapMindsCopy.forEach(element => {
      this.selectedSkillForAssign[element.MID] = [];
      this.selectedCourseForAssign[element.MID] = [];
      element.YorbitSkillListCopy = [];
      element.ProjectCourseListCopy = [];
      this.selectedFilterCourse.forEach(ele => {
        element.ProjectCourseList.forEach(e => {
          if (ele.CourseUniqueId === e.CourseUniqueId) {
            element.ProjectCourseListCopy.push(e);
            this.availableCourseList.push(e);
            this.checkToUpdateMindFilter(element);
            this.checkToUpdateSkillFilter(element);
          }
        });
      });
    });
  }
  updateSkillList(array) {
    array.YorbitSkillList.forEach(e => {
      this.availableSkillList.push(e);
      array.YorbitSkillListCopy.push(e);
      this.availableSkillList = this.accountService.removeDuplicatesObject(
        this.availableSkillList,
        'Skill'
      );
    });
  }
  updateCourseList(array) {
    array.ProjectCourseList.forEach(e => {
      array.ProjectCourseListCopy.push(e);
      this.availableCourseList.push(e);
      this.availableCourseList = this.accountService.removeDuplicatesObject(
        this.availableCourseList,
        'CourseUniqueId'
      );
    });
  }
  selectSkillForAssign(minds, skill, flag) {
    //console.log('selected skill for filter', minds, skill, flag);
    this.skillSelectAll = false;
    if (flag) {
      const obj = {
        UserIds: [minds.MID],
        itemId: skill.CourseId,
        itemType: 'Course',
        itemName: skill.CourseName,
        itemExpertise: skill.Expertise,
        duration: '00.00.00',
        dueDate: '',
        CDMIntentOfAssigning: '',
        IsAssigneeOnBench: false,
        IsAssigned: false
      };
      this.listOfSelectedSkill.push(obj);
      let data;
      if (this.listOfSelectedSkill.length !== 0) {
        data = this.configureData(minds);
      }
      if (this.assignmentDataList.length !== 0) {
        const found = this.assignmentDataList.find(item => {
          return item.LearnerId === minds.MID;
        });
        if (found !== undefined) {
          const index = this.assignmentDataList.indexOf(found);
          this.assignmentDataList[index].YorbitCourseList = [];
          this.listOfSelectedSkill.forEach(element => {
            if (element.UserIds[0] === minds.MID) {
              this.assignmentDataList[index].YorbitCourseList.push(element);
            }
          });
        } else {
          const courseData = this.configureData(minds);
          this.assignmentDataList.push(courseData);
          //console.log('this.assignmentDataList', this.assignmentDataList);
        }
      } else {
        this.assignmentDataList.push(data);
      }
    } else {
      // const found = this.listOfSelectedSkill.find(function(item) {
      //   return item.UserIds[0] === minds.MID && item.itemId === skill.CourseId;
      // });
      // const index = this.listOfSelectedSkill.indexOf(found);
      // this.listOfSelectedSkill.splice(index, 1);
      const found = this.assignmentDataList.find(item => {
        return item.LearnerId === minds.MID;
      });
      const index = this.assignmentDataList.indexOf(found);
      if (found !== undefined) {
        const found2 = found.YorbitCourseList.find(item => {
          return item.itemId === skill.CourseId;
        });
        const index2 = found.YorbitCourseList.indexOf(found2);
        this.assignmentDataList[index].YorbitCourseList.splice(index2, 1);
      }
    }
    //remove entry for empty project and course list
    this.assignmentDataList.forEach((value, key) => {
      if (
        value.ProjectCourseList.length === 0 &&
        value.YorbitCourseList.length === 0
      ) {
        this.assignmentDataList.splice(key, 1);
      }
    });
  }
  selectCourseForAssign(minds, course, flag) {
    //console.log('selected course for filter', minds, course, flag);
    this.courseSelectAll = false;
    let isAccount;
    let projectId;
    let projectName;
    if (course.IsAccountOrProjectCourse === 'Account') {
      isAccount = true;
      projectId = '';
      projectName = '';
    } else {
      isAccount = false;
      projectId = this.selectedProject.ProjectId;
      projectName = this.selectedProject.ProjectName;
    }
    if (flag) {
      const obj = {
        UserIds: [minds.MID],
        itemId: course.CourseUniqueId,
        itemType: 'Course',
        itemName: course.CourseName,
        itemExpertise: '101',
        duration: '00.00.00',
        accountId: this.selectedAccount.AccountId,
        accountName: this.selectedAccount.AccountName,
        projectId: projectId,
        projectName: projectName,
        isAccount: isAccount,
        dueDate: '',
        IsAssigned: false
      };
      this.listOfSelectedCourse.push(obj);
      let data;
      if (this.listOfSelectedCourse.length !== 0) {
        data = this.configureData(minds);
      }
      if (this.assignmentDataList.length !== 0) {
        const found = this.assignmentDataList.find(item => {
          return item.LearnerId === minds.MID;
        });
        if (found !== undefined) {
          const index = this.assignmentDataList.indexOf(found);
          this.assignmentDataList[index].ProjectCourseList = [];
          this.listOfSelectedCourse.forEach(element => {
            if (element.UserIds[0] === minds.MID) {
              this.assignmentDataList[index].ProjectCourseList.push(element);
            }
          });
        } else {
          const courseData = this.configureData(minds);
          this.assignmentDataList.push(courseData);
        }
      } else {
        this.assignmentDataList.push(data);
      }
    } else {
      // const found = this.listOfSelectedCourse.find(function(item) {
      //   return (
      //     item.UserIds[0] === minds.MID && item.itemId === course.CourseUniqueId
      //   );
      // });
      // const index = this.listOfSelectedCourse.indexOf(found);
      // this.listOfSelectedCourse.splice(index, 1);
      const found = this.assignmentDataList.find(item => {
        return item.LearnerId === minds.MID;
      });
      const index = this.assignmentDataList.indexOf(found);
      if (found !== undefined) {
        const found2 = found.ProjectCourseList.find(item => {
          return item.itemId === course.CourseUniqueId;
        });
        const index2 = found.ProjectCourseList.indexOf(found2);
        this.assignmentDataList[index].ProjectCourseList.splice(index2, 1);
      }
    }
    //remove entry for empty project and course list
    this.assignmentDataList.forEach((value, key) => {
      if (
        value.ProjectCourseList.length === 0 &&
        value.YorbitCourseList.length === 0
      ) {
        this.assignmentDataList.splice(key, 1);
      }
    });
  }
  configureData(minds) {
    let data = {};
    const skillArray = [];
    const courseArray = [];
    this.listOfSelectedSkill.forEach(value => {
      if (value.UserIds[0] === minds.MID) {
        skillArray.push(value);
      }
    });
    this.listOfSelectedCourse.forEach(value => {
      if (value.UserIds[0] === minds.MID) {
        courseArray.push(value);
      }
    });
    data = {
      LearnerId: minds.MID,
      YorbitCourseList: skillArray,
      ProjectCourseList: courseArray
    };
    return data;
  }
  skillSelectAllFunction(checked) {
    //this.assignmentDataList = [];
    this.listOfGapMinds.forEach(element => {
      this.listOfSelectedSkill = [];
      element.YorbitSkillList.forEach(ele => {
        if (checked) {
          this.selectedSkillForAssign[element.MID][ele.CourseUniqueId] = true;
          const obj = {
            UserIds: [element.MID],
            itemId: ele.CourseId,
            itemType: 'Course',
            itemName: ele.CourseName,
            itemExpertise: ele.Expertise,
            duration: '00.00.00',
            dueDate: '',
            CDMIntentOfAssigning: '',
            IsAssigneeOnBench: false,
            IsAssigned: false
          };
          this.listOfSelectedSkill.push(obj);
        } else {
          let count = 0;
          this.assignmentDataList.forEach(el => {
            if (el.ProjectCourseList.length !== 0) {
              count++;
            }
            el.YorbitCourseList = [];
          });
          if (count === 0) {
            this.assignmentDataList = [];
          }
          this.selectedSkillForAssign[element.MID][ele.CourseUniqueId] = false;
        }
      });
      if (this.listOfSelectedSkill.length !== 0) {
        if (this.assignmentDataList.length !== 0) {
          this.assignmentDataList.forEach(ele => {
            if (element.MID === ele.LearnerId) {
              ele.YorbitCourseList = this.listOfSelectedSkill;
            } else {
              const data = {
                LearnerId: element.MID,
                YorbitCourseList: Object.assign([], this.listOfSelectedSkill),
                ProjectCourseList: Object.assign([], this.listOfSelectedCourse)
              };
              this.assignmentDataList.push(data);
            }
          });
        } else {
          const data = {
            LearnerId: element.MID,
            YorbitCourseList: Object.assign([], this.listOfSelectedSkill),
            ProjectCourseList: Object.assign([], this.listOfSelectedCourse)
          };
          this.assignmentDataList.push(data);
        }
      }
      this.assignmentDataList = this.accountService.removeDuplicatesObject(
        this.assignmentDataList,
        'LearnerId'
      );
      // console.log(
      //   'assignment data after skill select all',
      //   this.assignmentDataList
      // );
    });
  }
  courseSelectAllFunction(checked) {
    //this.assignmentDataList = [];
    this.listOfGapMinds.forEach(element => {
      this.listOfSelectedCourse = [];
      element.ProjectCourseList.forEach(ele => {
        if (checked) {
          let isAccount;
          let projectId;
          let projectName;
          if (ele.IsAccountOrProjectCourse === 'Account') {
            isAccount = true;
            projectId = '';
            projectName = '';
          } else {
            isAccount = false;
            projectId = this.selectedProject.ProjectId;
            projectName = this.selectedProject.ProjectName;
          }
          this.selectedCourseForAssign[element.MID][ele.CourseUniqueId] = true;
          const obj = {
            UserIds: [element.MID],
            itemId: ele.CourseUniqueId,
            itemType: 'Course',
            itemName: ele.CourseName,
            itemExpertise: '101',
            duration: '00.00.00',
            accountId: this.selectedAccount.AccountId,
            accountName: this.selectedAccount.AccountName,
            projectId: projectId,
            projectName: projectName,
            isAccount: isAccount,
            dueDate: '',
            IsAssigned: false
          };
          this.listOfSelectedCourse.push(obj);
        } else {
          let count = 0;
          this.assignmentDataList.forEach(el => {
            if (el.YorbitCourseList.length !== 0) {
              count++;
            }
            el.ProjectCourseList = [];
          });
          if (count === 0) {
            this.assignmentDataList = [];
          }
          this.selectedCourseForAssign[element.MID][ele.CourseUniqueId] = false;
        }
      });
      if (this.listOfSelectedCourse.length !== 0) {
        if (this.assignmentDataList.length !== 0) {
          this.assignmentDataList.forEach(ele => {
            if (element.MID === ele.LearnerId) {
              ele.ProjectCourseList = this.listOfSelectedCourse;
            } else {
              const data = {
                LearnerId: element.MID,
                YorbitCourseList: Object.assign([], this.listOfSelectedSkill),
                ProjectCourseList: Object.assign([], this.listOfSelectedCourse)
              };
              this.assignmentDataList.push(data);
            }
          });
        } else {
          const data = {
            LearnerId: element.MID,
            YorbitCourseList: Object.assign([], this.listOfSelectedSkill),
            ProjectCourseList: Object.assign([], this.listOfSelectedCourse)
          };
          this.assignmentDataList.push(data);
        }
      }
      this.assignmentDataList = this.accountService.removeDuplicatesObject(
        this.assignmentDataList,
        'LearnerId'
      );
      // console.log(
      //   'assignment data after course select all',
      //   this.assignmentDataList
      // );
    });
  }
  resetAllVariable() {
    this.assignBtnTitle = 'Assign';
    this.skillSelectAll = false;
    this.courseSelectAll = false;
    this.selectedFilterMind = [];
    this.selectedFilterSkill = [];
    this.selectedFilterCourse = [];
    this.assignmentDataList = [];
    this.listOfSelectedSkill = [];
    this.listOfSelectedCourse = [];
    this.listOfGapMinds = this.listOfGapMindsCopy;
    this.listOfGapMinds.forEach(element => {
      element.YorbitSkillList.forEach(ele => {
        this.selectedSkillForAssign[element.MID][ele.CourseUniqueId] = false;
      });
      element.ProjectCourseList.forEach(ele => {
        this.selectedCourseForAssign[element.MID][ele.CourseUniqueId] = false;
      });
    });
  }
  assignMinds() {
    if (
      this.assignmentDataList.length !== 0 ||
      this.skillSelectAll ||
      this.courseSelectAll
    ) {
      this.assignBtnTitle = 'Assigning...';
      let role;
      if (this.selectedAccount.IsACM === 'ACM') {
        role = 'ACM';
      } else {
        role = 'PCM';
      }
      const data = {
        AssignerId: this.logedInUserId,
        Role: role,
        AssignmentDataList: Object.assign([], this.assignmentDataList)
      };
      //console.log('payload for assignment', data);
      this.openpopup(
        'Status',
        'Assignment process has began and status will be notified by the email.'
      );
      this.assignBtnTitle = 'Assigned';
      this.accountService.assignToMindForFirstTab(data).subscribe(res => {
        //console.log('response after assignment from first tab', res);
        this.resetAllVariable();
        this.getGapMindsDetails();
      });
    } else {
      this.openpopup(
        'Message',
        'Please select atleast one skill or project course that needs to assigned !'
      );
    }
  }
  openpopup(status, data) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.panelClass = 'popupDialogContainer';
    dialogConfig.data = {
      status: status,
      data: data
    };
    const response = this._popup.open(
      AccountAssignMindsPopupComponent,
      dialogConfig
    );
    response.afterClosed().subscribe(res => {
      //do something after pop up close
    });
  }
}
