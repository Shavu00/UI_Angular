import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountAssignCourseComponent } from './account-assign-course.component';

describe('AccountAssignCourseComponent', () => {
  let component: AccountAssignCourseComponent;
  let fixture: ComponentFixture<AccountAssignCourseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountAssignCourseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountAssignCourseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
