import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { GraphDataService } from '@YorbitWorkspace/graph';
import { AccountAssignMindsPopupComponent } from '../account-assign-minds-popup/account-assign-minds-popup.component';
import { AccountService } from '../../account.service';

@Component({
  selector: 'yorbit-account-non-gap-minds',
  templateUrl: './account-non-gap-minds.component.html',
  styleUrls: ['./account-non-gap-minds.component.scss']
})
export class AccountNonGapMindsComponent implements OnInit, OnChanges {
  @Input('selectedAccount') selectedAccount;
  @Input('selectedProject') selectedProject;
  @Input('selectedProjectRole') selectedProjectRole;
  listOfNonGapMindsCopy: any;
  listOfNonGapMinds: any;
  //selectedTakenCourseForAssign: any;
  selectedMappedCourseForAssign: any;
  // takenCourseSelectAll: boolean;
  // mappedCourseSelectAll: boolean;
  availableMindsList: any;
  availableTakenCourseList: any;
  availableMappedCourseList: any;
  selectedFilterMind: any;
  selectedFilterTakenCourse: any;
  selectedFilterMappedCourse: any;
  assignButtonTitle: any;
  dropdownSettingsForMinds: Object;
  dropdownSettingsForTakenCourse: Object;
  dropdownSettingsForMappedCourse: Object;
  dataForAssignment: any;
  isPageLoading: boolean;
  constructor(
    private accountService: AccountService,
    private _graphSvc: GraphDataService,
    private _popup: MatDialog
  ) {
    this.listOfNonGapMindsCopy = [];
    this.listOfNonGapMinds = [];
    // this.takenCourseSelectAll = false;
    // this.mappedCourseSelectAll = false;
    //this.selectedTakenCourseForAssign = [];
    this.selectedMappedCourseForAssign = [];
    this.availableMindsList = [];
    this.availableTakenCourseList = [];
    this.availableMappedCourseList = [];
    this.selectedFilterMind = [];
    this.selectedFilterTakenCourse = [];
    this.selectedFilterMappedCourse = [];
    this.assignButtonTitle = [];
    this.dropdownSettingsForMinds = {
      singleSelection: false,
      idField: 'MID',
      textField: 'MindName',
      enableCheckAll: false,
      itemsShowLimit: 1,
      allowSearchFilter: true
    };
    this.dropdownSettingsForTakenCourse = {
      singleSelection: false,
      idField: 'CourseUniqueId',
      textField: 'CourseName',
      enableCheckAll: false,
      itemsShowLimit: 1,
      allowSearchFilter: true
    };
    this.dropdownSettingsForMappedCourse = {
      singleSelection: false,
      idField: 'CourseUniqueId',
      textField: 'CourseName',
      enableCheckAll: false,
      itemsShowLimit: 1,
      allowSearchFilter: true
    };
    this.isPageLoading = true;
  }
  ngOnChanges(changeObj) {
    if (changeObj['selectedProjectRole']) {
      this.isPageLoading = true;
      this.getNonGapMindsDetails();
    }
  }
  getNonGapMindsDetails() {
    this.accountService
      .getNonGapMindDetails(this.selectedProjectRole.RoleId)
      .subscribe(nongaps => {
        //clear the old value
        this.availableMindsList = [];
        this.availableTakenCourseList = [];
        this.availableMappedCourseList = [];
        //
        this.listOfNonGapMindsCopy = nongaps;
        this.isPageLoading = false;;
        this.listOfNonGapMinds = Object.assign([], this.listOfNonGapMindsCopy);
        this.listOfNonGapMinds.forEach(element => {
          this.assignButtonTitle[element.MID] = [];
          this.selectedMappedCourseForAssign[element.MID] = [];
          // get name for each mid
          this._graphSvc.getUserName(element.MID).subscribe(
            data => {
              element.MindName = data.value;
              this.availableMindsList.push(element);
              this.availableMindsList = this.accountService.removeDuplicatesObject(
                this.availableMindsList,
                'MID'
              );
            },
            error => {
              element.MindName = element.MID;
              this.availableMindsList.push(element);
              this.availableMindsList = this.accountService.removeDuplicatesObject(
                this.availableMindsList,
                'MID'
              );
            }
          );
          if (element.CourseVariantList.length !== 0) {
            element.mappedCourseList = [];
            element.takenCourseList = [];
            element.CourseVariantList.forEach(ele => {
              const takenCourse = {
                CourseUniqueId: ele.TakenCourseId,
                CourseName: ele.TakenCourseName,
                Skill: ele.Skill,
                Expertise: ele.TakenCourseExpertise,
                TakenCourseStatus: ele.CourseProgressStatus
              };
              this.availableTakenCourseList.push(takenCourse);
              this.availableTakenCourseList = this.accountService.removeDuplicatesObject(
                this.availableTakenCourseList,
                'CourseUniqueId'
              );
              element.takenCourseList.push(takenCourse);
              element.takenCourseList = this.accountService.removeDuplicatesObject(
                element.takenCourseList,
                'CourseUniqueId'
              );
              const mappedCourse = {
                Skill: ele.Skill,
                Expertise: ele.MappedCourseExpertise,
                CourseUniqueId: ele.MappedCourseUId,
                CourseId: ele.MappedCourseId,
                CourseName: ele.MappedCourseName,
                isDisabled: false
              };
              element.mappedCourseList.push(mappedCourse);
              element.mappedCourseList = this.accountService.removeDuplicatesObject(
                element.mappedCourseList,
                'CourseUniqueId'
              );
              this.availableMappedCourseList.push(mappedCourse);
              this.availableMappedCourseList = this.accountService.removeDuplicatesObject(
                this.availableMappedCourseList,
                'CourseUniqueId'
              );
              this.assignButtonTitle[element.MID][ele.MappedCourseId] =
                'Assign';
            });
          }
        });
        //console.log('non gap minds', this.listOfNonGapMinds);
      });
  }
  ngOnInit() {
    //this.getNonGapMindsDetails();
  }
  filterByMind() {
    //console.log(this.selectedFilterMind);
    //this.selectedTakenCourseForAssign = [];
    this.selectedMappedCourseForAssign = [];
    // this.availableTakenCourseList = [];
    // this.availableMappedCourseList = [];
    // this.selectedFilterTakenCourse = [];
    // this.selectedFilterMappedCourse = [];
    // this.listOfNonGapMinds = [];
    // if (this.selectedFilterMind.length === 0) {
    //   this.listOfNonGapMinds = this.listOfNonGapMindsCopy;
      this.listOfNonGapMinds.forEach(element => {
        //this.selectedTakenCourseForAssign[element.MID] = [];
        this.selectedMappedCourseForAssign[element.MID] = [];
        // this.availableMindsList.push(element);
        // element.takenCourseList.forEach(e => {
        //   this.availableTakenCourseList.push(e);
        //   this.availableTakenCourseList = this.accountService.removeDuplicatesObject(
        //     this.availableTakenCourseList,
        //     'TakenCourseId'
        //   );
        // });
      });
    // } else {
    //   this.listOfNonGapMindsCopy.forEach(element => {
    //     //this.selectedTakenCourseForAssign[element.MID] = [];
    //     this.selectedMappedCourseForAssign[element.MID] = [];
    //     this.selectedFilterMind.forEach(ele => {
    //       if (element.MID === ele.MID) {
    //         this.listOfNonGapMinds.push(element);
    //         this.availableMindsList.push(element);
    //         element.takenCourseList.forEach(e => {
    //           this.availableTakenCourseList.push(e);
    //           this.availableTakenCourseList = this.accountService.removeDuplicatesObject(
    //             this.availableTakenCourseList,
    //             'TakenCourseId'
    //           );
    //         });
    //         element.mappedCourseList.forEach(e => {
    //           this.availableMappedCourseList.push(e);
    //           this.availableMappedCourseList = this.accountService.removeDuplicatesObject(
    //             this.availableMappedCourseList,
    //             'MappedCourseUId'
    //           );
    //         });
    //       }
    //     });
    //   });
    // }
  }
  filterByTakenCourse() {
    //console.log(this.selectedFilterTakenCourse);
    //this.selectedTakenCourseForAssign = [];
    this.selectedMappedCourseForAssign = [];
    // this.availableMindsList = [];
    // this.availableMappedCourseList = [];
    // this.selectedFilterMind = [];
    // this.selectedFilterMappedCourse = [];
    // this.listOfNonGapMinds = [];
    // if (this.selectedFilterTakenCourse.length === 0) {
    //   this.listOfNonGapMinds = this.listOfNonGapMindsCopy;
      this.listOfNonGapMinds.forEach(element => {
        // this.selectedTakenCourseForAssign[element.MID] = [];
        this.selectedMappedCourseForAssign[element.MID] = [];
        // this.availableMindsList.push(element);
        // element.mappedCourseList.forEach(e => {
        //   this.availableMappedCourseList.push(e);
        //   this.availableMappedCourseList = this.accountService.removeDuplicatesObject(
        //     this.availableMappedCourseList,
        //     'MappedCourseUId'
        //   );
        // });
      });
    // } else {
    //   this.listOfNonGapMindsCopy.forEach(element => {
    //     //this.selectedTakenCourseForAssign[element.MID] = [];
    //     this.selectedMappedCourseForAssign[element.MID] = [];
    //     const takenCourseList = [];
    //     this.selectedFilterTakenCourse.forEach(ele => {
    //       element.takenCourseList.forEach(e => {
    //         if (e.Skill === ele.Skill) {
    //           takenCourseList.push(e);
    //           const obj = {
    //             MID: element.MID,
    //             MindName: element.MindName,
    //             mappedCourseList: element.mappedCourseList,
    //             takenCourseList: takenCourseList
    //           };
    //           this.listOfNonGapMinds.push(obj);
    //           this.listOfNonGapMinds = this.accountService.removeDuplicatesObject(
    //             this.listOfNonGapMinds,
    //             'MID'
    //           );
    //           this.availableMindsList.push(element);
    //           this.availableMindsList = this.accountService.removeDuplicatesObject(
    //             this.availableMindsList,
    //             'MID'
    //           );
    //           this.availableTakenCourseList.push(e);
    //           this.availableTakenCourseList = this.accountService.removeDuplicatesObject(
    //             this.availableTakenCourseList,
    //             'TakenCourseId'
    //           );
    //         }
    //       });
    //       element.mappedCourseList.forEach(e => {
    //         this.availableMappedCourseList.push(e);
    //         this.availableMappedCourseList = this.accountService.removeDuplicatesObject(
    //           this.availableMappedCourseList,
    //           'MappedCourseUId'
    //         );
    //       });
    //     });
    //   });
    // }
  }
  filterByMappedCourse() {
    //console.log(this.selectedFilterMappedCourse);
    //this.selectedTakenCourseForAssign = [];
    this.selectedMappedCourseForAssign = [];
    // this.availableMindsList = [];
    // this.availableTakenCourseList = [];
    // this.selectedFilterMind = [];
    // this.selectedFilterTakenCourse = [];
    // this.listOfNonGapMinds = [];
    // if (this.selectedFilterMappedCourse.length === 0) {
    //   this.listOfNonGapMinds = this.listOfNonGapMindsCopy;
      this.listOfNonGapMinds.forEach(element => {
        //this.selectedTakenCourseForAssign[element.MID] = [];
        this.selectedMappedCourseForAssign[element.MID] = [];
        // this.availableMindsList.push(element);
        // element.takenCourseList.forEach(e => {
        //   this.availableTakenCourseList.push(e);
        //   this.availableTakenCourseList = this.accountService.removeDuplicatesObject(
        //     this.availableTakenCourseList,
        //     'TakenCourseId'
        //   );
        // });
      });
    // } else {
    //   this.listOfNonGapMindsCopy.forEach(element => {
    //     //this.selectedTakenCourseForAssign[element.MID] = [];
    //     this.selectedMappedCourseForAssign[element.MID] = [];
    //     const mappedCourseList = [];
    //     this.selectedFilterMappedCourse.forEach(ele => {
    //       element.takenCourseList.forEach(e => {
    //         this.availableTakenCourseList.push(e);
    //         this.availableTakenCourseList = this.accountService.removeDuplicatesObject(
    //           this.availableTakenCourseList,
    //           'TakenCourseId'
    //         );
    //       });
    //       element.mappedCourseList.forEach(e => {
    //         if (e.CourseUniqueId === ele.CourseUniqueId) {
    //           mappedCourseList.push(e);
    //           const obj = {
    //             MID: element.MID,
    //             MindName: element.MindName,
    //             mappedCourseList: mappedCourseList,
    //             takenCourseList: element.takenCourseList
    //           };
    //           this.listOfNonGapMinds.push(obj);
    //           this.listOfNonGapMinds = this.accountService.removeDuplicatesObject(
    //             this.listOfNonGapMinds,
    //             'MID'
    //           );
    //           this.availableMindsList.push(element);
    //           this.availableMindsList = this.accountService.removeDuplicatesObject(
    //             this.availableMindsList,
    //             'MID'
    //           );
    //         }
    //         this.availableMappedCourseList.push(e);
    //         this.availableMappedCourseList = this.accountService.removeDuplicatesObject(
    //           this.availableMappedCourseList,
    //           'MappedCourseUId'
    //         );
    //       });
    //     });
    //   });
    // }
  }
  // selectTakenCourseForAssign(course, flag) {
  //   console.log('selected taken course for filter', course, flag);
  // }
  selectMappedCourseForAssign(minds, course, flag) {
    //console.log('selected mapped course for filter', minds, course, flag);
    if (flag) {
      this.listOfNonGapMinds.forEach(element => {
        element.mappedCourseList.forEach(ele => {
          if (element.MID === minds.MID && ele.CourseId === course.CourseId) {
            //do not change anything
          } else {
            ele.isDisabled = true;
          }
        });
      });
      const midList = [];
      midList[0] = minds.MID;
      this.dataForAssignment = {
        UserIds: midList,
        itemId: course.CourseId,
        itemType: 'Course',
        itemName: course.CourseName,
        itemExpertise: course.Expertise,
        duration: '00.00.00',
        DueDate: ''
      };
    } else {
      this.listOfNonGapMinds.forEach(element => {
        element.mappedCourseList.forEach(ele => {
          ele.isDisabled = false;
        });
      });
    }
  }
  resetAllVariable() {
    this.selectedMappedCourseForAssign = [];
    this.listOfNonGapMinds = this.listOfNonGapMindsCopy;
    this.listOfNonGapMinds.forEach(element => {
      this.selectedMappedCourseForAssign[element.MID] = [];
      element.mappedCourseList.forEach(ele => {
        this.selectedMappedCourseForAssign[element.MID][ele.CourseId] = false;
      });
    });
    this.selectedFilterMind = [];
    this.selectedFilterTakenCourse = [];
    this.selectedFilterMappedCourse = [];
  }
  assignMappedCourse(minds, course, checked) {
    if (checked) {
      const mid = this.dataForAssignment.UserIds[0];
      const cid = this.dataForAssignment.itemId;
      //console.log('call api', this.dataForAssignment);
      this.assignButtonTitle[mid][cid] = 'Assigning...';
      let role;
      if (this.selectedAccount.IsACM === 'ACM') {
        role = 'ACM';
      } else {
        role = 'PCM';
      }
      this.accountService
        .assignToMindForSecondTab(role, this.dataForAssignment)
        .subscribe(res => {
          //console.log('res after assignment from second tab', res);
          this.assignButtonTitle[mid][cid] = 'Assigned';
          this.openpopup('Status', res[mid]);
        });
    }
    if (!this.selectedMappedCourseForAssign[minds.MID][course.CourseId]) {
      this.openpopup(
        '',
        'Please select course that needs to be assigned !'
      );
    }
  }
  openpopup(status, data) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.panelClass = 'popupDialogContainer';
    dialogConfig.data = {
      status: status,
      data: data
    };
    const response = this._popup.open(
      AccountAssignMindsPopupComponent,
      dialogConfig
    );
    response.afterClosed().subscribe(res => {
      //do something after pop up close
      this.getNonGapMindsDetails();
    });
  }
}
