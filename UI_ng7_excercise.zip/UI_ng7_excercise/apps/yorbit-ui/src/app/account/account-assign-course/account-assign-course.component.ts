import {
  Component,
  OnInit,
  Input,
  OnChanges,
  Output,
  EventEmitter
} from '@angular/core';
import { AccountService } from '../account.service';

@Component({
  selector: 'yorbit-account-assign-course',
  templateUrl: './account-assign-course.component.html',
  styleUrls: ['./account-assign-course.component.scss']
})
export class AccountAssignCourseComponent implements OnInit, OnChanges {
  @Input('selectedAccount') selectedAccount;
  @Input('selectedProject') selectedProject;
  @Input('passedProjectRole') passedProjectRole;
  @Output() routeFromAssignView = new EventEmitter<any>();
  selectedProjectRole: any;
  projectRoleList: any;
  selectedTab: string;
  isPageLoading: boolean;
  constructor(private accountService: AccountService) {
    this.projectRoleList = [];
    this.isPageLoading = true;
  }

  ngOnChanges(changeObj) {
    if (changeObj['selectedAccount'] || changeObj['selectedProject']) {
      this.isPageLoading = true;
      this.getProjectRoleList();
    }
  }
  ngOnInit() {
    //this.getProjectRoleList();
  }
  getProjectRoleList() {
    this.selectedTab = 'gap';
    this.accountService
      .getRoles(this.selectedAccount.AccountId, this.selectedProject.ProjectId)
      .subscribe(roles => {
        this.projectRoleList = roles;
        this.isPageLoading = false;
        //console.log('Selected Project Role', this.selectedProjectRole);
        if (this.passedProjectRole === undefined) {
          this.selectedProjectRole = this.projectRoleList[0];
        } else {
          this.projectRoleList.forEach((element, index) => {
            if (element.RoleId === this.passedProjectRole.RoleId) {
              this.selectedProjectRole = this.projectRoleList[index];
            }
          });
        }
      });
  }
  roleSelected() {}
  tabSelected(tab) {
    this.selectedTab = tab;
  }
  goToCreateEditTab() {
    const obj = {
      tab: 'create',
      projectRole: ''
    };
    this.routeFromAssignView.emit(obj);
  }
}
