import { AccountGapMindsModule } from './account-gap-minds.module';

describe('AccountGapMindsModule', () => {
  let accountGapMindsModule: AccountGapMindsModule;

  beforeEach(() => {
    accountGapMindsModule = new AccountGapMindsModule();
  });

  it('should create an instance', () => {
    expect(accountGapMindsModule).toBeTruthy();
  });
});
