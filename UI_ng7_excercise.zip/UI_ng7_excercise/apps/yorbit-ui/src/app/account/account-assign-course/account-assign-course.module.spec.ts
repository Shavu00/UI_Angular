import { AccountAssignCourseModule } from './account-assign-course.module';

describe('AccountAssignCourseModule', () => {
  let accountAssignCourseModule: AccountAssignCourseModule;

  beforeEach(() => {
    accountAssignCourseModule = new AccountAssignCourseModule();
  });

  it('should create an instance', () => {
    expect(accountAssignCourseModule).toBeTruthy();
  });
});
