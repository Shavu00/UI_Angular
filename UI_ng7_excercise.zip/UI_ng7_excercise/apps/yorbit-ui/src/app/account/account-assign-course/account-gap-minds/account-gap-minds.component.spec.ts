import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountGapMindsComponent } from './account-gap-minds.component';

describe('AccountGapMindsComponent', () => {
  let component: AccountGapMindsComponent;
  let fixture: ComponentFixture<AccountGapMindsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountGapMindsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountGapMindsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
