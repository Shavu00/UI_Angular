import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AccountGapMindsComponent } from '../account-gap-minds/account-gap-minds.component';

@Component({
  selector: 'yorbit-account-assign-minds-popup',
  templateUrl: './account-assign-minds-popup.component.html',
  styleUrls: ['./account-assign-minds-popup.component.scss']
})
export class AccountAssignMindsPopupComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<AccountGapMindsComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: any) { }

  ngOnInit() {
    //console.log(this.dialogData);
  }
  close() {
    this.dialogRef.close();
  }

}
