import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { AccountAssignMindsPopupComponent } from '../account-assign-minds-popup/account-assign-minds-popup.component';
import { AccountGapMindsComponent } from './account-gap-minds.component';
import { ReusableUiModule } from '@YorbitWorkspace/reusable-ui';
import { PipesModule } from '@YorbitWorkspace/pipes';
import {
  MatButtonModule,
  MatIconModule,
  MatDialogModule,
  MatDividerModule
} from '@angular/material';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    FlexLayoutModule,
    NgMultiSelectDropDownModule.forRoot(),
    ReusableUiModule,
    PipesModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule
  ],
  entryComponents: [AccountAssignMindsPopupComponent],
  declarations: [AccountGapMindsComponent, AccountAssignMindsPopupComponent],
  exports: [AccountGapMindsComponent]
})
export class AccountGapMindsModule {}
