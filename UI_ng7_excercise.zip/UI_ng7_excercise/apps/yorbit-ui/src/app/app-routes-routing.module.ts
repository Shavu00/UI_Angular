import { NgModule } from '@angular/core';
import { Routes, RouterModule, LoadChildren } from '@angular/router';
import { AuthGuard } from '@YorbitWorkspace/auth';
import { BrowseComponent } from './browse/browse.component';
import { reusableUiRoutes } from '@YorbitWorkspace/reusable-ui';
import { CourseRequestComponent } from './course-request/course-request.component';
import { MyPageComponent } from './my-page/my-page.component';
import { LearningHistoryComponent } from './my-page/learning-history/learning-history.component';
import { LearningComplianceComponent } from './my-page/learning-compliance/learning-compliance.component';
import { LearningPathComponent } from './learning-path/learning-path.component';
import { QuizComponent } from './quiz/quiz.component';
import { PowerbiComponent } from './powerbi/powerbi.component';
import { PssComponent } from './pss/pss.component';
import { HomeComponent } from './home/home.component';
import { UnauthorizedComponent } from './shared/guard-fail-page/unauthorized/unauthorized.component';
import { IdpComponent } from './idp/idp.component';
const routes: Routes = [
  {
    path: '',
    canActivateChild: [AuthGuard],
    children: [
      {
        path:'',
        component: HomeComponent,
        data: { title: 'Home' }
      },
      {
        path: 'browse',
        loadChildren: './browse/browse.module#BrowseModule',
        // component: AccountComponent,
        data: { title: 'Browse' }
      },
      {
        path: 'account',
        loadChildren: './account/account.module#AccountModule',
        // component: AccountComponent,
        data: { title: 'ACCOUNTS' }
      },
      {
        path: 'search',
        loadChildren: './search/search.module#SearchModule',
        //component: SearchComponent,
        data: { title: 'Search' }
      },
      ...reusableUiRoutes,
      {
        path: 'course-request',
        component: CourseRequestComponent,
        data: { title: 'Course Request' }
      },
      {
        path: 'my-page/:id/:role',
        component: MyPageComponent,
        data: { title: 'My Page' }
      },
      {
        path: 'learningpath',
        loadChildren:
          'apps/yorbit-ui/src/app/learning-path/learning-path.module#LearningPathModule',
          data: { title: 'Learning Path' }
      },
      {
        path: 'c2ops',
        loadChildren: 'apps/yorbit-ui/src/app/c2ops/c2ops.module#C2opsModule',
        data: { title: 'C2OPS' }
      },
      {
        path: 'detailsPage',
        loadChildren:
          'apps/yorbit-ui/src/app/details-page/details-page.module#DetailsPageModule',
          data: { title: 'Details Page' }
      },
      {
        path: 'PdetailsPage',
        loadChildren:
          'apps/yorbit-ui/src/app/pdetails-page/pdetails-page.module#PdetailsPageModule',
          data: { title: 'Project Details Page' }
      },
      {
        path: 'quiz/:courseid',
        component: QuizComponent,
        data: { title: 'Quiz' }
      },
      {
        path: 'quiz/:courseid/:lpid/:category',
        component: QuizComponent,
        data: { title: 'Quiz' }
      },
      {
        path: 'powerbireports',
        component: PowerbiComponent,
        data: { title: 'PowerBi Reports' }
      },
      {
        path: 'pss',
        component: PssComponent,
        data: { title: 'PSS' }
      },
      {
        path: 'iCertificationUpload',
        loadChildren:
          'apps/yorbit-ui/src/app/i-certificate-upload/i-certificate-upload.module#ICertificateUploadModule',
          data: { title: 'Internal Certificate Page' }
      },
      {
        path: 'eCertificationUpload',
        loadChildren:
          'apps/yorbit-ui/src/app/e-certificate-upload/e-certificate-upload.module#ECertificateUploadModule',
          data: { title: 'External Certificate Page' }
      },
      {
        path:'AO',
        loadChildren:'apps/yorbit-ui/src/app/ao/ao.module#AoModule',
        data: { title: 'AO' }
      },
      {
        path:'cdm',
        loadChildren:'apps/yorbit-ui/src/app/cdm/cdm.module#CdmModule',
        data: { title: 'CDM' }
      },
      {
        path:'rm',
        loadChildren:'apps/yorbit-ui/src/app/cdm/cdm.module#CdmModule',
        data: { title: 'RM' }
      },
      {
        path:'IDP/:guid',
        component: IdpComponent,
        data: { title: 'IDP' }
      },
      {
        path:'unauthorized',
        component:UnauthorizedComponent,
        data: { title: 'Unauthorized' }
      }
    ]
  }
  // {
  //   path: 'footer',
  //   canActivateChild: [AuthGuard],
  //   children: reusableUiRoutes
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutesRoutingModule {}
