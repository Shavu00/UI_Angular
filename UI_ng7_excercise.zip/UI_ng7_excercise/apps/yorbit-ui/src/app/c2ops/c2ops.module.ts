import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { C2opsComponent } from './c2ops.component';
import { C2opsRoutingModule} from './c2ops-routing/c2ops-routing.module'
import { FlexLayoutModule } from '@angular/flex-layout';
import { DirectivesModule} from '@YorbitWorkspace/directives';
@NgModule({
  imports: [
    CommonModule,
    C2opsRoutingModule,
    FlexLayoutModule,
    DirectivesModule
  ],
  providers:[],
  declarations: [C2opsComponent]
})
export class C2opsModule { }
