import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {
  EnvironmentService,
  Ienvironment
} from '@YorbitWorkspace/global-environments';
@Injectable({
  providedIn: 'root'
})
export class C2opsService {
  config: any;
  constructor(
    private http: HttpClient,
    private _envService: EnvironmentService
  ) {
    this.config = this._envService.getEnvironment();
  }

  downloadCloudCreationTmpl() {
    return this.http
      .get(this.config.apiUrl + 'C2OPS/Excel/All', {
        responseType: 'arraybuffer'
      })
      .toPromise();
  }
  downloadCloudApprovalsTmpl() {
    return this.http
      .get(this.config.apiUrl + 'C2OPS/Download/C2OPSTemplate', {
        responseType: 'arraybuffer'
      })
      .toPromise();
  }
  downloadCloudApprovals() {
    return this.http
      .get(this.config.apiUrl + 'C2OPS/Excel/Req', {
        responseType: 'arraybuffer'
      })
      .toPromise();
  }
  uploadCloudCreationTmpl(file) {
    // var fd = new FormData();
    // fd.append("file", file);
    // let httpHeaders = new HttpHeaders().set('Content-Type', undefined);
    // return this.http.post(this.config.apiUrl + "C2OPS/Lab/Details/Upload", fd,{headers:httpHeaders}).toPromise()
    const fd = new FormData();
    fd.append('file', file);
    return this.http
      .post(this.config.apiUrl + 'C2OPS/Lab/Details/Upload', fd)
      .toPromise();
  }
  uploadCloudApprovalsTmpl(file) {
    // var fd = new FormData();
    // fd.append('file', file);
    // let httpHeaders = new HttpHeaders().set('Content-Type', undefined);
    // return this.http
    //   .post(this.config.apiUrl + 'C2OPS/Requests/Upload', fd, {
    //     headers: httpHeaders
    //   })
    //   .toPromise();
    const fd = new FormData();
    fd.append('file', file);
    return this.http
      .post(this.config.apiUrl + 'C2OPS/Requests/Upload', fd)
      .toPromise();
  }
}
