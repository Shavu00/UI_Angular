import { TestBed, inject } from '@angular/core/testing';

import { C2opsService } from './c2ops.service';

describe('C2opsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [C2opsService]
    });
  });

  it('should be created', inject([C2opsService], (service: C2opsService) => {
    expect(service).toBeTruthy();
  }));
});
