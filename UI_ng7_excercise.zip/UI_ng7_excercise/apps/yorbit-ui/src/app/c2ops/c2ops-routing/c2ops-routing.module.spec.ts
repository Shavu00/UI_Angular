import { C2opsRoutingModule } from './c2ops-routing.module';

describe('C2opsRoutingModule', () => {
  let c2opsRoutingModule: C2opsRoutingModule;

  beforeEach(() => {
    c2opsRoutingModule = new C2opsRoutingModule();
  });

  it('should create an instance', () => {
    expect(c2opsRoutingModule).toBeTruthy();
  });
});
