import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes , RouterModule} from '@angular/router';
import {C2opsComponent} from '../c2ops.component';
const routes :Routes = [
  {
    path: '',
    component: C2opsComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  declarations: []
})
export class C2opsRoutingModule { }
