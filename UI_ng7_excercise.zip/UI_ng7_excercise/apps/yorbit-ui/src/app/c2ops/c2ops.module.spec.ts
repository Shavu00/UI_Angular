import { C2opsModule } from './c2ops.module';

describe('C2opsModule', () => {
  let c2opsModule: C2opsModule;

  beforeEach(() => {
    c2opsModule = new C2opsModule();
  });

  it('should create an instance', () => {
    expect(c2opsModule).toBeTruthy();
  });
});
