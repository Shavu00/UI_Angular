import { Component, OnInit } from '@angular/core';
import {C2opsService} from './c2ops.service';
import {saveAs } from 'file-saver';
@Component({
  selector: 'yorbit-c2ops',
  templateUrl: './c2ops.component.html',
  styleUrls: ['./c2ops.component.scss']
})
export class C2opsComponent implements OnInit {
  cloudLabUploadFile :any;
  cloudRequestUploadFile :any;
  labCreationUploadStatus       :string;
  requestsUploadStatus          :string;
  cloudLabUploadBtnText         :string;
  cloudRequestsUploadBtnText    :string;
  cloudLabDownloadBtnText       :string;
  cloudRequestsDownloadBtnText  :string;
  constructor(private c2opsService:C2opsService) {

    this.cloudLabUploadFile = "";
    this.cloudRequestUploadFile = "";
    this.labCreationUploadStatus = "";
    this.requestsUploadStatus = "";
    this.cloudLabUploadBtnText = "UPLOAD";
    this.cloudRequestsUploadBtnText = "UPLOAD";
    this.cloudLabDownloadBtnText = "Download CloudLab Data";
    this.cloudRequestsDownloadBtnText = "Download Requests Data";
   }

  ngOnInit() {
    //Call this  on first load
this.c2opsFirstload();
  }
   getCloudCreationTmpl() {
    this.c2opsService.downloadCloudCreationTmpl().then( (response:any)=> {
           this.cloudLabDownloadBtnText = "Download Cloudlab template";
            var data = new Blob([response], { type: "application/octet-stream" });
            saveAs(data, 'Cloud-Mapping.xlsx');

    })
    .catch( (error) =>{
       this.cloudLabDownloadBtnText = "Download Cloudlab template";

    })
}
 getCloudApprovalsTmpl() {
    this.c2opsService.downloadCloudApprovalsTmpl().then( (response:any)=> {
            var data = new Blob([response], { type: 'application/octet-stream' });
            saveAs(data, 'C2OPS_Template.xlsx');

    })
        .catch( (error:any)=> {
        })
}
 getCloudApprovals() {
    this.c2opsService.downloadCloudApprovals().then( (response:any) => {
            var data = new Blob([response], { type: 'application/octet-stream' });
            saveAs(data, 'C2OPS_AllRequests.xlsx');
           this.cloudRequestsDownloadBtnText = "Download Cloudlab template";

    })
        .catch( (error:any)=> {
           this.cloudRequestsDownloadBtnText = "Download Cloudlab template";
        })
}
 uploadCloudCreationTmpl() {
    this.c2opsService.uploadCloudCreationTmpl(this.cloudLabUploadFile).then( (response:any)=> {
           this.labCreationUploadStatus = "Uploaded Successfully";
           this.cloudLabUploadBtnText = "Upload";

    })
        .catch( (error:any)=> {
           this.labCreationUploadStatus = "Upload Failed! Please check e-mail for error log";
           this.cloudLabUploadBtnText = "UPLOAD";
        })

}
 uploadCloudApprovalsTmpl() {
    this.c2opsService.uploadCloudApprovalsTmpl(this.cloudRequestUploadFile).then( (response:any)=> {
           this.requestsUploadStatus = "Uploaded Successfully";
           this.cloudRequestsUploadBtnText = "UPLOAD";

    })
        .catch( (error:any)=> {
           this.requestsUploadStatus = "Upload Failed! Please check e-mail for error log";
           this.cloudRequestsUploadBtnText = "UPLOAD";
        })
}

 setDefaultValuesForUploads() {
   this.requestsUploadStatus = "";
   this.labCreationUploadStatus = "";
}
fileModel(event){
if(event.inputFor=='cloudLabUploadFile'){
this.cloudLabUploadFile=event.file;
}
else if(event.inputFor=='cloudRequestUploadFile'){
        this.cloudRequestUploadFile=event.file;

}
}
// Check C2OPS Role
 c2opsFirstload() {
    // get content for C2OPS else redirect to unauthorised page
    //if ( appConstants.C2OPS ) {
    //    // do nothing
    //} else {
    //    //for non C2OPS-user route to unauthorised
    //    $window.location.href = '/unauthorized.html';
    //}
};

}
