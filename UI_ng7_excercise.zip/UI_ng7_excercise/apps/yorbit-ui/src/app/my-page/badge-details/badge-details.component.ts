import { Component, OnInit, Input, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { BadgeDetails} from '../my-page.interface';
import {MyPageService} from '../my-page.service';
import { GraphDataService } from '@YorbitWorkspace/graph';



@Component({
  selector: 'yorbit-badge-details',
  templateUrl: './badge-details.component.html',
  styleUrls: ['./badge-details.component.scss']
})
export class BadgeDetailsComponent implements OnInit {
  badge: object;
  badgeDetails: BadgeDetails;
  badgeDetailsLoading: boolean;
  assignerNameLoading: boolean;
  mid:string;


  constructor(
    private dialogRef: MatDialogRef<BadgeDetailsComponent>,
    @Inject(MAT_DIALOG_DATA) data,
    private _myPageSvc: MyPageService,
    private _graphSvc: GraphDataService
  ) {
    this.badge = data.context;
    this.mid = data.mid;


  }

  ngOnInit() {
    this.getBadgeDetails(this.badge);

  }

  close(){
    this.dialogRef.close();
  }

  getBadgeDetails(badge) {
    this.badgeDetails = null;
    this.badgeDetailsLoading = true;
    this._myPageSvc.getBadgeDetails(badge.CourseId, this.mid).subscribe(
      data => {
        this.badgeDetailsLoading = false;

        if (data != null) {
          this.badgeDetails = data;
          this.badgeDetails.DateOfCompletion = new Date(data.DateOfCompletion);
          if (data.AssignedBy != null && data.AssignedBy !== '') {
            this.assignerNameLoading = true;
            this._graphSvc.getUserName(data.AssignedBy).subscribe(
              name => {
                this.badgeDetails.AssignerName = name.value;
              },
              error => {
                this.assignerNameLoading = false;
                this.badgeDetails.AssignerName = 'NA';
              }
            );
          }
        }
      },
      error => {}
    );
  }

  getDateFromString(stringDate){
    return new Date(stringDate);
  }

}


