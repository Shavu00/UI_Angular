import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IBadge } from '../store/my-page-details.interface';
import { Observable } from 'rxjs';
import * as fromMyPageStore from '../store';
import { Store } from '@ngrx/store';
import { MyPageService } from '../my-page.service';
import {
  OrderbyDatePipe,
  BadgeQuarterPipe,
  ValidDatePipe,
  ExpertisePipe
} from '@YorbitWorkspace/pipes';
import { GraphDataService } from '@YorbitWorkspace/graph';

import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { LearningBadgesComponent } from '../learning-badges/learning-badges.component';
import { BadgeDetailsComponent } from '../badge-details/badge-details.component';

@Component({
  selector: 'yorbit-learning-history',
  templateUrl: './learning-history.component.html',
  styleUrls: ['./learning-history.component.scss']
})
export class LearningHistoryComponent implements OnInit {
  MId: string;
  role: string;
  historyDetails: Array<IBadge> = [];

  firstQuarterHistory: Array<IBadge> = [];
  secondQuarterHistory: Array<IBadge> = [];
  thirdQuarterHistory: Array<IBadge> = [];
  fourthQuarterHistory: Array<IBadge> = [];
  reverseOrderCompletedDate: Array<IBadge> = [];

  selectedYear: number;
  showResultsForYear: number;
  latestDOCYear: number;
  oldDOCYear: number;
  badgesLength: number;
  date: Date;
  openExpansion: Array<boolean>;
  historyLoading: boolean;

  constructor(
    private route: ActivatedRoute,
    private _myPageSvc: MyPageService,
    private myPageStore: Store<fromMyPageStore.IMyPageReducerState>,
    private badgeQuarterPipe: BadgeQuarterPipe,
    private orderbyDatePipe: OrderbyDatePipe,
    private validDatePipe: ValidDatePipe,
    private expertisePipe: ExpertisePipe,
    private _graphSvc: GraphDataService,
    private _dialog: MatDialog
  ) {}

  ngOnInit() {
    this.date = new Date();
    this.selectedYear = this.date.getFullYear();
    this.showResultsForYear = this.date.getFullYear();

    this.route.params.subscribe(params => {
      this.MId = params.id;
      this.role = params.role;
      this.getHistoryDetails();
    });

    this.openExpansion = new Array(4);
    this.openExpansion[0] = false;
    this.openExpansion[1] = false;
    this.openExpansion[2] = false;
    this.openExpansion[3] = false;
  }

  getHistoryDetails() {
    if (this.role === 'self') {
      this.myPageStore.select(fromMyPageStore.getMyPageHistoryLoading).subscribe(data=>{
        this.historyLoading = data;
      })
      this.myPageStore
        .select(fromMyPageStore.getMyPageHistory)
        .subscribe(data => {
          this.historyDetails = data;
          if (this.historyDetails.length > 0) {
            const validDateBadgeList: Array<any> = this.validDatePipe.transform(
              this.historyDetails as any
            );
            if (validDateBadgeList.length > 0) {
              this.getDOCYears(validDateBadgeList);
              this.filterByYear(this.showResultsForYear, null);
            }
          }
        });
    } else if (this.role === 'learner') {
      this.historyLoading = true;
      this._myPageSvc.getBadgesListOfLearner(this.MId).subscribe(
        data => {
          this.historyDetails = data;
          this.historyLoading = false;
          if (this.historyDetails.length > 0) {
            const validDateBadgeList: Array<any> = this.validDatePipe.transform(
              this.historyDetails as any
            );
            if (validDateBadgeList.length > 0) {
              this.getDOCYears(validDateBadgeList);
              this.filterByYear(this.showResultsForYear, null);
            }
          }
        },
        error => {
        }
      );
    }
  }

  filterByYear(selectedYear, moveForward) {
    let year;
    if (moveForward == null) {
      year = selectedYear;
    } else if (moveForward === true) {
      year = selectedYear + 1;
    } else if (moveForward === false) {
      year = selectedYear - 1;
    }

    if (year >= this.oldDOCYear && year <= this.latestDOCYear) {
      this.selectedYear = year;
      this.firstQuarterHistory = this.badgeQuarterPipe.transform(
        this.historyDetails,
        year,
        'Q1'
      );
      this.secondQuarterHistory = this.badgeQuarterPipe.transform(
        this.historyDetails,
        year,
        'Q2'
      );
      this.thirdQuarterHistory = this.badgeQuarterPipe.transform(
        this.historyDetails,
        year,
        'Q3'
      );
      this.fourthQuarterHistory = this.badgeQuarterPipe.transform(
        this.historyDetails,
        year,
        'Q4'
      );
      this.setColor(this.fourthQuarterHistory);
    } else {
      //  vmLearningHistory.selectedYear = year;
    }
  }

  getDOCYears(badges) {
    this.reverseOrderCompletedDate = this.orderbyDatePipe.transform(
      badges,
      'CompletedDate'
    );
    if (this.reverseOrderCompletedDate.length > 0) {
      this.badgesLength = this.reverseOrderCompletedDate.length;
      this.latestDOCYear = new Date(
        this.reverseOrderCompletedDate[0].CompletedDate
      ).getFullYear();
      this.oldDOCYear = new Date(
        this.reverseOrderCompletedDate[this.badgesLength - 1].CompletedDate
      ).getFullYear();
      this.selectedYear = this.latestDOCYear;
      this.showResultsForYear = this.latestDOCYear;
    } else {
      this.latestDOCYear = this.date.getFullYear();
      this.oldDOCYear = this.date.getFullYear();
      this.selectedYear = this.latestDOCYear;
      this.showResultsForYear = this.latestDOCYear;
    }
  }

  setColor(badgeList) {
    const _101Array = this.expertisePipe.transform(badgeList, ['101']);
  }

  openDialog(context) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;

    dialogConfig.data = {
      context: context,
      mid: this.MId
    };
    dialogConfig.panelClass = 'popupDialogContainer';
    this._dialog.open(LearningBadgesComponent, dialogConfig);
  }

  open(context) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.panelClass = 'popupDialogContainer';
    dialogConfig.data = {
      context: context,
      mid: this.MId
    };
    this._dialog.open(BadgeDetailsComponent, dialogConfig);
  }

  spaceTrim(input){
    if(input){
      return input.toString().trim();
    }else{
      return '';
    }
  }
}
