import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LearningComplianceComponent } from './learning-compliance.component';

describe('LearningComplianceComponent', () => {
  let component: LearningComplianceComponent;
  let fixture: ComponentFixture<LearningComplianceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LearningComplianceComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LearningComplianceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
