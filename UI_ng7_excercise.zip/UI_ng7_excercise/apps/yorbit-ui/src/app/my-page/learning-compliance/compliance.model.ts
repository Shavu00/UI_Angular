export const categoryOptions = [
  'My compliance status is incorrect',
  'Current cycle duration is incorrect',
  'Link to learning policy is incorrect',
  'My Primary L4 is incorrect',
  'Acquired credit(s) is wrong',
  'Others'
];

export const complianceInfo = [
  'This page displays courses considered for compliance for the Jan 2020 promotion cycle only.',
  'Once the course is marked to completed, the credits associated with the course will be displayed immediately on the Learning history page when you click on the badge.',
  'Credits associated with a course will appear on this page only 24hrs after the course has been marked to completed.',
  '101 courses and Behavioral Academy courses are not considered for learning policy compliance.',
  'The compliance status and current cycle are not applicable for C1 minds who are due for promotion on Mar or Sept cycle.'
];
