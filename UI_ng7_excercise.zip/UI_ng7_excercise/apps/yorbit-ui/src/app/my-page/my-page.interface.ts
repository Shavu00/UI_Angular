export enum APIResponse {
  Success = 'newCourseReqSuccess',
  Error = 'newCourseReqError'
}

export enum Messages {
  SuccessMsg = 'Course request is submitted successfully',
  ErrorMsg = 'Something went wrong. Please try later'
}

export interface BadgeDetails {
  Expertise?: any;
  CourseName?: any;
  Skill?: any;
  AccountName?: any;
  DateOfCompletion: any;
  AssignedBy?: any;
  QuizPercentage?: any;
  AssignerName ?: any;
  Credit?:any;
}


