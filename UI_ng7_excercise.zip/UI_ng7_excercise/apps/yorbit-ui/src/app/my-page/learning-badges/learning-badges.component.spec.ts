import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LearningBadgesComponent } from './learning-badges.component';

describe('LearningBadgesComponent', () => {
  let component: LearningBadgesComponent;
  let fixture: ComponentFixture<LearningBadgesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LearningBadgesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LearningBadgesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
