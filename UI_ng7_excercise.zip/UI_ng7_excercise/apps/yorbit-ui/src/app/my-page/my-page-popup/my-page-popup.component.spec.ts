import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyPagePopupComponent } from './my-page-popup.component';

describe('MyPagePopupComponent', () => {
  let component: MyPagePopupComponent;
  let fixture: ComponentFixture<MyPagePopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MyPagePopupComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyPagePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
