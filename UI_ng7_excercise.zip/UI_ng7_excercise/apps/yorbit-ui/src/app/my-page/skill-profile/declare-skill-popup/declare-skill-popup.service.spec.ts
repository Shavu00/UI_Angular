import { TestBed } from '@angular/core/testing';

import { DeclareSkillPopupService } from './declare-skill-popup.service';

describe('DeclareSkillPopupService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DeclareSkillPopupService = TestBed.get(DeclareSkillPopupService);
    expect(service).toBeTruthy();
  });
});
