import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeclareSkillPopupComponent } from './declare-skill-popup.component';

describe('DeclareSkillPopupComponent', () => {
  let component: DeclareSkillPopupComponent;
  let fixture: ComponentFixture<DeclareSkillPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeclareSkillPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeclareSkillPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
