import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { EnvironmentService } from '@YorbitWorkspace/global-environments';
import { catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';
import {
  ICompliance,
  IBadge,
  IUserSkills,
  ICoreSkills,
  ISkill,
  IPrimarySkill
} from './store/my-page-details.interface';
import { BadgeDetails } from './my-page.interface';

@Injectable({
  providedIn: 'root'
})
export class MyPageService {
  _baseURL: string;
  constructor(private _http: HttpClient, private _envSvc: EnvironmentService) {
    this._baseURL = this._envSvc.getEnvironment().apiUrl;
  }
  getCDMandRM(Mid) {
    const url = this._baseURL + 'User/CDMandRM/' + Mid;
    return this._http.get(url).toPromise();
  }
  getBadgesListOfLearner(MId) {
    const url = this._baseURL + 'Users/Badges/' + MId;
    return this._http.get<IBadge[]>(url);
  }

  getBadgeDetails(courseId, userId) {
    const url =
      this._baseURL + 'Users/Badge/Details/' + courseId + '/' + userId;
    return this._http.get<BadgeDetails>(url);
  }

  getLearnerComplianceStatus(userId) {
    const url = this._baseURL + 'Users/ComplianceStatus/' + userId;
    return this._http.get<ICompliance>(url);
  }

  sendReport(payload) {
    const url = this._baseURL + 'Users/MailOnLearningComplianceIssue';
    return this._http.post(url, payload);
  }

  getUserPrimarySkill(MId) {
    const url = this._baseURL + 'User/PrimarySkills/' + MId;
    return this._http.get<IPrimarySkill>(url);
  }

  getDeclaredAndAquiredSkill(MId) {
    const url = this._baseURL + 'User/Skills/' + MId;
    return this._http.get<IUserSkills>(url);
  }

  getCoreSkills(primaryL4) {
    const pl4 = encodeURIComponent(primaryL4);
    const url =
      this._baseURL +
      'SkillRecommendations/GetCoreSkills' +
      '?primaryL4=' +
      pl4;
    return this._http.get<ICoreSkills>(url);
  }

  getSupportSkills(primaryL4) {
    const pl4 = encodeURIComponent(primaryL4);
    const url =
      this._baseURL +
      'SkillRecommendations/GetSupportSkills' +
      '?primaryL4=' +
      pl4;
    return this._http.get<any>(url);
  }

  getCrossSkills(primaryL4) {
    const pl4 = encodeURIComponent(primaryL4);
    const url =
      this._baseURL +
      'SkillRecommendations/GetCrossSkills' +
      '?primaryL4=' +
      pl4;
    return this._http.get(url);
  }

  getFutureSkills(primaryL4) {
    const pl4 = encodeURIComponent(primaryL4);
    const url =
      this._baseURL +
      'SkillRecommendations/GetFutureSkillListName' +
      '?primaryL4=' +
      pl4;
    return this._http.get<Array<string>>(url);
  }

  getFutureSkillPath(listName, primaryL4) {
    const lName = encodeURIComponent(listName);
    const pl4 = encodeURIComponent(primaryL4);
    const url =
      this._baseURL +
      'SkillRecommendations/GetFutureSkillPath' +
      '?listName=' +
      lName +
      '&primaryL4=' +
      pl4;
    return this._http.get<any>(url);
  }

  addCrossSkill(payload, skillType) {
    const recommendationType = skillType;
    const url =
      this._baseURL +
      'SkillRecommendations/AddCrossSkillToLP?' +
      'recommendationType=' +
      recommendationType;
    return this._http.post<any>(url, payload);
  }

  getCrossSkillsNames(primaryL4) {
    const pl4 = encodeURIComponent(primaryL4);
    const url =
      this._baseURL +
      'SkillRecommendations/GetCrossSkillsNames' +
      '?primaryL4=' +
      pl4;
    return this._http.get<string[]>(url);
  }

  getCrossSkillsList(primaryL4, destinationSkill) {
    const pl4 = encodeURIComponent(primaryL4);
    const dest = encodeURIComponent(destinationSkill);
    const url =
      this._baseURL +
      'SkillRecommendations/GetSkillPathDetails' +
      '?primaryL4=' +
      pl4 +
      '&destinationSkill=' +
      dest;
    return this._http.get<Array<any>>(url);
  }

  getPL4FromCapacityReport() {
    const url = this._baseURL + 'SkillPlan/GetL4List';
    return this._http.get(url);
  }

  getSupportSkillForDemo(primaryL4) {
    const pl4 = encodeURIComponent(primaryL4);
    const url =
      this._baseURL +
      'SkillRecommendations/GetSupportSkillsForDemo' +
      '?primaryL4=' +
      pl4;
    return this._http.get(url);
  }

  getCrossSkillForDemo(primaryL4, listName) {
    const pl4 = encodeURIComponent(primaryL4);
    const lName = encodeURIComponent(listName);
    const url =
      this._baseURL +
      'SkillRecommendations/GetCrossSkillsforDemo' +
      '?crossSkillName=' +
      lName +
      '&primaryL4=' +
      pl4;
    return this._http.get(url);
  }

  getFutureSkillPathForDemo(listName, primaryL4) {
    const pl4 = encodeURIComponent(primaryL4);
    const lName = encodeURIComponent(listName);
    const url =
      this._baseURL +
      'SkillRecommendations/GetFutureSkillsPathforDemo' +
      '?listName=' +
      lName +
      '&primaryL4=' +
      pl4;
    return this._http.get(url);
  }
}
