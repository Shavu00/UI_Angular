import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as fromGraphStore from '@YorbitWorkspace/graph';
import { GraphDataService } from '@YorbitWorkspace/graph';
import { Store } from '@ngrx/store';
import * as fromMyPageStore from './store';
import { DomSanitizer } from '@angular/platform-browser';
import { WINDOW } from '../shared/services/window.service';
import { Globals } from '../globals';
import { HomeService } from '../home/home.service';
@Component({
  selector: 'yorbit-my-page',
  templateUrl: './my-page.component.html',
  styleUrls: ['./my-page.component.scss']
})
export class MyPageComponent implements OnInit {
  graphUserName: string;
  graphUserImage: Blob;
  graphUserJobTitle: string;
  role: string;
  MId: string;
  tab: string;
  tabs: boolean[];
  hover: boolean[];

  profileImgStyle: any;
  events: string[] = [];
  opened: boolean;
  imageUrl: any;
  imageLoaded: boolean;

  complianceStatus: string;
  isCompliant: boolean;

  personalisedRecommendations: Array<any>;
  constructor(
    private graphStore: Store<fromGraphStore.IGraphReducerState>,
    private myPageStore: Store<fromMyPageStore.IMyPageReducerState>,
    @Inject(WINDOW) private _window: Window,
    private route: ActivatedRoute,
    private _graphSvc: GraphDataService,
    private sanitizer: DomSanitizer,
    private globals: Globals,
    private homeService: HomeService
  ) {}

  ngOnInit() {
    this.personalisedRecommendations = null;
    this.route.params.subscribe(params => {
      this.opened = false;
      this.role = params.role;
      this.MId = params.id;
      this.tab = params.tab;
      this.tabs = Array(5);
      this.hover = Array(5);
      this.tabs[0] = true;
      this.imageLoaded = false;
      this.getGraphDetails();
      if (this.role === 'self') {
        this.getLearningHistory();
        this.getPrimarySkills();
        this.getSkillProfile();
        this.getPersonalisedRecommendations();
      }
      this.getCompliance();
    });
    if (this.globals.isRecommendationsClicked) {
      this.setTab(3);
      this.globals.isRecommendationsClicked = false;
    }
    if (this.globals.isSkillProfileClicked) {
      this.setTab(2);
      this.globals.isSkillProfileClicked = false;
    }
    if (this.globals.isPersonalisedRecommendationsClicked) {
      this.setTab(4);
      this.globals.isPersonalisedRecommendationsClicked = false;
    }
  }

  getGraphDetails() {
    if (this.role === 'self') {
      this.graphStore.select(fromGraphStore.getGraphUserName).subscribe(res => {
        this.graphUserName = res;
      });
      this.graphStore
        .select(fromGraphStore.getGraphUserImage)
        .subscribe(res => {
          this.graphUserImage = res;
          this.imageUrl = this.createImageURL(this.graphUserImage);
          this.imageLoaded = true;
        });
      this.graphStore
        .select(fromGraphStore.getGraphUserJobTitle)
        .subscribe(res => {
          this.graphUserJobTitle = res;
        });
    } else if (this.role === 'learner') {
      this._graphSvc.getUserImage(this.MId).subscribe(
        data => {
          this.graphUserImage = data;
          this.imageUrl = this.createImageURL(this.graphUserImage);
          this.imageLoaded = true;
        },
        error => {
          this.imageLoaded = false;
        }
      );
      this._graphSvc.getUserName(this.MId).subscribe(
        data => {
          this.graphUserName = data.value;
        },
        error => {
          this.graphUserName = this.MId;
        }
      );
      this._graphSvc.getUserJobTitle(this.MId).subscribe(
        data => {
          this.graphUserJobTitle = data.value;
        },
        error => {
          this.graphUserJobTitle = this.MId;
        }
      );
    }
  }

  getLearningHistory() {
    this.myPageStore.dispatch(
      new fromMyPageStore.GetMyPageLearningHistory(this.MId)
    );
  }

  getSkillProfile() {
    this.myPageStore.dispatch(
      new fromMyPageStore.GetMyPageSkillProfile(this.MId)
    );
  }

  getPrimarySkills() {
    this.myPageStore.dispatch(
      new fromMyPageStore.GetMyPagePrimarySkill(this.MId)
    );
  }
  getPersonalisedRecommendations() {
    this.homeService.getRecommendedCourses(this.MId).then((res: any) => {
      if (res != null && res.length !== 0) {
        this.personalisedRecommendations = res;
      } else {
        this.personalisedRecommendations = [];
      }
      this.homeService.personalizedRecommendations = res;
    });
  }
  setTab(tab) {
    for (let i = 0; i < this.tabs.length; i++) {
      this.tabs[i] = false;
    }
    this.tabs[tab] = true;
  }

  createImageURL(imageBlob) {
    const imageURL = this._window.URL.createObjectURL(imageBlob);
    return this.sanitizer.bypassSecurityTrustUrl(imageURL);
  }

  getCompliance() {
    if (this.role === 'self') {
      this.myPageStore.select(fromMyPageStore.getMyPageCompliance).subscribe(
        data => {
          this.complianceStatus = data.ComplianceStatus;
          if (this.complianceStatus.toLowerCase() === 'non-compliant') {
            this.isCompliant = false;
          } else {
            this.isCompliant = true;
          }
        },
        error => {}
      );
    } else {
      this.isCompliant = this.globals.isLearnerCompliant;
    }
  }
}
