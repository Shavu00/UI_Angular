import { MyPageEffects } from './my-page.effect';
export const effectsMyPage: any[] = [MyPageEffects];

export * from './my-page.effect';
