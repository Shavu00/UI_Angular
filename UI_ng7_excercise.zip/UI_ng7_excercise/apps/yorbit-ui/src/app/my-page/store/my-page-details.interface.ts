/* Start of Compliance Interfaces */
export interface ICompliance {
  AchievedCredits?: number;
  ComplianceCourses?: ICourse[];
  CompliancePolicyUrl?: string | null;
  ComplianceStatus?: string | null;
  CycleEndDate: string|Date;
  CycleStartDate: string|Date;
  RequiredCredits: number;
}
export interface ICourse {
  CourseId: string | null;
  CourseName: string | null;
  Credit: number;
  Expertise: string;
}
/* End of Compliance Interfaces */

/* Start of Learning History Interfaces */
export interface IBadgeList {
  Badges: IBadge[];
}

export interface IBadge {
  BadgeId: number;
  UniqueId?: any;
  BadgeImage: string | null;
  BadgeName: string | null;
  Status: string;
  CourseId: string;
  CompletedDate: Date;
  Score: number;
  isMigrated: boolean;
  IsFeedbackSet: boolean;
  IsFeedbackMandatory: boolean;
  IsExternalCertificate: boolean;
  IsRetakeMandatory: boolean;
}
/* End of Learning History Interfaces */

/* Start of Skills Profile Interfaces */

export interface IUserSkills {
  AcquiredSkills: IAcquiredOrDeclaredSkill[];
  DeclaredSkills: IAcquiredOrDeclaredSkill[];
}
export interface IAcquiredOrDeclaredSkill {
  Name:       string;
  CourseInfo: CourseInfo[];
}
export interface CourseInfo {
  CourseName:  string;
  CreatedDate: string;
  Expertise:   string;
  IsApproved:  boolean;
  Approver?:    string;
}
/* End of Skills Profile Interfaces */

/* Start of Skilling Recommendations Interfaces */
export interface ISkill {
  SkillName?: string | null;
  CourseId?: string | null;
  CourseName?: string | null;
  Expertise?: string | null;
  Status?: string | null;
  Duration?: number;
  OrderNo?: number;
}

export interface ICoreSkills {
  CoreSkillCourses: ISkill[];
  Message?: any;
}

// export interface ISupportSkills {
//   SupportSkillCourses: ISkill[];
// }

export interface ICrossSkillList {
  CrossSkillName?: string;
  CrossSkillPath?: ICrossSkillPath | any;
  IsLoading?: boolean;
}

export interface ICrossSkillPath {
  TotalDuration?: number;
  TargetSkill?: ISkill;
  TransitionSkills?: ISkill[];
  IsTargetSkillAlreadyAdded?: boolean;
}

export interface IFutureSkillList {
  FutureSkillNames: string[];
}

export interface IFutureSkillPaths {
  FutureSkillName ?: string;
  FutureSkillPaths?: IFutureSkillPath[];
  IsLoading?:boolean;
  IsAdded?:boolean;
}

export interface IFutureSkillPath {
  TotalDuration: number;
  TargetSkill: ISkill;
  TransitionSkills: ISkill[];
  IsTargetSkillAlreadyAdded: boolean;
}
/* End of Skilling Recommendations Interfaces */
/* User Primary Skill */

export interface IPrimarySkill {
  PrimaryL1: string | null;
  PrimaryL2: string | null;
  PrimaryL3: string | null;
  PrimaryL4: string | null;
}
