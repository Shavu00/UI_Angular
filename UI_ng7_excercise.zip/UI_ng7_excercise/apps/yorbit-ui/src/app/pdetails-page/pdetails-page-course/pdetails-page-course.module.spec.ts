import { PdetailsPageCourseModule } from './pdetails-page-course.module';

describe('PdetailsPageCourseModule', () => {
  let pdetailsPageCourseModule: PdetailsPageCourseModule;

  beforeEach(() => {
    pdetailsPageCourseModule = new PdetailsPageCourseModule();
  });

  it('should create an instance', () => {
    expect(pdetailsPageCourseModule).toBeTruthy();
  });
});
