import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PdetailsPageCourseComponent } from './pdetails-page-course.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ReusableUiModule } from '@YorbitWorkspace/reusable-ui';
import { ContentTilesModule } from '../../shared/content-tiles/content-tiles.module';
import { AccordionModule } from '../../shared/accordion/accordion.module';
import { CardFeatureModule } from '../../shared/card-feature/card-feature.module'
import { LinkyModule } from 'angular-linky';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    ReusableUiModule,
    ContentTilesModule,
    AccordionModule,
    CardFeatureModule,
    LinkyModule
  ],
  declarations: [PdetailsPageCourseComponent],
  exports: [PdetailsPageCourseComponent]
})
export class PdetailsPageCourseModule {}
