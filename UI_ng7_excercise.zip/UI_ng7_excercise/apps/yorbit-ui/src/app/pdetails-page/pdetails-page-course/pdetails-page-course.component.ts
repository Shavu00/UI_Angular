import { Component, OnInit, Input } from '@angular/core';
import * as fromRoleAccessStore from '@YorbitWorkspace/role-access';
import { Store } from '@ngrx/store';

@Component({
  selector: 'yorbit-pdetails-page-course',
  templateUrl: './pdetails-page-course.component.html',
  styleUrls: ['./pdetails-page-course.component.scss']
})
export class PdetailsPageCourseComponent implements OnInit {
  @Input('contentDetails') contentDetails;
  @Input('unitDetails') unitDetails;
  roleList: fromRoleAccessStore.IroleData;
  constructor(private userRoleAccessStore: Store<fromRoleAccessStore.IRoleReducerState>) {}

  ngOnInit() {

        //get the roles
        this.userRoleAccessStore
        .select(fromRoleAccessStore.getRoleAccessList)
        .subscribe(roleList => {
          this.roleList = roleList;
        });
  }
}
