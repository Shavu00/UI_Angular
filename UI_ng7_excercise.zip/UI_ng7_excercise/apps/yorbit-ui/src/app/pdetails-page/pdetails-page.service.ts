import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import {
  EnvironmentService,
  Ienvironment
} from '@YorbitWorkspace/global-environments';

@Injectable({
  providedIn: 'root'
})
export class PdetailsPageService {
  config: Ienvironment;
  constructor(private http:HttpClient, private _envSvc: EnvironmentService) {
    this.config = this._envSvc.getEnvironment();
  }

  getPPackageDetails(payload, type):Observable<any>{
    if(type==='Course'){
      return this.http.post(this.config.apiUrl + 'Course', payload).pipe(
        tap((res: Response) => res),
        catchError((e: Response) => throwError(e))
      );
    }
    else if(type==='FamilyPackage'){
      return this.http.post(this.config.apiUrl + 'Package', payload).pipe(
        tap((res: Response) => res),
        catchError((e: Response) => throwError(e))
      );
    }
  }
  getPPContentofCourse(payload):Observable<any>{
    return this.http.post(this.config.apiUrl + 'LearningPlan/Course/Units', payload).pipe(
      tap((res: Response) => res),
      catchError((e: Response) => throwError(e))
    );
  }
  getPPContentofPackage(payload):Observable<any>{
    return this.http.post(this.config.apiUrl + 'LearningPlan/Package/Courses', payload).pipe(
      tap((res: Response) => res),
      catchError((e: Response) => throwError(e))
    );
  }
  getContentInsideUnitForAccount(data): Observable<any> {
    return this.http.post(this.config.apiUrl + 'LearningPlan/Unit/Contents', data).pipe(
      tap((res: Response) => res),
      catchError((e: Response) => throwError(e))
    );
  }
}
