import { TestBed, inject } from '@angular/core/testing';

import { PdetailsPageService } from './pdetails-page.service';

describe('PdetailsPageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PdetailsPageService]
    });
  });

  it('should be created', inject([PdetailsPageService], (service: PdetailsPageService) => {
    expect(service).toBeTruthy();
  }));
});
