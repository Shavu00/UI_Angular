import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';

import { ContentAddedCheckService } from '../shared/services/content-added-check.service';
import { AddPopupComponent } from '../shared/card-feature/add-content/add-popup/add-popup.component';

import { PdetailsPageService } from './pdetails-page.service';
import * as fromRoleAccessStore from '@YorbitWorkspace/role-access';
import { Store } from '@ngrx/store';

interface Content {
  Name: string;
  UniqueId: string;
  Academy: string;
  Genre: string;
  Skill: string;
  Vendor: string;
  Type: string;
  Description: string;
  Duration: string;
  TopicsCovered: string;
  Internal: boolean;
  Category: string;
  ContentCount: number;
  AccountPackage: boolean;
  ProjectPackage: boolean;
  TotalUsers: number;
  TotalShares: number;
  TotalExperts: number;
  Account: string;
  Project: string;
  AcademyUniqueId: number;
  GenreUniqueId: number;
  SkillUniqueId: number;
  Badges: any;
  IsHidden: boolean;
}

@Component({
  selector: 'yorbit-pdetails-page',
  templateUrl: './pdetails-page.component.html',
  styleUrls: ['./pdetails-page.component.scss']
})
export class PdetailsPageComponent implements OnInit {
  public uniqueId: string;
  public accountPackage: boolean;
  public projectPackage: boolean;
  public accountId: string;
  public projectId: string;
  public itemType: string;
  public expertise: string;
  public id: number;
  public contentDetails: Content;
  public contentCDetails: Array<Object>;
  public contentPDetails: Array<Object>;
  isAddedToLP: any;
  roleList: fromRoleAccessStore.IroleData;
  isPageLoading: boolean;
  constructor(
    private route: ActivatedRoute,
    private pdetailsPageService: PdetailsPageService,
    private contentAddedCheckService: ContentAddedCheckService,
    private _popup: MatDialog,
    private router: Router,
    private userRoleAccessStore: Store<fromRoleAccessStore.IRoleReducerState>
  ) {
    this.isAddedToLP = false;
    this.isPageLoading = true;
  }

  subscribeToRouteParams() {
    this.route.params.subscribe(params => {
      this.loadOnPageLoad();
    });
  }
  ngOnInit() {
    this.subscribeToRouteParams();
  }
  loadOnPageLoad() {
    this.uniqueId = this.route.snapshot.params['uniqueId'];
    this.accountPackage = this.route.snapshot.params['accountPackage'];
    this.projectPackage = this.route.snapshot.params['projectPackage'];
    this.accountId = this.route.snapshot.params['accountId'];
    this.projectId = this.route.snapshot.params['projectId'];
    this.itemType = this.route.snapshot.params['itemType'];
    this.expertise = this.route.snapshot.params['expertise'];
    this.id = this.route.snapshot.params['id'];

    //get the roles
    this.userRoleAccessStore
      .select(fromRoleAccessStore.getRoleAccessList)
      .subscribe(roleList => {
        this.roleList = roleList;
      });
    let payload;
    payload = {
      ItemId: this.uniqueId,
      AccountPackage: this.accountPackage,
      ProjectPackage: this.projectPackage,
      AccountId: this.accountId,
      ProjectId: this.projectId
    };
    //get course/package details fro account/project
    this.pdetailsPageService
      .getPPackageDetails(payload, this.itemType)
      .subscribe(
        res => {
          this.contentDetails = res;
          if (this.contentDetails !== null && !this.contentDetails.IsHidden) {
            // get content details for course
            if (this.itemType === 'Course') {
              this.pdetailsPageService
                .getPPContentofCourse(payload)
                .subscribe(data => {
                  this.contentCDetails = data.packages;
                  this.isPageLoading = false;
                });
            }
            // get content details for package
            if (this.itemType === 'FamilyPackage') {
              this.pdetailsPageService
                .getPPContentofPackage(payload)
                .subscribe(data => {
                  this.contentPDetails = data.Courses;
                  this.isPageLoading = false;
                });
            }
          } else {
            this.isPageLoading = false;
          }
        },
        error => {}
      );
  }
  isCardAddedToLP() {
    this.contentAddedCheckService
      .IsContentAddedToLP(this.contentDetails)
      .then(response => {
        if (response) {
          this.isAddedToLP = true;
        }
      });
  }
  openDialog() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.panelClass = 'popupDialogContainer';

    dialogConfig.data = {
      contentName: this.contentDetails.Name,
      Id: this.uniqueId,
      ItemType: this.itemType,
      uniqueId: this.contentDetails.UniqueId,
      accountId: this.contentDetails.Account,
      projectId: this.contentDetails.Project,
      AccountPackage: this.contentDetails.AccountPackage,
      ProjectPackage: this.contentDetails.ProjectPackage,
      Title: this.contentDetails.Name,
      skillProfile: {},
      addedLocation: 'Details-Page'
    };

    this._popup.open(AddPopupComponent, dialogConfig);
  }
  goToBrowsePage(accoundId, projectId) {
    //console.log(accoundId, projectId);
    const url = '/browse/accountsAndProjects/' + accoundId + '/' + projectId;
    this.router.navigate([url]);
  }
  stopPropagation(event) {
    event.stopPropagation();
  }
}
