import { PdetailsPageModule } from './pdetails-page.module';

describe('PdetailsPageModule', () => {
  let pdetailsPageModule: PdetailsPageModule;

  beforeEach(() => {
    pdetailsPageModule = new PdetailsPageModule();
  });

  it('should create an instance', () => {
    expect(pdetailsPageModule).toBeTruthy();
  });
});
