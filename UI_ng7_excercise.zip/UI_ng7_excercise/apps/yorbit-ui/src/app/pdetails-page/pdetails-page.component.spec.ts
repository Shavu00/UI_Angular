import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PdetailsPageComponent } from './pdetails-page.component';

describe('PdetailsPageComponent', () => {
  let component: PdetailsPageComponent;
  let fixture: ComponentFixture<PdetailsPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PdetailsPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PdetailsPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
