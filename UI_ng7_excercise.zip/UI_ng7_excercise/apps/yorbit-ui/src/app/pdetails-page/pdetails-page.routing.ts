import { NgModule } from "@angular/core";
import { Routes, RouterModule } from '@angular/router';
import { PdetailsPageComponent } from './pdetails-page.component';

const routes: Routes = [
  { path: ":uniqueId/:accountPackage/:projectPackage/:accountId/:projectId/:itemType/:expertise/:id", component: PdetailsPageComponent},

];

@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes)]
})
export class DetailsPageRoutingModule { }
