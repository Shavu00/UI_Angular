import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PdetailsPageComponent } from './pdetails-page.component';

import { DetailsPageRoutingModule } from './pdetails-page.routing';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ReusableUiModule } from '@YorbitWorkspace/reusable-ui';
import { ContentTilesModule } from '../shared/content-tiles/content-tiles.module';
import { AccordionModule } from '../shared/accordion/accordion.module';
import { PdetailsPageCourseModule } from './pdetails-page-course/pdetails-page-course.module';
import { DetailsPagePackageModule } from '../details-page/details-page-package/details-page-package.module';
import { YammerModule } from '../shared/yammer/yammer.module';
import { CardFeatureModule } from '../shared/card-feature/card-feature.module';
import { DetailsPageYammerModule } from '../details-page/details-page-yammer/details-page-yammer.module';
import { MobileCourseDetailsPageModule } from '../details-page/mobile-course-details-page/mobile-course-details-page.module';
import { MobilePackageDetailsPageModule } from '../details-page/mobile-package-details-page/mobile-package-details-page.module';

@NgModule({
  imports: [
    CommonModule,
    DetailsPageRoutingModule,
    FlexLayoutModule,
    ReusableUiModule,
    ContentTilesModule,
    AccordionModule,
    PdetailsPageCourseModule,
    DetailsPagePackageModule,
    YammerModule,
    CardFeatureModule,
    DetailsPageYammerModule,
    MobileCourseDetailsPageModule,
    MobilePackageDetailsPageModule
  ],
  declarations: [PdetailsPageComponent]
})
export class PdetailsPageModule {}
