export interface INotifications {
    Payload?:Payload;
    AllNotifications?:NotificationEntities;
    NewNotificationsLoading?:boolean;
    NewNotificationsLoadedSuccesfully?:boolean;
    OldNotificationsLoading?:boolean;
    OldNotificationsLoadedSuccesfully?:boolean;
}
export interface Payload{
    AdminMessageCollection?:NotificationsCollection[];
    BellResultCollection?:NotificationsCollection[];
    CommonMessageCollection?:NotificationsCollection[];
}
export interface NotificationEntities{
    [Id:number]:NotificationsCollection
}
export interface NotificationsCollection{
    Category: string ;
    CreatedDate: string | Date ;
    CreatedDate_Master:string | Date;
    DesktopLink:string;
    Id: string|number;
    IsActioned: boolean;
    IsSeen: boolean;
    MId: string;
    Message:string;
    MobileLink: string;
};
export interface NotificationsCollection{
    ACMorPCMName: null |string;
    Academy: string;
    ActionedByName: null;
    Category: string;
    CertificationStatus: null|string;
    CourseId: number|string ;
    CreatedDate: string|Date;
    Expertise: string;
    Genre: string;
    Id: number|string;
    IsACMPCMAssigned: boolean;
    IsActioned: boolean;
    IsSeen: boolean;
    ItemType: null|string;
    MId:string;
    MessageTemplate: string;
    Name: string;
    PackageExpertise: null |string;
    PackageId: number|string;
    PackageName: null|string;
    PackageUniqueId: null|string|number;
    Reason: null|string;
    SharedBy: null| string;
    Skill: string;
    TemplateId: number|string;
    UniqueId:string;
    UnitCourseId: null|string|number;
    UnitExpertise: null|string;
    UnitId: number|string;
    UnitName: null|string;
    UnitUniqueId: null|string|number;
    WorkflowStatus: string;
}
export interface NotificationsCollection{
    Category: string;
    CreatedDate: string|Date;
    CreatedDate_Master: string|Date;
    DesktopLink: null |string;
    IsActioned: boolean;
    IsSeen: boolean;
    MId: string;
    Message: string;
    MessageId: number|string;
    MobileLink: null|string;
}