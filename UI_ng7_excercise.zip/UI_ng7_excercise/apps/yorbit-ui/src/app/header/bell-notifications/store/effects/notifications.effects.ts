import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';
import { HttpClient } from '@angular/common/http';
import { BellNotificationService } from '../../bell-notifications.service';
import { switchMap, catchError, map } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import * as NotificationsActions from '../actions/notifications.actions';
@Injectable()
export class NotificationsEffects {
  constructor(
    private actions$: Actions,
    private bellNotificationService$: BellNotificationService
  ) {}
  @Effect()
  getNewNotifications$ = this.actions$.ofType('GET_NEW_NOTIFICATIONS').pipe(
    map((action: NotificationsActions.GetNewNotifications) => action.payload),
    switchMap(payload => {
      return this.bellNotificationService$
        .getOldNotificationsFromDB(payload, false)
        .pipe(
          map(res => {
            return new NotificationsActions.GetNewNotificationsSuccess(res);
          }),
          catchError(error =>
            of(new NotificationsActions.GetNewNotificationsFailure())
          )
        );
    })
  );

  @Effect()
  getOldNotifications$ = this.actions$.ofType('GET_OLD_NOTIFICATIONS').pipe(
    map((action: NotificationsActions.GetOldNotifications) => action.payload),
    switchMap(payload => {
      return this.bellNotificationService$
        .getOldNotificationsFromDB(payload, true)
        .pipe(
          map(res => {
            return new NotificationsActions.GetOldNotificationsSuccess(res);
          }),
          catchError(error =>
            of(new NotificationsActions.GetOldNotificationsFailure())
          )
        );
    })
  );
}
