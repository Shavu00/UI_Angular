import { Component, OnInit, Output, Input, Inject, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { HeaderService } from './header.service';
import { AccountService } from '../account/account.service';
import * as fromRoleAccessStore from '@YorbitWorkspace/role-access';
import { Store } from '@ngrx/store';
import { DomSanitizer } from '@angular/platform-browser';
import * as fromMyPageStore from '../my-page/store';
import { AuthService } from '@YorbitWorkspace/auth';
import { AdalService } from 'adal-angular4';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { HeaderPopupComponent } from './header-popup/header-popup.component';
import { EnvironmentService } from '@YorbitWorkspace/global-environments';
import { WINDOW } from '../shared/services/window.service';

@Component({
  selector: 'yorbit-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @Output() openSideNav: EventEmitter<any> = new EventEmitter();
  @Input('id') id: any;
  public search: any;
  public searchClicked = false;
  public hideSearchIcon = false;
  public disableOthers = false;
  public preloaderForSearch = false;
  userImageFromGraphDetails: any;
  yorbitPoints: number | string;
  roleList: fromRoleAccessStore.IroleData;
  complianceStatus: string;
  isCompliant: boolean;
  accountAndProjectList: any;
  constructor(
    private router: Router,
    private _envService: EnvironmentService,
    private headerService: HeaderService,
    private appStore: Store<any>,
    private domSanitizer: DomSanitizer,
    private myPageStore: Store<fromMyPageStore.IMyPageReducerState>,
    private accountService: AccountService,
    private userRoleAccessStore: Store<fromRoleAccessStore.IRoleReducerState>,
    //private myPageStore: Store<fromMyPageStore.IMyPageReducerState>,
    private adalService: AdalService,
    private _popup: MatDialog,
    private changeDetectorRef: ChangeDetectorRef,
    @Inject(WINDOW) private _window: Window
  ) {
    this.search = '';
    this.userImageFromGraphDetails = null;
    this.yorbitPoints = 0;
    this.accountAndProjectList = [];
  }

  ngOnInit() {
    this.loadUserYorbitProfile();
    //get the roles
    this.userRoleAccessStore
      .select(fromRoleAccessStore.getRoleAccessList)
      .subscribe(roleList => {
        this.roleList = roleList;
      });
    this.getCompliance();
    this.getAdminRoles();
    //get account and projects list
    this.accountService.getUsersAccountAndProjectList().subscribe(list => {
      if(list)list.sort(this.sortByAccountName);
      this.headerService.saveAccountData(list);
      this.accountAndProjectList = list;
    });
  }
  getAdminRoles() {
    this.userRoleAccessStore
      .select(fromRoleAccessStore.getRoleAccessList)
      .subscribe(roleList => {
        this.roleList = roleList;
      });
  }
  loadUserYorbitProfile() {
    this.appStore.select('Graph').subscribe(graphDetails => {
      if (graphDetails.loaded && graphDetails.userGraphInfo.user_image.size != 0 && this.userImageFromGraphDetails == null) {
        this.userImageFromGraphDetails = this.domSanitizer.bypassSecurityTrustUrl(
          this._window.URL.createObjectURL(graphDetails.userGraphInfo.user_image)
        );
        this.changeDetectorRef.detectChanges();
      }
    });
    this.appStore.select('userDetails').subscribe(userDetails => {
      if (userDetails.user.loaded) {
        this.yorbitPoints = userDetails.user.data.Achievements.Points;
      }
    });
  }
  keyDownFunction(event) {
    if (event.keyCode === 13) {
      this.doSearch();
    }
  }
  inputChanged(event) {
    if (event === '') {
      this.hideSearchIcon = false;
    } else {
      this.hideSearchIcon = true;
    }
    setTimeout(() => {
      this.hideSearchIcon = false;
    }, 1000);
  }
  doSearch() {
    if (this.search != null && this.search !== '') {
      this.preloaderForSearch = true;
      let data;
      data = {
        searchKey: this.search
      };
      this.searchClicked = true;
      this.hideSearchIcon = true;
      this.router.navigate(['search/' + this.search]).then(
        nav => {
          this.search = '';
          this.hideSearchIcon = false;
          this.preloaderForSearch = false;
        },
        err => {
        }
      );
      // this.headerService.getSearchData(data).subscribe(
      //   res => {
      //     debugger;
      //     const results = res;
      //     //save search results in service
      //     this.headerService.saveSearchedData(this.search, results);
      //     //after getting results go to search page
      //   },
      //   error => {
      //     debugger;
      //   }
      // );
    }
  }

  getCompliance() {
    this.myPageStore.select(fromMyPageStore.getMyPageCompliance).subscribe(
      data => {
        this.complianceStatus = data.ComplianceStatus;
        if (this.complianceStatus.toLowerCase() === 'non-compliant') {
          this.isCompliant = false;
        } else {
          this.isCompliant = true;
        }
      },
      error => { }
    );
  }
  openProjectCaselets() {
    var url = this._envService.getEnvironment().appUrl;
    window.open(url + 'projectcaselets', '_blank');
  }
  goToAccountPage() {
    this.router.navigate(['account/', this.accountAndProjectList[0].AccountId]);
  }
  sortByAccountName(a, b) {
    const nameA = a.AccountId.toLowerCase(),
      nameB = b.AccountId.toLowerCase();
    if (nameA < nameB)
      //sort string ascending
      return -1;
    if (nameA > nameB) return 1;
    return 0; //default return value (no sorting)
  }
  logOut() {
    this.adalService.logOut();
  }
  openPopup() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.panelClass = 'popupDialogContainer';
    dialogConfig.data = {};
    const response = this._popup.open(HeaderPopupComponent, dialogConfig);
    response.afterClosed().subscribe(res => {
      //console.log('response from header pop up', res);
      if (res.data === 'Yes') {
        this.router.navigate(['iCertificationUpload']);
      } else if (res.data === 'No') {
        this.router.navigate(['eCertificationUpload']);
      }
    });
  }
}
