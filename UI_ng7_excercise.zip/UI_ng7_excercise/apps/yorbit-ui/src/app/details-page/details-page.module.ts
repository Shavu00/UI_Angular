import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DetailsPageRoutingModule } from './details-page.routing';
import { DetailsPageComponent } from './details-page.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ReusableUiModule } from '@YorbitWorkspace/reusable-ui';
import { ContentTilesModule } from '../shared/content-tiles/content-tiles.module'
import { AccordionModule } from '../shared/accordion/accordion.module'
import { DetailsPageCourseModule } from './details-page-course/details-page-course.module';
import { DetailsPagePackageModule } from './details-page-package/details-page-package.module';
import { RatingAndCommentsModule } from './rating-and-comments/rating-and-comments.module';
import { DetailsPageYammerModule } from './details-page-yammer/details-page-yammer.module';
import { CardFeatureModule } from '../shared/card-feature/card-feature.module';
import { MobileCourseDetailsPageModule } from './mobile-course-details-page/mobile-course-details-page.module';
import { MobilePackageDetailsPageModule } from './mobile-package-details-page/mobile-package-details-page.module';
import { PipesModule } from '@YorbitWorkspace/pipes';
import { MatIconModule } from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    DetailsPageRoutingModule,

    MatIconModule,

    FlexLayoutModule,
    ReusableUiModule,
    ContentTilesModule,
    AccordionModule,
    DetailsPageCourseModule,
    DetailsPagePackageModule,
    RatingAndCommentsModule,
    DetailsPageYammerModule,
    CardFeatureModule,
    MobileCourseDetailsPageModule,
    MobilePackageDetailsPageModule,
    PipesModule
  ],
  declarations: [DetailsPageComponent]
})
export class DetailsPageModule { }
