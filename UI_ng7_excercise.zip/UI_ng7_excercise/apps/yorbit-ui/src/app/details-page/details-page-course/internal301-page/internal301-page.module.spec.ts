import { Internal301PageModule } from './internal301-page.module';

describe('Internal301PageModule', () => {
  let internal301PageModule: Internal301PageModule;

  beforeEach(() => {
    internal301PageModule = new Internal301PageModule();
  });

  it('should create an instance', () => {
    expect(internal301PageModule).toBeTruthy();
  });
});
