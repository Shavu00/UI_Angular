import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsPageCourseComponent } from './details-page-course.component';

describe('DetailsPageCourseComponent', () => {
  let component: DetailsPageCourseComponent;
  let fixture: ComponentFixture<DetailsPageCourseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailsPageCourseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailsPageCourseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
