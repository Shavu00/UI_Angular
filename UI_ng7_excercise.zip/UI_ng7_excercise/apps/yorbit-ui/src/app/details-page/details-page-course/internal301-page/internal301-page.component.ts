import { Component, OnInit, Input } from '@angular/core';
import * as fromRoleAccessStore from '@YorbitWorkspace/role-access';
import { Store } from '@ngrx/store';
import { DetailsPageService } from '../../details-page.service';

@Component({
  selector: 'yorbit-internal301-page',
  templateUrl: './internal301-page.component.html',
  styleUrls: ['./internal301-page.component.scss']
})
export class Internal301PageComponent implements OnInit {
  public projectDetailsFor301: Array<Object>;
  public preparatoryCoursePackage: Array<Object>;
  public prerequisiteCourse: Array<Object>;
  roleList: fromRoleAccessStore.IroleData;
  @Input('contentDetails') contentDetails;
  constructor(
    private detailsPageService: DetailsPageService,
    private userRoleAccessStore: Store<fromRoleAccessStore.IRoleReducerState>
  ) {
    this.projectDetailsFor301 = [];
    this.preparatoryCoursePackage = [];
    this.prerequisiteCourse = [];
  }

  ngOnInit() {
    // format the social count
    this.contentDetails.TotalUsers = this.detailsPageService.CountFormatter(
      this.contentDetails.TotalUsers
    );
    this.contentDetails.TotalShares = this.detailsPageService.CountFormatter(
      this.contentDetails.TotalShares
    );
    this.contentDetails.TotalExperts = this.detailsPageService.CountFormatter(
      this.contentDetails.TotalExperts
    );
    //get the roles
    this.userRoleAccessStore
      .select(fromRoleAccessStore.getRoleAccessList)
      .subscribe(roleList => {
        this.roleList = roleList;
      });
    //get projects for 301 course
    this.detailsPageService
      .getProjectsFor301Course(this.contentDetails.UniqueId)
      .subscribe(project => {
        this.projectDetailsFor301 = project;
      });
    //get preparatory course details
    if (
      this.contentDetails.PrePreperatoryCourses !== undefined &&
      this.contentDetails.PrePreperatoryCourses.length !== 0
    ) {
      this.contentDetails.PrePreperatoryCourses.forEach(element => {
        this.detailsPageService
          .getPackageDetails(element, 'Course')
          .subscribe(cDetails => {
            this.preparatoryCoursePackage.push(cDetails);
          });
      });
    }
    //get preparatory package details
    if (
      this.contentDetails.PrePreperatoryCourses !== undefined &&
      this.contentDetails.PrePreperatoryPackages.length !== 0
    ) {
      this.contentDetails.PrePreperatoryPackages.forEach(element => {
        this.detailsPageService
          .getPackageDetails(element, 'FamilyPackage')
          .subscribe(pDetails => {
            this.preparatoryCoursePackage.push(pDetails);
          });
      });
    }
    //get prerequisite course details
    if (
      this.contentDetails.PreRequisiteCourses != null &&
      this.contentDetails.PreRequisiteCourses.length !== 0
    ) {
      this.contentDetails.PreRequisiteCourses.forEach(element => {
        this.detailsPageService
          .getPackageDetails(element.courseId, 'Course')
          .subscribe(preDetails => {
            if (preDetails !== null) {
              this.prerequisiteCourse.push(preDetails);
            }
          });
      });
    }
  }
}
