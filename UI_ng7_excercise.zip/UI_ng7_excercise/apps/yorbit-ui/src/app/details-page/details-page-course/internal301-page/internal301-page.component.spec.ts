import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Internal301PageComponent } from './internal301-page.component';

describe('Internal301PageComponent', () => {
  let component: Internal301PageComponent;
  let fixture: ComponentFixture<Internal301PageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Internal301PageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Internal301PageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
