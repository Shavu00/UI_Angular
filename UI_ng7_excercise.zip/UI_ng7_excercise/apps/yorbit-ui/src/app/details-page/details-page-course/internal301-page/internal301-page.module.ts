import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AccordionModule } from '../../../shared/accordion/accordion.module'
import { ContentTilesModule } from '../../../shared/content-tiles/content-tiles.module'
import { CardFeatureModule } from '../../../shared/card-feature/card-feature.module'
import { Internal301PageComponent } from './internal301-page.component';
import { LinkyModule } from 'angular-linky';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    AccordionModule,
    ContentTilesModule,
    CardFeatureModule,
    LinkyModule
  ],
  declarations: [Internal301PageComponent],
  exports:[Internal301PageComponent]
})
export class Internal301PageModule { }
