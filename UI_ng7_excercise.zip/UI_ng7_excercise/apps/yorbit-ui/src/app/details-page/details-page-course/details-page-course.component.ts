import { Component, OnInit, Input, OnChanges } from '@angular/core';
import * as fromRoleAccessStore from '@YorbitWorkspace/role-access';
import { Store } from '@ngrx/store';

import { DetailsPageService } from '../../details-page/details-page.service';
import { Video } from '../mobile-course-details-page/mobile-course-details-page.component';
import { PlayerVarsIntroVideo } from '../../shared/video-players/o365-video-player/o365-player.config';
import { ContentAddedCheckService } from '../../shared/services/content-added-check.service';

@Component({
  selector: 'yorbit-details-page-course',
  templateUrl: './details-page-course.component.html',
  styleUrls: ['./details-page-course.component.scss']
})
export class DetailsPageCourseComponent implements OnInit, OnChanges {
  @Input('contentDetails') contentDetails;
  @Input('unitDetails') unitDetails;
  @Input('introVideoUrl') introVideoUrl;
  @Input('itemType') itemType;
  @Input('expertise') expertise;
  videoConfig: Video;
  roleList: fromRoleAccessStore.IroleData;
  isEnlargeImage: boolean;
  isAddedToLP: boolean;
  listOfPrerequsite: any;
  constructor(
    private detailsPageService: DetailsPageService,
    private userRoleAccessStore: Store<fromRoleAccessStore.IRoleReducerState>,
    private contentAddedCheckService: ContentAddedCheckService
  ) {
    this.listOfPrerequsite = [];
  }
  ngOnChanges(changeObj) {
    if (
      this.contentDetails.ItemType === 'Course' &&
      this.contentDetails.Expertise === '101' &&
      this.contentDetails.Internal &&
      this.introVideoUrl !== undefined
    ) {
      //check for add
      this.isCardAddedToLP();
      //get pre-requisite courses
      this.getPreRequisite();
      let videoId;
      if (this.introVideoUrl.SourceType === 'YouTube') {
        videoId = this.introVideoUrl.SourceUrl.split('embed/')[1];
      } else if (this.introVideoUrl.SourceType === 'O365') {
        videoId = this.introVideoUrl.UniqueId;
      }
      if (changeObj['introVideoUrl']) {
        const data = {
          ContentId: this.introVideoUrl.Id,
          UnitId: this.introVideoUrl.UnitId,
          CourseId: this.contentDetails.Id,
          ItemId: this.contentDetails.Id,
          ItemType: this.contentDetails.ItemType,
          PathId: 0,
          VideoId: videoId,
          sourceUrl: this.introVideoUrl.SourceUrl
        };
        this.videoConfig = {
          VideoDetails: data,
          VideoPlayerId: 'IntroVideo' + videoId,
          CanCaptureProgress: this.isAddedToLP,
          PlayerVars: PlayerVarsIntroVideo,
          showInfoMsg: false
        };
      }
    } else {
    }
  }
  ngOnInit() {
    //check for add
    this.isCardAddedToLP();
    //get pre-requisite courses
    this.getPreRequisite();
    this.isEnlargeImage = false;
    //get the roles
    this.userRoleAccessStore
      .select(fromRoleAccessStore.getRoleAccessList)
      .subscribe(roleList => {
        this.roleList = roleList;
      });
    // format the social count
    this.contentDetails.TotalUsers = this.detailsPageService.CountFormatter(
      this.contentDetails.TotalUsers
    );
    this.contentDetails.TotalShares = this.detailsPageService.CountFormatter(
      this.contentDetails.TotalShares
    );
    this.contentDetails.TotalExperts = this.detailsPageService.CountFormatter(
      this.contentDetails.TotalExperts
    );
  }
  isCardAddedToLP() {
    this.contentAddedCheckService
      .IsContentAddedToLP(this.contentDetails)
      .then(response => {
        //console.log(response);
        if (response) {
          this.isAddedToLP = true;
        } else {
          this.isAddedToLP = false;
        }
      });
  }
  getPreRequisite() {
    this.listOfPrerequsite = [];
    if (
      this.contentDetails.PreRequisiteCourses !== null &&
      this.contentDetails.PreRequisiteCourses.length !== 0
    ) {
      this.contentDetails.PreRequisiteCourses.forEach(element => {
        this.detailsPageService
          .getPackageDetails(element.courseId, 'Course')
          .subscribe(pre => {
            //console.log(pre);
            if (pre !== null && !pre.IsHidden) {
              this.listOfPrerequsite.push(pre);
            }
          });
      });
    }
  }
}
