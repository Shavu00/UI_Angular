import { DetailsPageCourseModule } from './details-page-course.module';

describe('DetailsPageCourseModule', () => {
  let detailsPageCourseModule: DetailsPageCourseModule;

  beforeEach(() => {
    detailsPageCourseModule = new DetailsPageCourseModule();
  });

  it('should create an instance', () => {
    expect(detailsPageCourseModule).toBeTruthy();
  });
});
