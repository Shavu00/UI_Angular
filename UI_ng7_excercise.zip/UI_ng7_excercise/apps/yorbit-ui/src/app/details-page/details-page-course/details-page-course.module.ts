import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ContentTilesModule } from '../../shared/content-tiles/content-tiles.module'
import { AccordionModule } from '../../shared/accordion/accordion.module'
import { VideoPlayersModule } from '../../shared/video-players/video-players.module';
import { DetailsPageCourseComponent } from './details-page-course.component';
import { Internal301PageModule } from './internal301-page/internal301-page.module';
import { CardFeatureModule } from '../../shared/card-feature/card-feature.module'
import { LinkyModule } from 'angular-linky';
import { MatExpansionModule } from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    MatExpansionModule,

    AccordionModule,
    VideoPlayersModule,
    Internal301PageModule,
    ContentTilesModule,
    CardFeatureModule,
    LinkyModule
  ],
  declarations: [DetailsPageCourseComponent],
  exports:[DetailsPageCourseComponent]
})
export class DetailsPageCourseModule { }
