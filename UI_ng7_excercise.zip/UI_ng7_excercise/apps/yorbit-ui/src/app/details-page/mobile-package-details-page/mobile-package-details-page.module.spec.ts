import { MobilePackageDetailsPageModule } from './mobile-package-details-page.module';

describe('MobilePackageDetailsPageModule', () => {
  let mobilePackageDetailsPageModule: MobilePackageDetailsPageModule;

  beforeEach(() => {
    mobilePackageDetailsPageModule = new MobilePackageDetailsPageModule();
  });

  it('should create an instance', () => {
    expect(mobilePackageDetailsPageModule).toBeTruthy();
  });
});
