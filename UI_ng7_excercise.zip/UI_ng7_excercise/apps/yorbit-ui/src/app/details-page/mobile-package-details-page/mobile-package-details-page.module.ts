import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AccordionModule } from '../../shared/accordion/accordion.module';
import { ContentTilesModule } from '../../shared/content-tiles/content-tiles.module'
import { VideoPlayersModule } from '../../shared/video-players/video-players.module';
import { LinkyModule } from 'angular-linky';
import { MobilePackageDetailsPageComponent } from './mobile-package-details-page.component';
import { MatExpansionModule } from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,

    MatExpansionModule,

    AccordionModule,
    ContentTilesModule,
    VideoPlayersModule,
    LinkyModule
  ],
  declarations: [MobilePackageDetailsPageComponent],
  exports: [MobilePackageDetailsPageComponent]
})
export class MobilePackageDetailsPageModule { }
