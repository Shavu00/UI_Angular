import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MobilePackageDetailsPageComponent } from './mobile-package-details-page.component';

describe('MobilePackageDetailsPageComponent', () => {
  let component: MobilePackageDetailsPageComponent;
  let fixture: ComponentFixture<MobilePackageDetailsPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MobilePackageDetailsPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MobilePackageDetailsPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
