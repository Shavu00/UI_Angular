import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { Video } from '../mobile-course-details-page/mobile-course-details-page.component';
import { PlayerVarsIntroVideo } from '../../shared/video-players/o365-video-player/o365-player.config';
import { ContentAddedCheckService } from '../../shared/services/content-added-check.service';

@Component({
  selector: 'yorbit-mobile-package-details-page',
  templateUrl: './mobile-package-details-page.component.html',
  styleUrls: ['./mobile-package-details-page.component.scss']
})
export class MobilePackageDetailsPageComponent implements OnInit, OnChanges {
  @Input('contentDetails') contentDetails;
  @Input('courseDetails') courseDetails;
  @Input('introVideoUrl') introVideoUrl;
  videoConfig: Video;
  panelOpenState: boolean;
  isAddedToLP: boolean;
  constructor(private contentAddedCheckService: ContentAddedCheckService) {}
  ngOnChanges(changeObj) {
    //check for add
    this.isCardAddedToLP();
    let videoId;
    if (
      this.introVideoUrl !== undefined &&
      this.introVideoUrl !== null &&
      this.introVideoUrl.SourceType !== undefined &&
      this.introVideoUrl.SourceType === 'YouTube'
    ) {
      videoId = this.introVideoUrl.SourceUrl.split('embed/')[1];
    } else if (
      this.introVideoUrl !== undefined &&
      this.introVideoUrl !== null &&
      this.introVideoUrl.SourceType !== undefined &&
      this.introVideoUrl.SourceType === 'O365'
    ) {
      videoId = this.introVideoUrl.UniqueId;
    }
    if (this.introVideoUrl !== undefined) {
      if (this.introVideoUrl !== null) {
        if (changeObj['introVideoUrl']) {
          const data = {
            ContentId: this.introVideoUrl.Id,
            UnitId: this.introVideoUrl.UnitId,
            CourseId: this.contentDetails.Id,
            ItemId: this.contentDetails.Id,
            ItemType: this.contentDetails.ItemType,
            PathId: 0,
            VideoId: videoId,
            sourceUrl: this.introVideoUrl.SourceUrl
          };
          this.videoConfig = {
            VideoDetails: data,
            CanCaptureProgress: this.isAddedToLP,
            VideoPlayerId: 'IntroVideo' + videoId,
            PlayerVars: PlayerVarsIntroVideo,
            showInfoMsg: false
          };
        }
      }
    }
  }
  ngOnInit() {}
  isCardAddedToLP() {
    this.contentAddedCheckService
      .IsContentAddedToLP(this.contentDetails)
      .then(response => {
        //console.log(response);
        if (response) {
          this.isAddedToLP = true;
        } else {
          this.isAddedToLP = false;
        }
      });
  }
}
