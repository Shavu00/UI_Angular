import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AccordionModule } from '../../shared/accordion/accordion.module';
import { ContentTilesModule } from '../../shared/content-tiles/content-tiles.module'
import { VideoPlayersModule } from '../../shared/video-players/video-players.module';
import { LinkyModule } from 'angular-linky';
import { MobileCourseDetailsPageComponent } from './mobile-course-details-page.component';
import { MatExpansionModule } from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,

    MatExpansionModule,

    VideoPlayersModule,
    AccordionModule,
    ContentTilesModule,
    LinkyModule
  ],
  declarations: [MobileCourseDetailsPageComponent],
  exports: [MobileCourseDetailsPageComponent]
})
export class MobileCourseDetailsPageModule { }
