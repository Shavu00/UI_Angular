import { Component, OnInit, Input, OnChanges } from '@angular/core';

import { DetailsPageService } from './../details-page.service';
import { PlayerVarsIntroVideo } from '../../shared/video-players/o365-video-player/o365-player.config';
import { ContentAddedCheckService } from '../../shared/services/content-added-check.service';

export interface Video {
  VideoDetails: {
    ContentId: any;
    UnitId: any;
    CourseId: any;
    ItemId: any;
    ItemType: any;
    PathId: any;
    VideoId: any;
    sourceUrl: any;
  };
  VideoPlayerId: string;
  CanCaptureProgress: boolean;
  PlayerVars: any;
  showInfoMsg: boolean;
}
@Component({
  selector: 'yorbit-mobile-course-details-page',
  templateUrl: './mobile-course-details-page.component.html',
  styleUrls: ['./mobile-course-details-page.component.scss']
})
export class MobileCourseDetailsPageComponent implements OnInit, OnChanges {
  @Input('contentDetails') contentDetails;
  @Input('unitDetails') unitDetails;
  @Input('introVideoUrl') introVideoUrl;
  @Input('cloudDetails') cloudDetails;
  videoConfig: Video;
  panelOpenState: boolean;
  showOtherAccordian: boolean;
  prePreperatoryCoursesPackages: any;
  preRequisiteCourses: any;
  isEnlargeImage: boolean;
  isAddedToLP: boolean;
  constructor(
    private detailsPageService: DetailsPageService,
    private contentAddedCheckService: ContentAddedCheckService
  ) {
    this.showOtherAccordian = false;
    this.prePreperatoryCoursesPackages = [];
    this.preRequisiteCourses = [];
  }
  ngOnChanges(changeObj) {
    if (
      this.contentDetails.ItemType === 'Course' &&
      this.contentDetails.Expertise === '101' &&
      this.contentDetails.Internal
    ) {
      //check for add
      this.isCardAddedToLP();
      this.showOtherAccordian = true;
      let videoId;
      if (this.introVideoUrl !== undefined) {
        if (this.introVideoUrl.SourceType === 'YouTube') {
          videoId = this.introVideoUrl.SourceUrl.split('embed/')[1];
        } else if (this.introVideoUrl.SourceType === 'O365') {
          videoId = this.introVideoUrl.UniqueId;
        }
      }
      if (changeObj['introVideoUrl']) {
        const data = {
          ContentId: this.introVideoUrl.Id,
          UnitId: this.introVideoUrl.UnitId,
          CourseId: this.contentDetails.Id,
          ItemId: this.contentDetails.Id,
          ItemType: this.contentDetails.ItemType,
          PathId: 0,
          VideoId: videoId,
          sourceUrl: this.introVideoUrl.SourceUrl
        };
        this.videoConfig = {
          VideoDetails: data,
          CanCaptureProgress: this.isAddedToLP,
          VideoPlayerId: 'IntroVideo' + videoId,
          PlayerVars: PlayerVarsIntroVideo,
          showInfoMsg: false
        };
      }
    } else {
      if (
        this.contentDetails.ItemType === 'Course' &&
        this.contentDetails.Expertise === '101' &&
        !this.contentDetails.Internal
      ) {
        this.showOtherAccordian = true;
      } else if (
        this.contentDetails.ItemType === 'Course' &&
        this.contentDetails.Expertise === '201' &&
        ((this.contentDetails.Assessment === 'true' &&
          this.contentDetails.AssessmentDescription !== '') ||
          (this.contentDetails.Assignment === 'true' &&
            this.contentDetails.AssignmentDescription !== '') ||
          (this.contentDetails.Classroom === 'true' &&
            this.contentDetails.ClassroomDescription !== '') ||
          (this.contentDetails.ELearning === 'true' &&
            this.contentDetails.ELearningDescription !== '') ||
          (this.contentDetails.ProjectWork === 'true' &&
            this.contentDetails.ProjectWorkDescription !== ''))
      ) {
        this.showOtherAccordian = true;
      } else {
        this.showOtherAccordian = false;
      }
    }
  }
  ngOnInit() {
    this.isEnlargeImage = false;
    //get pre-preperatory courses and packages
    if (
      this.contentDetails.PrePreperatoryCourses !== undefined &&
      this.contentDetails.PrePreperatoryCourses !== null
    ) {
      this.contentDetails.PrePreperatoryCourses.forEach(element => {
        this.detailsPageService
          .getPackageDetails(element.Id, element.ItemType)
          .subscribe(res => {
            this.prePreperatoryCoursesPackages.push(res);
          });
      });
    }
    //get pre-requisite courses
    if (this.contentDetails.PreRequisiteCourses !== null) {
      this.contentDetails.PreRequisiteCourses.forEach(element => {
        this.detailsPageService
          .getPackageDetails(element.courseId, 'Course')
          .subscribe(res => {
            this.preRequisiteCourses.push(res);
          });
      });
    }
  }
  isCardAddedToLP() {
    this.contentAddedCheckService
      .IsContentAddedToLP(this.contentDetails)
      .then(response => {
        //console.log(response);
        if (response) {
          this.isAddedToLP = true;
        } else {
          this.isAddedToLP = false;
        }
      });
  }
  goToDetailsPage(content) {
    let webLink, URL;
    //URL = 'https://yorbitst.azurewebsites.net/#/detailedpackagepage';
    URL = 'localhost:4200/detailsPage';
    if (content.ItemType === 'FamilyPackage' || content.ItemType === 'Course') {
      //for yorbit content
      if (content.AccountPackage == null) {
        // webLink =
        //   URL +
        //   '?type=' +
        //   content.ItemType +
        //   '&expertise=' +
        //   content.Expertise +
        //   '&id=' +
        //   content.Id;
        webLink =
          URL +
          '/' +
          content.ItemType +
          '/' +
          content.Expertise +
          '/' +
          content.Id;
      }
      //for account and project content
      else {
        if (content.AccountId === undefined) {
          content.AccountId = content.Account;
        }
        if (content.ProjectId === undefined) {
          content.ProjectId = content.Project;
        }
        if (
          content.AccountPackage === true ||
          content.AccountPackage === 'true'
        ) {
          content.ProjectId = '';
          content.AccountPackage = true;
          content.ProjectPackage = false;
        } else {
          content.AccountPackage = false;
          content.ProjectPackage = true;
        }
        content.UniqueId = content.Id;
        if (content.AccountPackage) {
          webLink =
            URL +
            '?UniqueId=' +
            content.UniqueId +
            '&AccountPackage=' +
            content.AccountPackage +
            '&ProjectPackage=' +
            content.ProjectPackage +
            '&AccountId=' +
            content.AccountId +
            '&type=' +
            content.ItemType +
            '&expertise=' +
            content.Expertise +
            '&id=' +
            content.Id;
        } else if (content.ProjectPackage) {
          webLink =
            URL +
            '?UniqueId=' +
            content.UniqueId +
            '&AccountPackage=' +
            content.AccountPackage +
            '&ProjectPackage=' +
            content.ProjectPackage +
            '&AccountId=' +
            content.AccountId +
            '&ProjectId=' +
            content.ProjectId +
            '&type=' +
            content.ItemType +
            '&expertise=' +
            content.Expertise +
            '&id=' +
            content.Id;
        }
      }
    } else if (content.ItemType === 'Unit') {
      if (content.AccountPackage || content.ProjectPackage) {
        if (
          content.AccountPackage == null ||
          content.AccountPackage === undefined
        ) {
          content.AccountPackage = false;
        }
        if (
          content.ProjectPackage == null ||
          content.ProjectPackage === undefined
        ) {
          content.ProjectPackage = false;
        }
        webLink =
          URL +
          '?UniqueId=' +
          content.CourseId +
          '&AccountPackage=' +
          content.AccountPackage +
          '&ProjectPackage=' +
          content.ProjectPackage +
          '&AccountId=' +
          content.Account +
          '&type=Course&expertise=' +
          content.Expertise +
          '&id=' +
          content.CourseId;
      } else {
        webLink =
          URL +
          '?type=Course&expertise=' +
          content.Expertise +
          '&id=' +
          content.CourseId;
      }
    } else if (content.ItemType === 'Video') {
      let videoData;
      videoData = {
        popupUrl: content.SourceUrl,
        popupVideoType: content.SourceType,
        contentId: content.Id,
        contentName: content.Name
      };
    }
    window.open(webLink, '_blank');
  }
}
