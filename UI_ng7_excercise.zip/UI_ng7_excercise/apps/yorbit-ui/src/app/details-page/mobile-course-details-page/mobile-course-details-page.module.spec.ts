import { MobileCourseDetailsPageModule } from './mobile-course-details-page.module';

describe('MobileCourseDetailsPageModule', () => {
  let mobileCourseDetailsPageModule: MobileCourseDetailsPageModule;

  beforeEach(() => {
    mobileCourseDetailsPageModule = new MobileCourseDetailsPageModule();
  });

  it('should create an instance', () => {
    expect(mobileCourseDetailsPageModule).toBeTruthy();
  });
});
