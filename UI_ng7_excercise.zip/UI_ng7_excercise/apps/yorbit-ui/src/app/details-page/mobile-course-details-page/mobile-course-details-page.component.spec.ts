import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MobileCourseDetailsPageComponent } from './mobile-course-details-page.component';

describe('MobileCourseDetailsPageComponent', () => {
  let component: MobileCourseDetailsPageComponent;
  let fixture: ComponentFixture<MobileCourseDetailsPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MobileCourseDetailsPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MobileCourseDetailsPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
