import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'yorbit-details-page-yammer',
  templateUrl: './details-page-yammer.component.html',
  styleUrls: ['./details-page-yammer.component.scss']
})
export class DetailsPageYammerComponent implements OnInit {
  @Input('contentDetails') contentDetails;
  constructor() { }

  ngOnInit() {
  }

}
