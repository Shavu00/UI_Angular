import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { YammerModule } from '../../shared/yammer/yammer.module';
import { DetailsPageYammerComponent } from './details-page-yammer.component';
import { MatIconModule } from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    MatIconModule,
    YammerModule
  ],
  declarations: [DetailsPageYammerComponent],
  exports:[DetailsPageYammerComponent]
})
export class DetailsPageYammerModule { }
