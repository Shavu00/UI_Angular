import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsPageYammerComponent } from './details-page-yammer.component';

describe('DetailsPageYammerComponent', () => {
  let component: DetailsPageYammerComponent;
  let fixture: ComponentFixture<DetailsPageYammerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailsPageYammerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailsPageYammerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
