import { DetailsPageYammerModule } from './details-page-yammer.module';

describe('DetailsPageYammerModule', () => {
  let detailsPageYammerModule: DetailsPageYammerModule;

  beforeEach(() => {
    detailsPageYammerModule = new DetailsPageYammerModule();
  });

  it('should create an instance', () => {
    expect(detailsPageYammerModule).toBeTruthy();
  });
});
