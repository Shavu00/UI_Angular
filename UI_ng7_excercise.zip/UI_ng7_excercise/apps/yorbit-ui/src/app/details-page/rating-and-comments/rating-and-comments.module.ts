import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReusableUiModule } from '@YorbitWorkspace/reusable-ui';
import { GraphModule } from '@YorbitWorkspace/graph';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RatingAndCommentsComponent } from './rating-and-comments.component';

@NgModule({
  imports: [
    CommonModule,
    ReusableUiModule,
    GraphModule,
    FlexLayoutModule
  ],
  declarations: [RatingAndCommentsComponent],
  exports:[RatingAndCommentsComponent]
})
export class RatingAndCommentsModule { }
