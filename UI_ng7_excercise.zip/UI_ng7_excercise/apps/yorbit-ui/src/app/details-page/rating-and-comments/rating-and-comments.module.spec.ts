import { RatingAndCommentsModule } from './rating-and-comments.module';

describe('RatingAndCommentsModule', () => {
  let ratingAndCommentsModule: RatingAndCommentsModule;

  beforeEach(() => {
    ratingAndCommentsModule = new RatingAndCommentsModule();
  });

  it('should create an instance', () => {
    expect(ratingAndCommentsModule).toBeTruthy();
  });
});
