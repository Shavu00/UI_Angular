import {
  Component,
  OnInit,
  Input,
  Inject,
  ViewChild,
  ElementRef
} from '@angular/core';
import { GraphDataService } from '@YorbitWorkspace/graph';
import { DomSanitizer } from '@angular/platform-browser';
import { WINDOW } from '../../shared/services/window.service';

@Component({
  selector: 'yorbit-rating-and-comments',
  templateUrl: './rating-and-comments.component.html',
  styleUrls: ['./rating-and-comments.component.scss']
})
export class RatingAndCommentsComponent implements OnInit {
  @Input('avgRating') avgRating;
  @ViewChild('userImage') image: ElementRef;
  limit: any = 0;
  usersFeedbackList: any;
  constructor(
    private graphService: GraphDataService,
    @Inject(WINDOW) private _window: Window,
    private sanitizer: DomSanitizer
  ) {
    this.usersFeedbackList = [];
  }

  ngOnInit() {
    //sort based on dates
    this.avgRating.courseFeedbackList.sort((a, b) => {
      return +new Date(b.createdDate) - +new Date(a.createdDate);
    });
    //sort based on comments
    const feedbacksWComments = this.avgRating.courseFeedbackList.filter(val => {
      return val.Comment !== '';
    });
    const feedbacksWOComments = this.avgRating.courseFeedbackList.filter(
      val => {
        return val.Comment === '';
      }
    );
    this.avgRating.courseFeedbackList = feedbacksWComments.concat(
      feedbacksWOComments
    );
    this.usersFeedbackList = this.avgRating.courseFeedbackList.slice(
      0,
      (this.limit + 1) * 7
    );
    //console.log('this.usersFeedbackList', this.usersFeedbackList);
    this.getGrpahDetails();
  }
  createImageURL(imageBlob: Blob) {
    const imageURL = this._window.URL.createObjectURL(imageBlob);
    return this.sanitizer.bypassSecurityTrustUrl(imageURL);
  }
  getGrpahDetails() {
    //to get user image and name
    this.usersFeedbackList.forEach(element => {
      //get user image
      this.graphService.getUserImage(element.Mid).subscribe(image => {
        element.Image = this.createImageURL(image);
      });
      //get user name
      this.graphService.getUserName(element.Mid).subscribe(data => {
        element.Name = data.value;
      });
    });
  }
  viewMoreComents() {
    this.limit = this.limit + 1;
    this.usersFeedbackList = [];
    this.usersFeedbackList = this.avgRating.courseFeedbackList.slice(
      this.limit * 7,
      (this.limit + 1) * 7
    );
    //console.log('this.usersFeedbackList', this.usersFeedbackList);
    this.getGrpahDetails();
  }
}
