import { NgModule } from "@angular/core";
import { Routes, RouterModule } from '@angular/router';
import { DetailsPageComponent } from './details-page.component';

const routes: Routes = [
  { path: ":itemType/:expertise/:id", component: DetailsPageComponent},

];

@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes)]
})
export class DetailsPageRoutingModule { }
