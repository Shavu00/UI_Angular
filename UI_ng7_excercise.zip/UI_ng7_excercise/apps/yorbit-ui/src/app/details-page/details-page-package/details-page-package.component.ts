import { Component, OnInit, Input, OnChanges } from '@angular/core';
import * as fromRoleAccessStore from '@YorbitWorkspace/role-access';
import { Store } from '@ngrx/store';
import { DetailsPageService } from '../../details-page/details-page.service';
import { Video } from '../mobile-course-details-page/mobile-course-details-page.component';
import { PlayerVarsIntroVideo } from '../../shared/video-players/o365-video-player/o365-player.config';
import { ContentAddedCheckService } from '../../shared/services/content-added-check.service';

@Component({
  selector: 'yorbit-details-page-package',
  templateUrl: './details-page-package.component.html',
  styleUrls: ['./details-page-package.component.scss']
})
export class DetailsPagePackageComponent implements OnInit, OnChanges {
  @Input('contentDetails') contentDetails;
  @Input('courseDetails') courseDetails;
  @Input('introVideoUrl') introVideoUrl;
  @Input('itemType') itemType;
  videoConfig: Video;
  roleList: fromRoleAccessStore.IroleData;
  noIntroVideo: boolean;
  isAddedToLP: boolean;
  constructor(
    private detailsPageService: DetailsPageService,
    private userRoleAccessStore: Store<fromRoleAccessStore.IRoleReducerState>,
    private contentAddedCheckService: ContentAddedCheckService
  ) {
    this.noIntroVideo = false;
  }
  ngOnChanges(changeObj) {
    //console.log('introVideoUrl', this.introVideoUrl);
    if (this.introVideoUrl !== undefined) {
      if (Object.keys(this.introVideoUrl).length === 0) {
        this.noIntroVideo = true;
      } else {
        //check for add
        this.isCardAddedToLP();
        let videoId;
        if (
          this.introVideoUrl !== undefined &&
          this.introVideoUrl !== null &&
          this.introVideoUrl.SourceType !== undefined &&
          this.introVideoUrl.SourceType === 'YouTube'
        ) {
          videoId = this.introVideoUrl.SourceUrl.split('embed/')[1];
        } else if (
          this.introVideoUrl !== undefined &&
          this.introVideoUrl !== null &&
          this.introVideoUrl.SourceType !== undefined &&
          this.introVideoUrl.SourceType === 'O365'
        ) {
          videoId = this.introVideoUrl.UniqueId;
        }
        if (this.introVideoUrl !== null) {
          if (changeObj['introVideoUrl']) {
            const data = {
              ContentId: this.introVideoUrl.Id,
              UnitId: this.introVideoUrl.UnitId,
              CourseId: this.contentDetails.Id,
              ItemId: this.contentDetails.Id,
              ItemType: this.contentDetails.ItemType,
              PathId: 0,
              VideoId: videoId,
              sourceUrl: this.introVideoUrl.SourceUrl
            };
            this.videoConfig = {
              VideoDetails: data,
              CanCaptureProgress: this.isAddedToLP,
              VideoPlayerId: 'IntroVideo-' + videoId,
              PlayerVars: PlayerVarsIntroVideo,
              showInfoMsg: false
            };
          }
        }
      }
    }
  }
  ngOnInit() {
    // format the social count
    this.contentDetails.TotalUsers = this.detailsPageService.CountFormatter(
      this.contentDetails.TotalUsers
    );
    this.contentDetails.TotalShares = this.detailsPageService.CountFormatter(
      this.contentDetails.TotalShares
    );
    this.contentDetails.TotalExperts = this.detailsPageService.CountFormatter(
      this.contentDetails.TotalExperts
    );
    //get the roles
    this.userRoleAccessStore
      .select(fromRoleAccessStore.getRoleAccessList)
      .subscribe(roleList => {
        this.roleList = roleList;
      });
  }
  isCardAddedToLP() {
    this.contentAddedCheckService
      .IsContentAddedToLP(this.contentDetails)
      .then(response => {
        //console.log(response);
        if (response) {
          this.isAddedToLP = true;
        } else {
          this.isAddedToLP = false;
        }
      });
  }
}
