import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsPagePackageComponent } from './details-page-package.component';

describe('DetailsPagePackageComponent', () => {
  let component: DetailsPagePackageComponent;
  let fixture: ComponentFixture<DetailsPagePackageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailsPagePackageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailsPagePackageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
