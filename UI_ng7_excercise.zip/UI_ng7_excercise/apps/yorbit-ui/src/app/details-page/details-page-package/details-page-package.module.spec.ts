import { DetailsPagePackageModule } from './details-page-package.module';

describe('DetailsPagePackageModule', () => {
  let detailsPagePackageModule: DetailsPagePackageModule;

  beforeEach(() => {
    detailsPagePackageModule = new DetailsPagePackageModule();
  });

  it('should create an instance', () => {
    expect(detailsPagePackageModule).toBeTruthy();
  });
});
