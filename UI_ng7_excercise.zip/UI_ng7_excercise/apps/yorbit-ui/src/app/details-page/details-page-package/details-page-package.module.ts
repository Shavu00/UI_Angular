import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AccordionModule } from '../../shared/accordion/accordion.module';
import { VideoPlayersModule } from '../../shared/video-players/video-players.module';
import { DetailsPagePackageComponent } from './details-page-package.component';
import { CardFeatureModule } from '../../shared/card-feature/card-feature.module';
import { LinkyModule } from 'angular-linky';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    AccordionModule,
    VideoPlayersModule,
    CardFeatureModule,
    LinkyModule
  ],
  declarations: [DetailsPagePackageComponent],
  exports: [DetailsPagePackageComponent]
})
export class DetailsPagePackageModule { }
