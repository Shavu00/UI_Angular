import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { MediaChange, MediaObserver } from '@angular/flex-layout';
import * as fromRoleAccessStore from '@YorbitWorkspace/role-access';
import { Store } from '@ngrx/store';

import { AddPopupComponent } from '../shared/card-feature/add-content/add-popup/add-popup.component';

import { ContentAddedCheckService } from '../shared/services/content-added-check.service';
import { DetailsPageService } from './details-page.service';
import { Subscriber } from 'rxjs';

interface PreqObj {
  courseName: string;
  courseLink: string;
  courseId: string;
}
interface Content {
  Name: string;
  UniqueId: string;
  Academy: string;
  Genre: string;
  Skill: string;
  Vendor: string;
  Type: string;
  Description: string;
  Duration: string;
  PreRequisiteMandatory: string;
  PreRequisiteCourses: Array<PreqObj>;
  TopicsCovered: string;
  Internal: boolean;
  TotalUsers: number;
  TotalShares: number;
  TotalExperts: number;
  Account: string;
  Project: string;
  AccountPackage: string;
  ProjectPackage: string;
  AcademyUniqueId: number;
  GenreUniqueId: number;
  SkillUniqueId: number;
  Badges: any;
  Credits: number;
  IsHidden: boolean;
}
interface Ratings {
  AvgRating: string;
  CourseId: Number;
  courseFeedbackList: Array<Object>;
}

@Component({
  selector: 'yorbit-details-page',
  templateUrl: './details-page.component.html',
  styleUrls: ['./details-page.component.scss']
})
export class DetailsPageComponent implements OnInit, OnDestroy {
  public itemType: string;
  public expertise: string;
  public courseId: Number;
  public contentDetails: Content;
  public unitDetails: Array<any>;
  public courseDetails: Array<any>;
  public avgRating: Ratings;
  public recommendations: Array<any>;
  public cloudDetails: Array<any>;
  public courseIntroVideo: any;
  listOfPrerequsite: any;
  isAddedToLP: boolean;
  roleList: fromRoleAccessStore.IroleData;
  routeTitle: string;
  routeUrl: string;
  isPageLoading: boolean;
  showMobileView: boolean;
  showDesktopView: boolean;
  detailsPageSubscriptions: any = {};
  constructor(
    private route: ActivatedRoute,
    private detailsPageService: DetailsPageService,
    private contentAddedCheckService: ContentAddedCheckService,
    private _popup: MatDialog,
    private router: Router,
    private userRoleAccessStore: Store<fromRoleAccessStore.IRoleReducerState>,
    private mediaObserver: MediaObserver
  ) {
    //this.courseIntroVideo = {};
    this.recommendations = [];
    this.listOfPrerequsite = [];
    this.routeTitle = '';
    this.routeUrl = '';
    this.isPageLoading = true;
    this.showMobileView = false;
    this.showDesktopView = false;
  }
  subscribeToRouteParams() {
    this.route.params.subscribe(params => {
      this.subscribeMediaChanges();
      this.loadOnPageLoad();
    });
  }
  ngOnInit() {
    this.subscribeToRouteParams();
  }
  loadOnPageLoad() {
    this.isPageLoading = true;
    this.itemType = this.route.snapshot.params['itemType'];
    this.expertise = this.route.snapshot.params['expertise'];
    this.courseId = this.route.snapshot.params['id'];
    //get the routes
    // const routes = this.detailsPageService.getPrevRoute();
    // console.log('routes in details page', routes);
    // if (routes.length > 1) {
    //   this.routeTitle = routes[1].title;
    //   this.routeUrl = routes[1].url;
    // } else {
    //   this.routeTitle = routes[0].title;
    //   this.routeUrl = routes[0].url;
    // }
    //get the roles
    this.userRoleAccessStore
      .select(fromRoleAccessStore.getRoleAccessList)
      .subscribe(roleList => {
        this.roleList = roleList;
        //console.log('user roleList', this.roleList);
      });
    //get course/package details
    this.detailsPageService
      .getPackageDetails(this.courseId, this.itemType)
      .subscribe(
        res => {
          this.contentDetails = res;
          if (this.contentDetails !== null && !this.contentDetails.IsHidden) {
            //check for add
            this.isCardAddedToLP();
            //get pre-requisite courses
            //this.getPreRequisite();
            //get content for course
            if (this.itemType === 'Course') {
              if (this.expertise === '101') {
                this.detailsPageService
                  .getCourseContent(this.courseId)
                  .subscribe(data => {
                    this.unitDetails = data.packages;
                    //get course video url
                    this.getIntroVideo(this.courseId);
                    this.isPageLoading = false;
                  });
              } else {
                this.isPageLoading = false;
              }
            }
            //get content for package
            else if (this.itemType === 'FamilyPackage') {
              this.detailsPageService
                .getPackageContent(this.courseId)
                .subscribe(data => {
                  this.courseDetails = data.Courses;
                  if (this.courseDetails.length !== 0) {
                    //get course video url
                    this.getIntroVideo(this.courseDetails[0].Course.Id);
                    this.isPageLoading = false;
                  } else {
                    this.isPageLoading = false;
                    this.courseIntroVideo = {};
                  }
                });
            }
            if (this.itemType !== 'FamilyPackage') {
              //get cloud lab details
              this.detailsPageService
                .getCloudLabDetails(this.courseId)
                .subscribe(cloud => {
                  this.cloudDetails = cloud;
                });
              //get feedback details
              this.detailsPageService
                .getFeedbackDetails(this.courseId)
                .subscribe(feedback => {
                  this.avgRating = feedback;
                });
              //get recommendation details
              this.detailsPageService
                .getRecommendationDetails(this.courseId)
                .subscribe(recommendation => {
                  //remove hidden courses
                  recommendation.forEach(element => {
                    if (!element.IsHidden) {
                      this.recommendations.push(element);
                    }
                  });
                });
            } //condition for family package ends here
          } else {
            this.isPageLoading = false;
          }
        },
        error => {}
      );
  }
  subscribeMediaChanges() {
    //console.log("xs",this.observableMedia.isActive('xs'));
    if (this.mediaObserver.isActive('xs')) {
      this.showMobileView = true;
      this.showDesktopView = false;
    } else if (!this.mediaObserver.isActive('xs')) {
      this.showDesktopView = true;
      this.showMobileView = false;
    }
    if (!this.detailsPageSubscriptions.mediaChangeSubscription) {
      this.detailsPageSubscriptions.mediaChangeSubscription = this.mediaObserver.media$.subscribe(
        (media: MediaChange) => {
          //console.log('media change', media.mqAlias);
          if (media.mqAlias === 'xs') {
            this.showMobileView = true;
            this.showDesktopView = false;
          } else if (media.mqAlias !== 'xs') {
            this.showDesktopView = true;
            this.showMobileView = false;
          }
        },
        error => {
          console.log('media change error', error);
        }
      );
    }
  }
  ngOnDestroy() {
    this.unsubscribeAllSubscriptions();
  }
  unsubscribeAllSubscriptions() {
    for (let subscriberKey in this.detailsPageSubscriptions) {
      let subscriber = this.detailsPageSubscriptions[subscriberKey];
      if (subscriber instanceof Subscriber) {
        subscriber.unsubscribe();
      }
    }
  }
  isCardAddedToLP() {
    this.contentAddedCheckService
      .IsContentAddedToLP(this.contentDetails)
      .then(response => {
        //console.log(response);
        if (response) {
          this.isAddedToLP = true;
        } else {
          this.isAddedToLP = false;
        }
      });
  }
  openDialog() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.panelClass = 'popupDialogContainer';

    dialogConfig.data = {
      contentName: this.contentDetails.Name,
      Id: this.courseId,
      ItemType: this.itemType,
      uniqueId: this.contentDetails.UniqueId,
      accountId: this.contentDetails.Account,
      projectId: this.contentDetails.Project,
      AccountPackage: this.contentDetails.AccountPackage,
      ProjectPackage: this.contentDetails.ProjectPackage,
      Title: this.contentDetails.Name,
      skillProfile: {},
      addedLocation: 'Details-Page'
    };

    this._popup.open(AddPopupComponent, dialogConfig);
  }
  goToBrowsePage(academyId, genreId) {
    const url = 'browse/academy/' + academyId + '/genre/' + genreId;
    this.router.navigate([url]);
  }
  getIntroVideo(courseId) {
    //get course video url
    this.detailsPageService.getCourseVideoUrl(courseId).subscribe(url => {
      if (url === null) {
        this.courseIntroVideo = {};
      } else {
        this.courseIntroVideo = url;
      }
    });
  }
  getPreRequisite() {
    this.listOfPrerequsite = [];
    if (
      this.contentDetails.PreRequisiteCourses !== null &&
      this.contentDetails.PreRequisiteCourses.length !== 0
    ) {
      this.contentDetails.PreRequisiteCourses.forEach(element => {
        this.detailsPageService
          .getPackageDetails(element.courseId, 'Course')
          .subscribe(pre => {
            if (pre !== null && !pre.IsHidden) {
              this.listOfPrerequsite.push(pre);
            }
          });
      });
     
    }
  }
  pageScroll() {
    const ele: any = document.getElementsByClassName('ratingCommentsBox')[0];
    if (ele) {
      ele.scrollIntoView(true);
    }
  }
  stopPropagation(event) {
    event.stopPropagation();
  }
}
