import { TestBed, inject } from '@angular/core/testing';

import { DetailsPageService } from './details-page.service';

describe('DetailsPageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DetailsPageService]
    });
  });

  it('should be created', inject([DetailsPageService], (service: DetailsPageService) => {
    expect(service).toBeTruthy();
  }));
});
