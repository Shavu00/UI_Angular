import { Component, OnInit, AfterViewInit } from '@angular/core';
import {
  EnvironmentService,
  Ienvironment
} from '@YorbitWorkspace/global-environments';
import { AuthService } from '@YorbitWorkspace/auth';
import { AdalService } from 'adal-angular4';
import { SwUpdate } from '@angular/service-worker';
import { Store } from '@ngrx/store';
import * as fromAuthStore from '@YorbitWorkspace/auth';
import * as fromRoleAccessStore from '@YorbitWorkspace/role-access';
import { DomSanitizer } from '@angular/platform-browser';
import * as fromUserDetailsStore from './shared/user-details/store';
import { Observable } from 'rxjs';
import {
  IuserDetails,
  Role
} from './shared/user-details/store/user-details.interface';
import { AppInsightService } from '@YorbitWorkspace/app-insight';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { PushNotificationService } from './push-notifications/push-notifications.service';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { HeaderPopupComponent } from './header/header-popup/header-popup.component';
import { SubscribePushNotificationsComponent } from './push-notifications/subscribe-push-notifications/subscribe-push-notifications.component';

import * as fromGraphStore from '@YorbitWorkspace/graph';
import * as fromMyPageStore from '../app/my-page/store';
import * as fromDeclareStore from './shared/declare-store/store';
import { ICompliance } from './my-page/store/my-page-details.interface';
import { IroleData } from '@YorbitWorkspace/role-access';

import { ManagerFeedbackComponent } from './shared/global-popups/manager-feedback/manager-feedback.component';
import { DetailsPageService } from './details-page/details-page.service';
import { PopupService } from './shared/global-popups/popup.service';
import { PopupTriggerService } from './shared/services/popup-trigger.service';
import { Globals } from './globals';
import { PackageCourseListService } from './shared/services/package-course-list.service';
import { SystemService } from './shared/services/system.service';

import { ToastComponent } from './toast/toast.component';

import { MatSnackBarConfig, MatSnackBar } from '@angular/material';
import { ContentTileLpService } from './shared/content-tiles/content-tile-lp/content-tile-lp.service';
import { GeneralInfoComponent } from './shared/global-popups/general-info/general-info.component';

@Component({
  selector: 'yorbit-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, AfterViewInit {
  title = 'yorbit';
  contentDetails: any;
  config: Ienvironment;
  userDetails$: Observable<IuserDetails>;
  authUserName$: Observable<string>;
  userNameFromGraphDetails: string;
  userImageFromGraphDetails: any;
  userImage: ImageData;
  userId: any;

  complianceDetails$: Observable<ICompliance>;
  userRoleAccess$: Observable<IroleData>;
  navbarLinks: Array<any>;
  yorbitPoints: number | string;
  rolesFromUserDetails: Role[];
  isCustomer: boolean;
  rolesList: any[];
  userRoleAccessLoaded$: Observable<boolean>;
  userProfileLoaded: boolean;
  constructor(
    private _envSvc: EnvironmentService,
    private authService: AuthService,
    private adalService: AdalService,
    private _InsightService: AppInsightService,
    private authStore: Store<fromAuthStore.IAuthState>,
    private declareStore: Store<fromDeclareStore.IdeclareState>,
    private userRoleAccessStore: Store<fromRoleAccessStore.IRoleReducerState>,
    private userDetailsStore: Store<fromUserDetailsStore.IuserDetailsState>,
    private graphStore: Store<fromGraphStore.IGraphReducerState>,
    private myPageStore: Store<fromMyPageStore.IMyPageReducerState>,
    private appStore: Store<any>,
    private _route: Router,
    private pushService: PushNotificationService,
    private dialog: MatDialog,
    private domSanitizer: DomSanitizer,
    private activatedRoute: ActivatedRoute,
    private detailsPageService: DetailsPageService,
    private _popupSvc: PopupService,
    private globals: Globals,
    private _popup: MatDialog,
    private _packageCourseListSvc: PackageCourseListService,
    private _systemService: SystemService,
    private _popupTriggerService: PopupTriggerService,
    private snackBar: MatSnackBar,
    private swUpdate: SwUpdate
  ) {
    this.userImageFromGraphDetails = null;
    this.userProfileLoaded = false;
  }
  loadNavbarLinks() {
    //navbar links should be type of angular routerlinks
    if (this.isCustomer) {
      this.navbarLinks = [
        {
          Name: 'Explore',
          Link: ['/browse']
        },
        {
          Name: 'About Us',
          Link: ['/info/aboutus']
        },
        {
          Name: 'FAQ',
          Link: ['/info/faq/General']
        },
        {
          Name: 'Terms of Use',
          Link: ['/info/termsOfUse']
        },
        {
          Name: 'Feedback',
          Link: ['/info/feedback']
        }
      ];
    } else {
      this.navbarLinks = [
        {
          Name: 'My Profile',
          Link: ['/my-page', this.userId, 'self']
        },
        {
          Name: 'Learning Path',
          Link: ['/learningpath']
        },
        {
          Name: 'Explore',
          Link: ['/browse']
        },
        {
          Name: 'Certification Upload',
          Link: ''
        },
        {
          Name: 'New Course Request',
          Link: ['/course-request']
        },
        {
          Name: 'About Us',
          Link: ['/info/aboutus']
        },
        {
          Name: 'FAQ',
          Link: ['/info/faq/General']
        },
        {
          Name: 'Terms of Use',
          Link: ['/info/termsOfUse']
        },
        {
          Name: 'Feedback',
          Link: ['/info/feedback']
        }
      ];
      this.showToast();
      this.checkPushSubscription();
    }
  }
  ngOnInit() {
    if (this.swUpdate.isEnabled) {
      this.swUpdate.available.subscribe(() => {
        window.location.reload(true);
      });
    }
    this.userId = '';
    this.config = this._envSvc.getEnvironment();
    this.adalAuthentication();
    this.getuserDetails();
    this.insightInitiate();
    this.appStore.subscribe(data => {});
    this.appStore.select('Graph').subscribe(graphdetails => {});
    this.devReroute();
    // this._popupSvc.isManagerFeedbackPending().then(isManagerFeedbackPending => {
    //   if (isManagerFeedbackPending && !this.globals.isManagerFeedbackPopupShown) {
    //     this.openMgrFeedbackDialog();
    //   }
    // });
    //  this.showToast();
  }

  devReroute() {
    if (!this.config.isProd) {
      this._systemService.getMindsAccessStatus('DEV').then((response: any) => {
        if (!response) {
          window.location.href = 'https://yorbit.mindtree.com';
        }
      });
    }
  }
  insightInitiate() {
    this._InsightService.insightInit(this.config.appInsightKey);
  }
  getuserDetails() {
    this.userDetails$ = this.userDetailsStore.select(
      fromUserDetailsStore.getUserDetailObject
    );
    this.userDetailsStore.dispatch(
      new fromUserDetailsStore.UserDetailsGetDetails()
    );

    this.userDetails$.subscribe(res => {
      if (!this.userProfileLoaded) {
        if (res.id !== '') {
          this.userProfileLoaded = true;
          this.globals.MId = res.id;
          this.userId = res.id;
          this._InsightService.trackUser(this.userId);
          this.isCustomer = res.IsCustomer;
          this.yorbitPoints = res.Achievements.Points;
          this.getGraphDetails(res.id);
          this.getComplianceDetails(res.id);

          this.loadNavbarLinks();
          this.getRouteState();
          if (res.Roles) {
            this.rolesFromUserDetails = res.Roles;
          } else {
            this.rolesFromUserDetails = [];
          }
          if (this.isCustomer)
            this.rolesFromUserDetails.push({ RoleId: 'CUSTOMER' });
          this.getUserRoles();
          this.adalAquireOnInterval();
          this.getItemList(res);
        }
      }
    });
  }

  adalAuthentication() {
    this.config.adalConfig.redirectUri = window.location.href;
    (this.config.adalConfig.postLogoutRedirectUri = window.location.href),
      this.authService.authInit(this.config.adalConfig);
    this.adalService.handleWindowCallback();

    this.authUserName$ = this.authStore.select(fromAuthStore.getAuthUserName);
    this.authStore.dispatch(new fromAuthStore.AuthGetUserProfile());

    this.authStore.subscribe(res => {});

    if (this.authUserName$) this.authService.login();
  }

  getGraphDetails(MId) {
    this.graphStore.dispatch(new fromGraphStore.GetGraphUserName(MId));
    this.graphStore.dispatch(new fromGraphStore.GetGraphUserFirstName(MId));
    this.graphStore.dispatch(new fromGraphStore.GetGraphUserJobTitle(MId));
    this.graphStore.dispatch(new fromGraphStore.GetGraphUserImage(MId));
    this.appStore.select('Graph').subscribe(graphDetails => {
      if (graphDetails.loaded) {
        this.userImageFromGraphDetails = this.domSanitizer.bypassSecurityTrustUrl(
          URL.createObjectURL(graphDetails.userGraphInfo.user_image)
        );
        this.userNameFromGraphDetails =
          graphDetails.userGraphInfo.user_first_name;
      }
    });
  }

  getComplianceDetails(MId) {
    this.complianceDetails$ = this.myPageStore.select(
      fromMyPageStore.GET_MY_PAGE_COMPLIANCE
    );
    this.myPageStore.dispatch(new fromMyPageStore.GetMyPageCompliance(MId));
  }

  checkPushSubscription() {
    try {
      this.pushService.getPushSubscription.subscribe(token => {
        console.log('push subscription token', token);
        if (token != '') {
          if (token == null) {
            //trigger popup
            const dialogRef = this.dialog.open(
              SubscribePushNotificationsComponent,
              {
                panelClass: 'popupDialogContainer',
                disableClose: false
              }
            );
            dialogRef.afterClosed().subscribe(data => {
              this._popupTriggerService.canTriggerPopupsOnLoad.next(true);
            });
          } else {
            //save the token
            this.pushService
              .storeSubscriptionId(token)
              .toPromise()
              .then(response => {});
            this.pushService
              .subscribeUserToGlobalTopic(token)
              .toPromise()
              .then(response => {})
              .catch(err => {});
            this._popupTriggerService.canTriggerPopupsOnLoad.next(true);
          }
        } else {
          this._popupTriggerService.canTriggerPopupsOnLoad.next(true);
        }
      });
    } catch (error) {
      this._popupTriggerService.canTriggerPopupsOnLoad.next(true);
    }
  }

  goToCourseRequest() {
    this._route.navigate(['course-request']);
  }

  openMgrFeedbackDialog() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.panelClass = 'popupDialogContainer';
    this.dialog.open(ManagerFeedbackComponent, dialogConfig);
  }

  getUserRoles() {
    this.userRoleAccess$ = this.userRoleAccessStore.select(
      fromRoleAccessStore.getRoleAccessList
    );
    this.userRoleAccessLoaded$ = this.userRoleAccessStore.select(
      fromRoleAccessStore.getRoleAccessListLoaded
    );
    this.userRoleAccessStore.dispatch(
      new fromRoleAccessStore.RoleGetAccessList()
    );
    this.userRoleAccess$.subscribe(roleAccess => {
      this.userRoleAccessLoaded$.subscribe(loaded => {
        if (this.rolesFromUserDetails && loaded) {
          const allRoles = [];
          this.rolesFromUserDetails.forEach(element => {
            allRoles.push(element.RoleId.toUpperCase());
          });
          if (roleAccess) {
            Object.entries(roleAccess).forEach(([key, value]) => {
              if (value) allRoles.push(key.toUpperCase());
            });
          }
          this.rolesList = allRoles;
          this.AdminRoleInit();
          this.userRoleAccessStore.dispatch(
            new fromRoleAccessStore.RoleUpdateAccessList(allRoles)
          );
        }
      });
    });
  }

  getRouteState() {
    this._route.events.forEach(event => {
      if (event instanceof NavigationEnd) {
        this.onPageRoute();
      }
    });
    this.onPageRoute();
  }

  onPageRoute() {
    try {
      const routeTitle = this.activatedRoute.snapshot.firstChild.children[0]
        .data.title;
      // const obj = {
      //   title: routeTitle,
      //   url: window.location.pathname
      // };
      // this.detailsPageService.savePrevRoute(obj);
      this._InsightService.trackPage(routeTitle);
      if (this.isCustomer) {
        this.checkCustomerRoute(routeTitle);
      }
      this.AdminRoleInit();
    } catch (error) {
      setTimeout(() => {
        this.onPageRoute();
      }, 2000);
    }
  }

  AdminRoleInit() {
    try {
      const routeTitle = this.activatedRoute.snapshot.firstChild.children[0]
        .data.title;

      const adminPagesListFromUserDetails = ['C2OPS', 'PSS', 'CDM'];
      const adminPagesListFromRoleApi = ['AO', 'RM'];
      const adminPagesList = [
        ...adminPagesListFromUserDetails,
        ...adminPagesListFromRoleApi,
        'ACCOUNTS'
      ];
      if (-1 !== adminPagesList.indexOf(routeTitle)) {
        if (-1 !== adminPagesListFromUserDetails.indexOf(routeTitle)) {
          this.checkAdminRole(routeTitle);
        }
        if (-1 !== adminPagesListFromRoleApi.indexOf(routeTitle)) {
          this.userRoleAccessLoaded$.subscribe(res => {
            if (res) this.checkAdminRole(routeTitle);
          });
        }
        if ('ACCOUNTS' === routeTitle) {
          this.userRoleAccessLoaded$.subscribe(res => {
            if (res) {
              if (this.rolesList) {
                if (null === this.rolesList || [] === this.rolesList) {
                  this.gotoUnauthorized();
                }
                const accountRole = {
                  ACM: -1 !== this.rolesList.indexOf('ACM'),
                  PCM: -1 !== this.rolesList.indexOf('PCM'),
                  TM: -1 !== this.rolesList.indexOf('TM')
                };
                if (
                  !(
                    accountRole.ACM ||
                    accountRole.PCM ||
                    accountRole.TM ||
                    this.isCustomer
                  )
                ) {
                  this.gotoUnauthorized();
                }
              }
            }
          });
        }
      }
    } catch (error) {}
  }

  gotoUnauthorized() {
    if (this.isCustomer) {
      this._route.navigate(['/unauthorized'], {
        queryParams: { forUser: 'Customer' }
      });
    } else {
      this._route.navigate(['unauthorized']);
    }
  }
  checkCustomerRoute(routeTitle) {
    const userAgentMobile =
      navigator.userAgent.match(/Android/i) ||
      navigator.userAgent.match(/webOS/i) ||
      navigator.userAgent.match(/iPhone/i) ||
      navigator.userAgent.match(/iPad/i) ||
      navigator.userAgent.match(/iPod/i) ||
      navigator.userAgent.match(/BlackBerry/i) ||
      navigator.userAgent.match(/Windows Phone/i);
    if (null !== userAgentMobile) {
      this._route.navigate(['/unauthorized'], {
        queryParams: { forUser: 'Customer' }
      });
    }
    const routesAllowed = [
      'Home',
      'Browse',
      'Search',
      'Details Page',
      'Project Details Page',
      'ACCOUNTS',
      'Feedback'
    ];
    const footerOptions = ['About us', 'FAQ', 'Terms of use'];
    if ('Home' === routeTitle) {
      this._route.navigate(['/browse']);
    }
    if (-1 !== footerOptions.indexOf(routeTitle)) {
      const path = window.location.href;
      if (-1 === path.indexOf('external')) {
        switch (routeTitle) {
          case 'About us':
            this._route.navigate(['info/aboutus/external']);
            break;
          case 'FAQ':
            this._route.navigate(['info/faq/external/', 'Access Related']);
            break;
          case 'Terms of use':
            this._route.navigate(['info/termsOfUse/external']);
            break;
          default:
            break;
        }
      }
    } else if (-1 === routesAllowed.indexOf(routeTitle)) {
      this._route.navigate(['/unauthorized'], {
        queryParams: { forUser: 'Customer' }
      });
    }
  }
  checkAdminRole(routeTitle) {
    if (null === this.rolesList || 0 === this.rolesList.length) {
      this.gotoUnauthorized();
    }
    if (this.rolesList && -1 === this.rolesList.indexOf(routeTitle)) {
      this.gotoUnauthorized();
    }
  }

  adalAquireOnInterval() {
    const timer = setInterval(() => {
      Object.entries(this.config.adalConfig.endpoints).forEach(
        ([key, value]) => {
          this.adalService.acquireToken(key);
        }
      );
    }, 15 * 60 * 1000);
  }
  openPopup(tab) {
    if (tab === 'Certification Upload') {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.autoFocus = true;
      dialogConfig.data = {};
      dialogConfig.panelClass = 'popupDialogContainer';
      const response = this._popup.open(HeaderPopupComponent, dialogConfig);
      response.afterClosed().subscribe(res => {
        //console.log('response from header pop up', res);
        if (res.data === 'Yes') {
          this._route.navigate(['iCertificationUpload']);
        } else if (res.data === 'No') {
          this._route.navigate(['eCertificationUpload']);
        }
      });
    }
  }

  logOut() {
    this.adalService.logOut();
  }

  getItemList(userDetails) {
    let undeletedlps = [];
    let packages = [];
    let courses = [];
    if (userDetails.LearningPaths.length > 0) {
      undeletedlps = userDetails.LearningPaths.filter(
        lp => lp.IsDeleted === false
      );

      if (undeletedlps.length > 0) {
        undeletedlps.forEach(lp => {
          if (lp.PackageList.length > 0) {
            let undeletedList = [];
            let undeletedPackagesList = [];
            let undeletedCoursesList = [];
            undeletedList = lp.PackageList.filter(
              entity => entity.IsDeleted === false
            );
            undeletedPackagesList = undeletedList.filter(
              packageList =>
                packageList.ItemType.toLowerCase() === 'package' ||
                packageList.ItemType.toLowerCase() === 'familypackage'
            );
            undeletedCoursesList = undeletedList.filter(
              courseList => courseList.ItemType.toLowerCase() === 'course'
            );
            if (undeletedPackagesList.length > 0) {
              undeletedPackagesList.forEach(li => {
                packages.push({
                  packageId: li.ItemId,
                  accountId: li.AccountId,
                  projectId: li.ProjectId
                });
              });
            }
            if (undeletedCoursesList.length > 0) {
              undeletedCoursesList.forEach(li => {
                courses.push({
                  CourseId: li.ItemId,
                  Expertise: li.ItemExpertise
                });
              });
            }
          }
        });
      }
    }

    if (packages.length > 0) {
      this._packageCourseListSvc.getCourseIdsOfPackage(packages);
    }
    if (courses.length > 0) {
      this.courseDeclareWorkflow(courses);
    } else {
      this.declareStore.dispatch(
        new fromDeclareStore.DeclareGetStatusError('empty')
      );
    }
  }

  courseDeclareWorkflow(courses) {
    this.declareStore.dispatch(new fromDeclareStore.DeclareGetStatus(courses));
  }

  showToast() {
    const today = new Date();
    if (today <= this.globals.lastDateCompletion) {
      this.openSnackBar();
    }
  }

  openSnackBar() {
    const config = new MatSnackBarConfig();
    config.verticalPosition = 'top';
    config.horizontalPosition = 'end';
    config.panelClass = 'toastSnackbar';
    config.duration = 70000;
    config.panelClass = 'toast-panel-class';
    this.snackBar.openFromComponent(ToastComponent, config);
  }
  ngAfterViewInit() {}
}
