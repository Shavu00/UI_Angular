import { Injectable } from '@angular/core';

@Injectable()
export class Globals {
  //Customer Access flag
  isCustomerAccess = false;

  //Manager Feedback Popup
  isManagerFeedbackPopupShown = false;
  managerFeedbackList = [];

  //Course Feedback Popup
  isCourseFeedbackPopupShown = false;
  courseFeedbackList = [];

  isLearnerCompliant = false;
  topLearnersData = [];
  //course ids for which last completed date has to be shown in lp
  courseListForShowingLastCompletedDate = ["2290","793","192","3222","3223"]; // prod
  //courseListForShowingLastCompletedDate = ["2290","793","192","2793","2794"]; //dev

  MId = '';

  homePageCards = [];
  mqAlias = 0;

  packageCourseList = [];
  isRecommendationsClicked = false;
  isSkillProfileClicked=false;
  isPersonalisedRecommendationsClicked=false;
  
  lastDateRegistration = new Date(2019, 9, 31); //Oct 31
  lastDateCompletion = new Date(2019,10,30); // Nov 30
  promotionCycle = "Jan 2020 Promotion Cycle";

  businessEthicsNotCompleted = false;
  mandatoryReminderCount = -1;
  mandatoryRetakeDate = null;
  complianceLPDetails = null;
  mandatoryLPProgress = null;
  isNewJoinee = false;
  isDateAPICalled = false;

  NASSCOMRecommendations = [];
  showReleasePopup = null;

}
