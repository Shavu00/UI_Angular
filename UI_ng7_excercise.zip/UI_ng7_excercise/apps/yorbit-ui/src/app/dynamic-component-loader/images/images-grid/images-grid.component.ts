import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Observable, of, Subscriber } from 'rxjs';
import { MediaObserver, MediaChange } from '@angular/flex-layout';
import { map, catchError, tap, startWith } from 'rxjs/operators';
import { GridTile } from './grid-tile';
import { ImagesGridService } from './images-grid.service';
import { Router } from '@angular/router';
import { Globals } from '../../../globals';
import { _CdkFooterRowDefBase } from '@angular/cdk/table';
import { AppInsightService } from '@YorbitWorkspace/app-insight';

@Component({
  selector: 'yorbit-images-grid',
  templateUrl: './images-grid.component.html',
  styleUrls: ['./images-grid.component.scss']
})
export class ImagesGridComponent implements OnInit, AfterViewInit {
  cards: GridTile[] = [];
  default: Array<boolean> = [];
  cols$: Observable<number>;
  rowHeight: Observable<string>;
  gutter: Observable<string>;
  showTiles: boolean;
  mediaBreakPoint: number;
  showXS: boolean;
  mediaQuerySub: any = {};

  constructor(
    private mediaObserver: MediaObserver,
    private _gridSvc: ImagesGridService,
    private _route: Router,
    private globals: Globals,
    private _InsightService: AppInsightService
  ) {}

  ngOnInit() {
    this.showTiles = false;
    if (this.cards.length === 0 && this.globals.mqAlias !== 0) {
      if (this.globals.mqAlias === 1) {
        this.createCards(this.globals.mqAlias);
        this.rowHeight = of('1:1');
        this.gutter = of('10px');
        this.cols$ = of(1);
        this.showXS = true;
        for (let i = 0; i < this.cards.length; i++) {
          this.default[i] = true;
        }
      } else {
        this.createCards(12);
        this.cols$ = of(12);
        this.rowHeight = of('1:1');
        this.gutter = of('30px');
        this.showXS = false;
        this.globals.mqAlias = 12;
        for (let i = 0; i < this.cards.length; i++) {
          this.default[i] = true;
        }
      }
    }
  }

  ngAfterViewInit() {
    this.mediaQuerySub = this.mediaObserver.media$.subscribe(
      (media: MediaChange) => {
        switch (media.mqAlias) {
          case 'xs':
            {
              this.createCards(1);
              this.rowHeight = of('1:1');
              this.gutter = of('10px');
              this.cols$ = of(1);
              this.showXS = true;
              this.globals.mqAlias = 1;
              for (let i = 0; i < this.cards.length; i++) {
                this.default[i] = true;
              }
            }
            break;
          case 'sm':
          case 'md':
          case 'lg':
          case 'xl':
            {
              this.createCards(12);
              this.cols$ = of(12);
              this.rowHeight = of('1:1');
              this.gutter = of('30px');
              this.showXS = false;
              this.globals.mqAlias = 12;
              for (let i = 0; i < this.cards.length; i++) {
                this.default[i] = true;
              }
            }
            break;
          default: {
            this.createCards(12);
            this.cols$ = of(12);
            this.rowHeight = of('1:1');
            this.showXS = false;
            this.globals.mqAlias = 12;
            for (let i = 0; i < this.cards.length; i++) {
              this.default[i] = true;
            }
          }
        }
      }
    );
  }

  createCards(data) {
    this.showTiles = true;
    this.cards = [];
    this._gridSvc.cardsService().then(
      cardData => {
        for (let i = 0; i < cardData.length; i++) {
          let column;
          let row;
          //this.rowHeight = new Observable(observer => observer.next('1:1'));
          switch (data) {
            case 16:
              const valOfCol8 = cardData[i].cols * (data / 3);
              column = cardData[i].cols;
              //valOfCol8 > cardData[i].cols ? (data / 4) : valOfCol8;
              row = cardData[i].rows;
              break;
            case 12:
              const valOfCol6 = cardData[i].cols * (data / 3);
              column = cardData[i].cols;
              //  valOfCol6 > cardData[i].cols ? (data / 3) * cardData[i].cols : valOfCol6;
              row = cardData[i].rows;
              break;
            case 8:
              const valOfCol4 = cardData[i].cols * (data / 3);
              column = cardData[i].cols;
              // valOfCol4 > cardData[i].cols ? cardData[i].cols : valOfCol4;
              row = cardData[i].rows;
              break;
            case 2:
            case 1:
              column = cardData[i].cols_m;
              row = cardData[i].rows_m;
              // if (i === 1) {
              //   row = 1;
              // } else if (i === 2) {
              //   row = 1;
              // }
              break;
          }
          const card = new GridTile({
            name: { key: GridTile.metadata.NAME, value: 'users' },
            col: { key: GridTile.metadata.COL, value: column },
            row: { key: GridTile.metadata.ROW, value: row },
            template: {
              key: GridTile.metadata.TEMPLATE,
              value: cardData[i].imgUrl
            },
            alt_template: {
              key: GridTile.metadata.ALT_TEMPLATE,
              value: cardData[i].alt_imgUrl
            },
            mob_template: {
              key: GridTile.metadata.MOB_TEMPLATE,
              value: cardData[i].mob_imgUrl
            },
            rowHeight: {
              key: GridTile.metadata.ROWHEIGHT,
              value: '1:1'
            },
            action: {
              key: GridTile.metadata.ACTION,
              value: cardData[i].action
            },
            call_to_action: {
              key: GridTile.metadata.CALL_TO_ACTION,
              value: cardData[i].callToAction
            },
            isImg: {
              key: GridTile.metadata.ISIMG,
              value: cardData[i].isImg
            },
            show_on_mob: {
              key: GridTile.metadata.ISIMG,
              value: cardData[i].isActiveInMob
            },
            academy_id: {
              key: GridTile.metadata.ACADEMY_ID,
              value: cardData[i].academyId
            },
            genre_id: {
              key: GridTile.metadata.GENRE_ID,
              value: cardData[i].genreId
            },
            title: {
              key: GridTile.metadata.TITLE,
              value: cardData[i].title
            }
          });

          if (data === 1 && cardData[i].isActiveInMob) {
            this.cards.push(card);
          } else if (data !== 1) {
            this.cards.push(card);
          }
          if (data === 1) {
            this.showXS = true;
          } else {
            this.showXS = false;
          }
        }
        this.showTiles = true;

        for (const subscriberKey in this.mediaQuerySub) {
          if (this.mediaQuerySub[subscriberKey] instanceof Subscriber) {
            this.mediaQuerySub[subscriberKey].unsubscribe();
          }
        }
      },
      error => {
        this.cards = [];
      }
    );
  }

  callToAction(actionType, card) {
    switch (actionType) {
      case 'goToBrowse':
        const url =
          '/browse/academy/' +
          card.inputs.academy_id.value +
          '/genre/' +
          card.inputs.genre_id.value;
        this._route.navigate([url]);
        break;
      case 'goToMyPage':
        this.globals.isRecommendationsClicked = true;
        this._route.navigate(['/my-page/', this.globals.MId, 'self']);
        break;
      case 'externalLink':
        window.open(
          ' https://peoplehub.mindtree.com/sites/Policies/LandC/Pages/NewLearningPolicy.aspx',
          '_blank'
        );
        break;
      case 'doNothing':
        break;
      default:
        break;
    }
    const insightPayload = {
      Action: card.inputs.title.value
    };
    this._InsightService.trackEvent('Info Graphic Clicked', insightPayload);
  }
  checkDefault(val, index) {
    if (val === '' || val === '') {
      this.default[index] = true;
    } else {
      this.default[index] = false;
    }
  }
}
