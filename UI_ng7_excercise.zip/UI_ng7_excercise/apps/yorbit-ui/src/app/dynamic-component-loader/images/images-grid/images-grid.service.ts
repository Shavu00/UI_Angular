import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';


@Injectable({
  providedIn: 'root'
})
export class ImagesGridService {
  cardList: Array<any> = [];
  Mid:string;
  constructor() { }


  cardsService() {
    // tslint:disable-next-line:no-shadowed-variable
    return new Promise<any[]>((resolve, reject) => {
      this.cardList = [];
      const elem = [];
      elem[0] = {
        flexOrder: '1',
        imgUrl: '../../assets/images/Marketing/domain-expert3.jpg',
        alt_imgUrl:'',
        mob_imgUrl:'../../assets/images/Marketing/domain-expert3.jpg',
        cols: '4',
        rows: '8',
        cols_m:'1',
        rows_m:'2',
        action:'goToBrowse',
        callToAction:true,
        isImg:true,
        isActiveInMob:true,
        academyId:4,
        genreId:175,
        title:"Specialist in Supply chain Management"
      };
      elem[1] = {
        flexOrder: '2',
        imgUrl: '../../assets/images/Marketing/domain-expert1.jpg',
        alt_imgUrl:'',
        mob_imgUrl:'../../assets/images/Marketing/domain-expert1.jpg',
        cols: '4',
        rows: '8',
        cols_m:'1',
        rows_m:'2',
        action:'goToBrowse',
        callToAction:true,
        isImg:true,
        isActiveInMob:true,
        academyId:4,
        genreId:119,
        title:"Explore the World of Retail"
      };
      elem[2] = {
        flexOrder: '3',
        imgUrl: '../../assets/images/Marketing/domain-expert2.jpg',
        alt_imgUrl:'',
        mob_imgUrl:'../../assets/images/Marketing/domain-expert2.jpg',
        cols: '4',
        rows: '8',
        cols_m:'1',
        rows_m:'2',
        action:'goToBrowse',
        callToAction:true,
        isImg:true,
        isActiveInMob:true,
        academyId:4,
        genreId:170,
        title:"Dive into the world of Manufacturing"
      };
      elem[3] = {
        flexOrder: '6',
        imgUrl:'../../assets/images/Marketing/Compliance-Policy.jpg',
        alt_imgUrl: '',
        mob_imgUrl:'../../assets/images/Marketing/Compliance-Policy-m.jpg',
        cols: '8',
        rows: '4',
        cols_m:'1',
        rows_m:'1',
        action:'externalLink',
        callToAction:true,
        isImg:true,
        isActiveInMob:true,
        academyId:-1,
        genreId:-1,
        title:"Compliance Policy"
      };      
      elem[4] = {
        flexOrder: '6',
        imgUrl: '../../assets/images/Marketing/skilling-rec-tile.jpg',
        alt_imgUrl:'../../assets/images/Marketing/skilling-rec-tile-hover.jpg',
        mob_imgUrl:'../../assets/images/Marketing/skilling-rec-tile-m.jpg',
        cols: '4',
        rows: '4',
        cols_m:'1',
        rows_m:'1',
        action:'goToMyPage',
        callToAction:true,
        isImg:true,
        isActiveInMob:true,
        title:"Recommendation"
      };

      for (let i = 0; i < elem.length; i++) {
        this.cardList.push(elem[i]);
      }
      resolve(this.cardList);
    });
  }


}
