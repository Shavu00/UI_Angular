import { TestBed, inject } from '@angular/core/testing';

import { ImagesGridService } from './images-grid.service';

describe('ImagesGridService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ImagesGridService]
    });
  });

  it('should be created', inject([ImagesGridService], (service: ImagesGridService) => {
    expect(service).toBeTruthy();
  }));
});
