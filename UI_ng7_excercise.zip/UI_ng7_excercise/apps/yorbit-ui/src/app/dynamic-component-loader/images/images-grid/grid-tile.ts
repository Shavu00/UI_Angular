import { InjectionToken } from '@angular/core';
import { Observable } from 'rxjs';

export class GridTile {
  static metadata: any = {
    NAME: new InjectionToken<string>('name'),
    COLOR: new InjectionToken<string>('color'),
    COLS: new InjectionToken<Observable<number>>('cols'),
    ROWS: new InjectionToken<Observable<number>>('rows'),
    TEMPLATE : new InjectionToken<string>('template'),
    ALT_TEMPLATE : new InjectionToken<string>('alt_template'),
    MOB_TEMPLATE:new InjectionToken<string>('mob_template'),
    ROWHEIGHT: new InjectionToken<string>('rowHeight'),
    ACTION:new InjectionToken<string>('action'),
    CALL_TO_ACTION:new InjectionToken<boolean>('call_to_action'),
    ISIMG :new InjectionToken<boolean>('isImg'),
    SHOW_ON_MOB:new InjectionToken<boolean>('show_on_mob'),
    ACADEMY_ID :new InjectionToken<boolean>('academy_id'),
    GENRE_ID :new InjectionToken<boolean>('genre_id'),
    TITLE :new InjectionToken<boolean>('title'),
  };
  constructor(
    private _input: {
      name: {
        key: InjectionToken<string>;
        value: string;
      };
      col: {
        key: InjectionToken<Observable<number>>;
        value: number;
      };
      row: {
        key: InjectionToken<Observable<number>>;
        value: number;
      };
      template: {
        key: InjectionToken<string>;
        value: string;
      };
      alt_template: {
        key: InjectionToken<string>;
        value: string;
      };
      mob_template: {
        key: InjectionToken<string>;
        value: string;
      };
      rowHeight: {
        key: InjectionToken<Observable<string>>;
        value: string;
      };
      action:{
        key:InjectionToken<string>;
        value:string;
      };
      call_to_action:{
        key:InjectionToken<boolean>;
        value:boolean;
      },
      isImg:{
        key:InjectionToken<boolean>;
        value:boolean;
      },
      show_on_mob:{
        key:InjectionToken<boolean>;
        value:boolean;
      },
      academy_id:{
        key:InjectionToken<string>;
        value:string;
      },
      genre_id:{
        key:InjectionToken<string>;
        value:string;
      },
      title:{
        key:InjectionToken<string>;
        value:string;
      }
    }
  ) {}
  get inputs(): any {
    return this._input;
  }

  // get component(): any {
  //   return this._component;
  // }
}
