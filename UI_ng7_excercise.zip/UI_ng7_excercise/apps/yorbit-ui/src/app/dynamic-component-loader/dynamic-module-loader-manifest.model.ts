export const Manifests =[
{
  componentId: 'images-grid',
  path: 'dynamicComponentLoader/component/images-grid',
  loadChildren:
    'apps/yorbit-ui/src/app/dynamic-component-loader/images/images.module#ImagesModule'
}
]
