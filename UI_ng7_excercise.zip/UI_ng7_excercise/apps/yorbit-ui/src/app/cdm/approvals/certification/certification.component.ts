import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { CdmService } from '../../cdm.service';
import { ArrayPropertyFilterPipe } from 'libs/pipes/src/lib/array-property-filter.pipe';
import { GraphDataService } from '@YorbitWorkspace/graph';
import { WINDOW } from '../../../shared/services/window.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Subscriber } from 'rxjs';

@Component({
  selector: 'yorbit-certification',
  templateUrl: './certification.component.html',
  styleUrls: ['./certification.component.scss']
})
export class CertificationComponent implements OnInit, OnDestroy {
  requests: Array<any>;
  requestsLoading: boolean;
  requestsLoadedSuccessfully: boolean;
  searchStatus: boolean;
  arrayPropertyFilter: any;
  requestActionsPayload: any;
  certificationComponentSubscriptions: any;
  startingIndex: number;
  userRole: string;
  constructor(
    private cdmService: CdmService,
    private _graphSvc: GraphDataService,
    private sanitizer: DomSanitizer,
    @Inject(WINDOW) private _window: Window
  ) {
    this.userRole = '';
    this.requests = [];
    this.requestsLoading = true;
    this.requestsLoadedSuccessfully = false;
    this.searchStatus = false;
    this.certificationComponentSubscriptions = {};
    this.arrayPropertyFilter = new ArrayPropertyFilterPipe();
    this.requestActionsPayload = {
      ItemsIds: [],
      courseId: [],
      Comments: null
    };
    this.startingIndex = 0;
  }
  clearPayload() {
    this.requestActionsPayload = {
      ItemsIds: [],
      courseId: [],
      Comments: null
    };
  }
  subscribeToSearchStatus() {
    this.certificationComponentSubscriptions.searchSubscription = this.cdmService
      .getSearchStatus()
      .subscribe(status => {
        this.searchStatus = status;
        if (status) {
          this.requestsLoading = true;
          this.requestsLoadedSuccessfully = false;
        }
      });
  }
  subscribeToSearchResults() {
    this.certificationComponentSubscriptions.searchResultsSubscription = this.cdmService
      .getSearchResults()
      .subscribe(requests => {
        if (requests == null) {
          requests = [];
        }
        if (this.searchStatus) {
          this.requests = requests;
          this.getSocialDetailsForRequests(this.requests);
          this.requestsLoadedSuccessfully = true;
          this.requestsLoading = false;
        }
      });
  }
  subscribeToFilters() {
    this.certificationComponentSubscriptions.subscribeToFilters = this.cdmService
      .getRequestsFilters()
      .subscribe(filterObj => {
        this.startingIndex = parseInt(filterObj['index']);
        if (!this.searchStatus) {
          this.requests = [];
          this.requestsLoading = true;
          this.requestsLoadedSuccessfully = false;
          this.cdmService
            .getCertificateApprovalCDMorRM(
              this.userRole,
              filterObj['limit'],
              filterObj['index'],
              filterObj['nextOrPrevious']
            )
            .then((requests: any) => {
              if (requests == null) {
                requests = [];
              }
              this.requestsLoadedSuccessfully = true;
              this.requestsLoading = false;
              this.requests = requests.ExternalCertificateList;
              this.getSocialDetailsForRequests(this.requests);
              this.cdmService.updateLoadedRequestsDetails({
                loadedRequestsLength: requests.ExternalCertificateList.length,
                totalRequestsLength: requests.RequestCount
              });
            })
            .catch(err => {
              this.requestsLoadedSuccessfully = false;
              this.requestsLoading = false;
              this.requests = [];
            });
        }
      });
  }
  getSocialDetailsForRequests(requests) {
    requests.forEach(request => {
      request.comments = '';
      if (request.UserId) {
        request.RequestedBy = request.UserId;
      }
      if (request.Filepath) {
        request.fileAzuredbPath = request.Filepath;
      }
      if (request.CertificationDate) {
        request.Certification_dt = request.CertificationDate;
      }
      if (request.ExpiryDate) {
        if (request.ExpiryDate == '0001-01-01T00:00:00') {
          request.IsCheck_noexpiry = true;
        } else {
          request.IsCheck_noexpiry = false;
        }
        request.Expiry_Dt = request.ExpiryDate;
      }
      this.getGraphDetails(request);
      //to check the status of pre-requisite course
      /* just empty the array */
    });
  }
  getGraphDetails(request) {
    this.certificationComponentSubscriptions.graphUserImageSub = this._graphSvc
      .getUserImage(request.RequestedBy)
      .subscribe(
        data => {
          request.userImage = this.createImageURL(data);
        },
        error => {
          request.userImage = null;
        }
      );
    this.certificationComponentSubscriptions.graphUserNameSub = this._graphSvc
      .getUserName(request.RequestedBy)
      .subscribe(
        data => {
          request.Name = data.value;
        },
        error => {
          request.Name = request.UserId;
        }
      );
    if (request.AssignedBy !== '' && request.AssignedBy != null) {
      this.certificationComponentSubscriptions.graphAssignerNameSub = this._graphSvc
        .getUserName(request.AssignedBy)
        .subscribe(
          response => {
            request.AssignerName = response.value;
          },
          err => {
            request.AssignerName = request.AssignedBy;
          }
        );
    }
  }
  createImageURL(imageBlob) {
    const imageURL = this._window.URL.createObjectURL(imageBlob);
    return this.sanitizer.bypassSecurityTrustUrl(imageURL);
  }
  approveRequest(request) {
    this.clearPayload();
    if (request.CourseId != 0 && request.CourseId != '') {
      this.requestActionsPayload.ItemsIds.push(request.RequestId);
      this.requestActionsPayload.Comments = request.comments;
      this.requestActionsPayload.courseId = [request.CourseId];
      request.approveInProgress = true;
      let isCertificate = true;
      //api to approve
      this.cdmService
        .approveRequests(this.requestActionsPayload, isCertificate)
        .then(response => {
          request.approveInProgress = false;
          request.approved = true;
        })
        .catch(err => {
          request.approveInProgress = false;
          request.approved = false;
        });
    } else {
      //show error msg
      request.showWarning = true;
    }
  }
  denyRequest(request) {
    this.clearPayload();
    if (
      request.comments.length != 0 &&
      request.CourseId != 0 &&
      request.CourseId != ''
    ) {
      this.requestActionsPayload.ItemsIds.push(request.RequestId);
      this.requestActionsPayload.Comments = request.comments;
      this.requestActionsPayload.courseId = [request.CourseId];

      request.denyInProgress = true;
      let isCertificate = true;

      //call api to deny
      this.cdmService
        .denyRequests(this.requestActionsPayload, isCertificate)
        .then(response => {
          request.denyInProgress = false;
          request.denied = true;
        })
        .catch(err => {
          request.denyInProgress = false;
          request.denied = false;
        });
    } else {
      //show error msg
      request.showWarning = true;
    }
  }
  holdRequest(request) {
    this.clearPayload();
    if (
      request.comments.length != 0 &&
      request.CourseId != 0 &&
      request.CourseId != ''
    ) {
      this.requestActionsPayload.ItemsIds.push(request.RequestId);
      this.requestActionsPayload.Comments = request.comments;
      this.requestActionsPayload.courseId = [request.CourseId];

      request.holdInProgress = true;
      let isCertificate = true;
      //api to onhold
      this.cdmService
        .holdRequests(this.requestActionsPayload, isCertificate)
        .then(response => {
          request.holdInProgress = false;
          request.onHold = true;
        })
        .catch(err => {
          request.holdInProgress = false;
          request.onHold = false;
        });
    } else {
      //show error msg
      request.showWarning = true;
    }
  }
  ngOnDestroy() {
    this.unsubscribeAllSubscriptions();
  }
  unsubscribeAllSubscriptions() {
    for (let subscriberKey in this.certificationComponentSubscriptions) {
      let subscriber = this.certificationComponentSubscriptions[subscriberKey];
      if (subscriber instanceof Subscriber) {
        subscriber.unsubscribe();
      }
    }
  }
  //certification
  downloadCertificate(previewLink) {
    //let link = "https://yorbitdev.blob.core.windows.net/certificates/M1035893_04-07-2017_746_Edureka_Certificate_for_NodeJS.pdf";
    this._window.open(previewLink, '_blank');
    // win.document.write( "<img src=" + previewLink + "height='100' width='100' alt='You will see a preview of your certificate here'/>" );
    //  win.document.write( "<embed src=" + previewLink + " width='600' height='500' alt='pdf' pluginspage='http://www.adobe.com/products/acrobat/readstep2.html'>" );
    // win.document.write( "<object width='400' height='400' data=" + 'https://yorbitdev.blob.core.windows.net/certificates/M1035893_04-07-2017_Edureka_Certificate_for_NodeJS.pdf' + "></object>");
    //win.document.write( "<iframe src=app/assets/img/" + link + "style='width: 100%; height: 100%;' frameborder='0' scrolling='no'>Sample</iframe>" );
  }
  ngOnInit() {
    this.subscribeToSearchStatus();
    this.subscribeToSearchResults();
    this.cdmService.getRoleOfUser().subscribe(role => {
      //console.log(role);
      this.userRole = role;
    });
    this.subscribeToFilters();
  }
}
