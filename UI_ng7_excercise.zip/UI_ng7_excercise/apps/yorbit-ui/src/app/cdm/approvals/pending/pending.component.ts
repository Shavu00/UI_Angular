import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { CdmService } from '../../cdm.service';
import { ArrayPropertyFilterPipe } from 'libs/pipes/src/lib/array-property-filter.pipe';
import { GraphDataService } from '@YorbitWorkspace/graph';
import { WINDOW } from '../../../shared/services/window.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Subscriber } from 'rxjs';
@Component({
  selector: 'yorbit-pending',
  templateUrl: './pending.component.html',
  styleUrls: ['./pending.component.scss']
})
export class PendingComponent implements OnInit, OnDestroy {
  userRole: string;
  requests: Array<any>;
  requestsLoading: boolean;
  requestsLoadedSuccessfully: boolean;
  searchStatus: boolean;
  arrayPropertyFilter: any;
  arrangeByCourse: boolean;
  courseNames: Array<string>;
  requestActionsPayload: any;
  selectedIds: Array<string | number>;
  overallComments: string;
  groupApprovalInProgress: boolean;
  groupDenyInProgress: boolean;
  groupOnHoldInProgress: boolean;
  groupApprovalSuccess: boolean;
  groupDenySuccess: boolean;
  groupOnHoldSuccess: boolean;
  showSelectAll: boolean;
  pendingComponentSubscriptions: any;
  showWarningForGroupRequests: boolean;
  warningMessage: string;
  selectedCourseNames:any;
  constructor(
    private cdmService: CdmService,
    private _graphSvc: GraphDataService,
    private sanitizer: DomSanitizer,
    @Inject(WINDOW) private _window: Window
  ) {
    this.userRole = '';
    this.requests = [];
    this.courseNames = [];
    this.selectedIds = [];
    this.selectedCourseNames={};
    this.overallComments = '';
    this.groupApprovalInProgress = false;
    this.groupDenyInProgress = false;
    this.groupOnHoldInProgress = false;
    this.groupApprovalSuccess = false;
    this.groupDenySuccess = false;
    this.groupOnHoldSuccess = false;
    this.showSelectAll = true;
    this.requestsLoading = true;
    this.requestsLoadedSuccessfully = false;
    this.arrangeByCourse = false;
    this.searchStatus = false;
    this.pendingComponentSubscriptions = {};
    this.arrayPropertyFilter = new ArrayPropertyFilterPipe();
    this.requestActionsPayload = {
      ItemsIds: [],
      Comments: null
    };
    this.showWarningForGroupRequests = false;
    this.warningMessage = '';
  }
  removeGlobalWarningMessage(event) {
    this.showWarningForGroupRequests = false;
    //console.log('overallComments', this.overallComments);
  }
  subscribeToUserRole() {
    this.pendingComponentSubscriptions.subscribeToUserRole = this.cdmService
      .getRoleOfUser()
      .subscribe(role => {
        if (role == 'cdm') {
          this.userRole = 'cdm';
          this.warningMessage = 'Give comments to hold/deny a request!';
        } else if (role == 'rm') {
          this.userRole = 'rm';
          this.warningMessage = 'Give comments to deny a request!';
        }
      });
  }
  clearPayload() {
    this.requestActionsPayload = {
      ItemsIds: [],
      Comments: null
    };
  }
  subscribeToSearchStatus() {
    this.pendingComponentSubscriptions.searchSubscription = this.cdmService
      .getSearchStatus()
      .subscribe(status => {
        this.searchStatus = status;
        if (status) {
          this.requestsLoading = true;
          this.requestsLoadedSuccessfully = false;
        }
      });
  }
  subscribeToSearchResults() {
    this.pendingComponentSubscriptions.searchResultsSubscription = this.cdmService
      .getSearchResults()
      .subscribe(requests => {
        if (requests == null) {
          requests = [];
        }
        if (this.searchStatus) {
          this.requests = [];
          if (requests != null) {
            requests.forEach(request => {
              if (request.Status == 'Pending' && request.IsAssigned == false) {
                this.requests.push(request);
              }
            });
          }
          this.getSocialDetailsForRequests(this.requests);
          this.requestsLoadedSuccessfully = true;
          this.requestsLoading = false;
        }
      });
  }
  subscribeToFilters() {
    this.pendingComponentSubscriptions.subscribeToFilters = this.cdmService
      .getRequestsFilters()
      .subscribe(filterObj => {
        if (!this.searchStatus) {
          if (filterObj['tab'] == 'pending') {
            this.requests = [];
            this.courseNames = [];
            this.selectedIds = [];
            this.overallComments = '';
            this.groupApprovalInProgress = false;
            this.groupDenyInProgress = false;
            this.groupOnHoldInProgress = false;
            this.groupApprovalSuccess = false;
            this.groupDenySuccess = false;
            this.groupOnHoldSuccess = false;
            this.showSelectAll = true;
            this.requestsLoading = true;
            this.requestsLoadedSuccessfully = false;
            let payload = {
              acceptedRequests: filterObj['acceptedRequests'],
              actionedNo: filterObj['actionedNo'],
              actionedYes: filterObj['actionedYes'],
              arrangeByCourse: filterObj['arrangeByCourse'],
              arrangeByDate: filterObj['arrangeByDate'],
              billablestatus: filterObj['billablestatus'],
              competency: filterObj['competency'],
              courseName: filterObj['courseName'],
              deniedRequests: filterObj['deniedRequests'],
              isACMorPCMAssigned: filterObj['isACMorPCMAssigned'],
              isOther201sInProgress: filterObj['isOther201sInProgress'],
              location: filterObj['location'],
              onHoldRequests: filterObj['onHoldRequests'],
              preRequisiteCoursesCompleted:
                filterObj['preRequisiteCoursesCompleted'],
              preRequisiteCoursesNonCompleted:
                filterObj['preRequisiteCoursesNonCompleted'],
              resignationstatus: filterObj['resignationstatus'],
              searchMids: filterObj['searchMids']
            };
            this.arrangeByCourse = filterObj['arrangeByCourse'];
            this.cdmService
              .getPendingRequests(
                filterObj['limit'],
                filterObj['index'],
                filterObj['nextOrPrevious'],
                payload,
                this.userRole
              )
              .then((requests: any) => {
                if (requests == null) {
                  requests = [];
                }
                this.requestsLoadedSuccessfully = true;
                this.requestsLoading = false;
                this.requests = requests.ApproveOrRejectList;
                this.getSocialDetailsForRequests(this.requests);
                this.cdmService.updateLoadedRequestsDetails({
                  loadedRequestsLength: requests.ApproveOrRejectList.length,
                  totalRequestsLength: requests.RequestCount
                });
              })
              .catch(err => {
                this.requestsLoadedSuccessfully = false;
                this.requestsLoading = false;
                this.requests = [];
              });
          }
        }
      });
  }
  getSocialDetailsForRequests(requests) {
    requests.forEach(request => {
      request.showWarning = false;
      request.comments = '';
      request.checked = false;
      request.approved = false;
      request.denied = false;
      request.onHold = false;
      request.approveInProgress = false;
      request.denyInProgress = false;
      request.holdInProgress = false;
      if (request.PackageID != 0 && request.PackageID != undefined) {
        request.PackageCourses = [];
        request.PacakgeCoursesLoaded = false;
        request.PacakgeCoursesLoading = false;
      }
      if (!this.arrangeByCourse) {
        request.header = false;
      } else {
        this.selectedIds = [];
        if (this.courseNames.indexOf(request.RequestedCourseName) == -1) {
          this.courseNames.push(request.RequestedCourseName);
          this.selectedCourseNames[request.RequestedCourseName]=false;
          request.header = true;
        } else {
          request.header = false;
        }
      }
      this.getGraphDetails(request);

      //to check the status of pre-requisite course
      /* just empty the array */
      if (request.Cost == null) {
        request.Cost = '';
      }
      request.CostDetails = request.Cost.split('+');
      let prerequisiteCompletedArray = [];
      let prerequisiteNotCompletedArray = [];
      if (request.PreRequisiteCourses == null) request.PreRequisiteCourses = [];
      if (request.PreRequisiteCourses.length > 0) {
        request.PreRequisiteCourses.forEach((i, k) => {
          if (i.CompletedDate != null) {
            i.PreRequisiteCoursesStatus = 'Completed';
            prerequisiteCompletedArray[k] = i.PreRequisiteCoursesStatus;
          } else if (i.CompletedDate == null) {
            i.PreRequisiteCoursesStatus = 'Not Completed';
            prerequisiteNotCompletedArray[k] = i.PreRequisiteCoursesStatus;
          }
        });
        // if there is any item in this array then the pre-requisite is not completed otherwise it is completed
        if (
          prerequisiteNotCompletedArray.length != 0 &&
          request.IsPreRequisiteMandatory == true
        ) {
          request.PreRequisiteCoursesStatus = 'Not Completed';
        } else if (
          prerequisiteCompletedArray.length ==
            request.PreRequisiteCourses.length &&
          request.IsPreRequisiteMandatory == true
        ) {
          request.PreRequisiteCoursesStatus = 'Completed';
        } else if (
          prerequisiteNotCompletedArray.length != 0 &&
          request.IsPreRequisiteMandatory == false
        ) {
          request.PreRequisiteCoursesStatus =
            'Not Completed, but not Mandatory';
        } else if (
          prerequisiteCompletedArray.length ==
            request.PreRequisiteCourses.length &&
          request.IsPreRequisiteMandatory == false
        ) {
          request.PreRequisiteCoursesStatus = 'Completed';
        }
      } else {
        if (
          request.IsPreRequisiteMandatory == true ||
          request.IsPreRequisiteMandatory == false
        ) {
          request.PreRequisiteCoursesStatus = 'No Pre-Requisites';
        }
      }
    });
  }
  getGraphDetails(request) {
    this.pendingComponentSubscriptions.graphUserImageSub = this._graphSvc
      .getUserImage(request.UserId)
      .subscribe(
        data => {
          request.userImage = this.createImageURL(data);
        },
        error => {
          request.userImage = null;
        }
      );
    this.pendingComponentSubscriptions.graphUserNameSub = this._graphSvc
      .getUserName(request.UserId)
      .subscribe(
        data => {
          request.Name = data.value;
        },
        error => {
          request.Name = request.UserId;
        }
      );
    if (request.RMMID != null && request.RMMID != '') {
      this.pendingComponentSubscriptions.graphUserRMNameSub = this._graphSvc
        .getUserName(request.RMMID)
        .subscribe(
          data => {
            request.RMName = data.value;
          },
          error => {
            request.RMName = request.RMMID;
          }
        );
    } else {
      request.RMName = request.RMMID;
    }
    // this.getImages(request.UserId);
    // pssService.getUserName(request.UserId).then(function(response) {
    //   request.Name = response.data.value;
    // });
    // // to get RM Name
    // if (request.RMMID == null || request.RMMID == '') {
    //   //do not call graph api
    // } else {
    //   pssService.getUserName(request.RMMID).then(function(response) {
    //     request.RMName = response.data.value;
    //   });
    // }
    // if (request.ActionedBy == null || request.ActionedBy == '') {
    //   //do not call graph api
    // } else if (request.ActionedBy.toLowerCase() == 'auto approved') {
    //   request.approverName = 'AUTO APPROVED';
    // } else {
    //   pssService.getUserName(request.ActionedBy).then(function(response) {
    //     request.approverName = response.data.value;
    //   });
    //   pssService.getUserJobTitle(request.ActionedBy).then(function(response) {
    //     request.approverDesignation = response.data.value;
    //   });
    // }

    if (
      (!request.IsSkillPlan && !request.IsCrossSkill) ||
      (request.IsSkillPlan && !request.IsCrossSkill && !request.IsFutureSkill)
    ) {
      if (request.AssignedBy != '' && request.AssignedBy != null) {
        this._graphSvc.getUserName(request.AssignedBy).subscribe(
          response => {
            request.AssignerName = response.value;
          },
          err => {
            request.AssignerName = request.AssignedBy;
          }
        );
      } else if (request.IsSkillPlan || request.IsCrossSkill) {
        request.AssignedBy = 'NA';
        request.AssignerName = 'NA';
      }
    } else if (
      request.IsSkillPlan &&
      (request.IsCrossSkill || request.IsFutureSkill)
    ) {
      //do not call graph api
      request.AssignedBy = 'SELF';
      request.AssignerName = 'SELF';
    }
  }
  createImageURL(imageBlob) {
    const imageURL = this._window.URL.createObjectURL(imageBlob);
    return this.sanitizer.bypassSecurityTrustUrl(imageURL);
  }
  approveRequest(request) {
    this.clearPayload();
    this.requestActionsPayload.ItemsIds.push(request.RequestId);
    this.requestActionsPayload.Comments = request.comments;
    request.approveInProgress = true;
    //api to approve
    this.cdmService
      .approveRequests(this.requestActionsPayload, false)
      .then(response => {
        request.approveInProgress = false;
        request.approved = true;
      })
      .catch(err => {
        request.approveInProgress = false;
        request.approved = false;
      });
  }
  approveSelectedRequests() {
    this.clearPayload();
    this.requestActionsPayload.ItemsIds = this.selectedIds;
    this.requestActionsPayload.Comments = this.overallComments;
    this.groupApprovalInProgress = true;
    //api to approve
    this.cdmService
      .approveRequests(this.requestActionsPayload, false)
      .then(response => {
        this.groupApprovalInProgress = false;
        this.groupApprovalSuccess = true;
        this.requests.forEach(request => {
          if (this.selectedIds.indexOf(request.RequestId) != -1) {
            request.approveInProgress = false;
            request.approved = true;
          }
        });
      })
      .catch(err => {
        this.groupApprovalInProgress = false;
        this.groupApprovalSuccess = false;
        this.requests.forEach(request => {
          if (this.selectedIds.indexOf(request.RequestId) != -1) {
            request.approveInProgress = false;
            request.approved = false;
          }
        });
      });
  }
  denyRequest(request) {
    this.clearPayload();
    if (request.comments.length != 0) {
      request.showWarning = false;
      this.requestActionsPayload.ItemsIds.push(request.RequestId);
      this.requestActionsPayload.Comments = request.comments;
      request.denyInProgress = true;
      //call api to deny
      this.cdmService
        .denyRequests(this.requestActionsPayload, false)
        .then(response => {
          request.denyInProgress = false;
          request.denied = true;
        })
        .catch(err => {
          request.denyInProgress = false;
          request.denied = false;
        });
    } else {
      request.showWarning = true;
      //show error msg
    }
  }
  denySelectedRequests() {
    this.clearPayload();
    if (this.overallComments.length != 0) {
      this.showWarningForGroupRequests = false;
      this.requestActionsPayload.ItemsIds = this.selectedIds;
      this.requestActionsPayload.Comments = this.overallComments;
      this.groupDenyInProgress = true;
      //api to deny
      this.cdmService
        .denyRequests(this.requestActionsPayload, false)
        .then(response => {
          this.groupDenyInProgress = false;
          this.groupDenySuccess = true;
          this.requests.forEach(request => {
            if (this.selectedIds.indexOf(request.RequestId) != -1) {
              request.denyInProgress = false;
              request.denied = true;
            }
          });
        })
        .catch(err => {
          this.groupDenyInProgress = false;
          this.groupDenySuccess = false;
          this.requests.forEach(request => {
            if (this.selectedIds.indexOf(request.RequestId) != -1) {
              request.denyInProgress = false;
              request.denied = false;
            }
          });
        });
    } else {
      this.showWarningForGroupRequests = true;
      //show error msg
    }
  }
  holdRequest(request) {
    this.clearPayload();
    if (request.comments.length != 0) {
      request.showWarning = false;
      this.requestActionsPayload.ItemsIds.push(request.RequestId);
      this.requestActionsPayload.Comments = request.comments;
      request.holdInProgress = true;
      //api to onhold
      this.cdmService
        .holdRequests(this.requestActionsPayload, false)
        .then(response => {
          request.holdInProgress = false;
          request.onHold = true;
        })
        .catch(err => {
          request.holdInProgress = false;
          request.onHold = false;
        });
    } else {
      request.showWarning = true;
      //show error msg
    }
  }
  holdSelectedRequests() {
    this.clearPayload();
    if (this.overallComments.length != 0) {
      this.showWarningForGroupRequests = false;
      this.requestActionsPayload.ItemsIds = this.selectedIds;
      this.requestActionsPayload.Comments = this.overallComments;
      this.groupOnHoldInProgress = true;
      this.cdmService
        .holdRequests(this.requestActionsPayload, false)
        .then(response => {
          this.groupOnHoldInProgress = false;
          this.groupOnHoldSuccess = true;
          this.requests.forEach(request => {
            if (this.selectedIds.indexOf(request.RequestId) != -1) {
              request.holdInProgress = false;
              request.onHold = true;
            }
          });
        })
        .catch(err => {
          this.groupOnHoldInProgress = false;
          this.groupOnHoldSuccess = false;
          this.requests.forEach(request => {
            if (this.selectedIds.indexOf(request.RequestId) != -1) {
              request.holdInProgress = false;
              request.onHold = false;
            }
          });
        });
    } else {
      this.showWarningForGroupRequests = true;
      //show error msg
    }
  }
  onRequestSelection(request) {
    if (request.checked) {
      this.selectedIds.push(request.RequestId);
      if(this.arrangeByCourse){
        let selectedCourseRequests = this.arrayPropertyFilter.transform(this.requests, {
          property: 'RequestedCourseName',
          flag: name
        });
        let activeRequests = this.arrayPropertyFilter.transform(selectedCourseRequests, {
          property: 'checked',
          flag: true
        });
        if(activeRequests.length==selectedCourseRequests.length){
          this.selectedCourseNames[request.RequestedCourseName]=true;
        }
      }
    } else {
      this.selectedIds.splice(this.selectedIds.indexOf(request.RequestId), 1);
      if(this.arrangeByCourse){
        let selectedCourseRequests = this.arrayPropertyFilter.transform(this.requests, {
          property: 'RequestedCourseName',
          flag: name
        });
        let activeRequests = this.arrayPropertyFilter.transform(selectedCourseRequests, {
          property: 'checked',
          flag: true
        });
        if(activeRequests.length==0){
          this.selectedCourseNames[request.RequestedCourseName]=false;
        }
      }
    }
  }
  onCourseSpecificRequestsSelection(name, checked) {
    
    let selectedRequests = this.arrayPropertyFilter.transform(this.requests, {
      property: 'RequestedCourseName',
      flag: name
    });
    if (checked) {
      selectedRequests.forEach(request => {
        this.selectedIds.push(request.RequestId);
        request.checked=true;
      });
    }
    else{
      selectedRequests.forEach(request => {
        this.selectedIds.splice(this.selectedIds.indexOf(request.RequestId),1);
        request.checked=false;
      });
    }
  }
  selectAllRequests() {
    this.selectedIds = [];
    this.showSelectAll = !this.showSelectAll;
    this.requests.forEach(request => {
      request.checked = true;
      this.selectedIds.push(request.RequestId);
    });
  }
  unSelectAllRequests() {
    this.selectedIds = [];
    this.requests.forEach(request => {
      request.checked = false;
    });
  }
  ngOnDestroy() {
    this.unsubscribeAllSubscriptions();
  }
  unsubscribeAllSubscriptions() {
    for (let subscriberKey in this.pendingComponentSubscriptions) {
      let subscriber = this.pendingComponentSubscriptions[subscriberKey];
      if (subscriber instanceof Subscriber) {
        subscriber.unsubscribe();
      }
    }
  }
  getCoursesStatusInsidePackage(request) {
    request.PacakgeCoursesLoading = true;
    this.cdmService
      .getCourseStatusInsidePackage(request.RequestId)
      .then(response => {
        request.PacakgeCoursesLoaded = true;
        request.PacakgeCoursesLoading = false;
        request.PackageCourses = response;
      });
  }
  ngOnInit() {
    this.subscribeToUserRole();
    this.subscribeToSearchStatus();
    this.subscribeToSearchResults();
    this.subscribeToFilters();
  }
}
