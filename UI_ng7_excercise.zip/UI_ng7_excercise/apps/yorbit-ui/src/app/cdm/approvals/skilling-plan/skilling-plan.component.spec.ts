import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SkillingPlanComponent } from './skilling-plan.component';

describe('SkillingPlanComponent', () => {
  let component: SkillingPlanComponent;
  let fixture: ComponentFixture<SkillingPlanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SkillingPlanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SkillingPlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
