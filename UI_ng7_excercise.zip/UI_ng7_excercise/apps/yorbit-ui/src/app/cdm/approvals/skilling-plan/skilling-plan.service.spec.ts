import { TestBed, inject } from '@angular/core/testing';

import { SkillingPlanService } from './skilling-plan.service';

describe('SkillingPlanService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SkillingPlanService]
    });
  });

  it('should be created', inject([SkillingPlanService], (service: SkillingPlanService) => {
    expect(service).toBeTruthy();
  }));
});
