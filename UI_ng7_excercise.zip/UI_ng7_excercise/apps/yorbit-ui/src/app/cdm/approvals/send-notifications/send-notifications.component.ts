import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'yorbit-send-notifications',
  templateUrl: './send-notifications.component.html',
  styleUrls: ['./send-notifications.component.scss']
})
export class SendNotificationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
