import { Component, OnInit, Inject } from '@angular/core';
import { CdmService } from '../../cdm.service';
import { ArrayPropertyFilterPipe } from 'libs/pipes/src/lib/array-property-filter.pipe';
import { GraphDataService } from '@YorbitWorkspace/graph';
import { WINDOW } from '../../../shared/services/window.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Subscriber } from 'rxjs';
@Component({
  selector: 'yorbit-assigned',
  templateUrl: './assigned.component.html',
  styleUrls: ['./assigned.component.scss']
})
export class AssignedComponent implements OnInit {
  requests: Array<any>;
  requestsLoading: boolean;
  requestsLoadedSuccessfully: boolean;
  searchStatus: boolean;
  arrayPropertyFilter: any;
  arrangeByCourse: boolean;
  courseNames: Array<string>;
  startingIndex: number;
  assignedComponentSubscriptions: any;
  constructor(
    private cdmService: CdmService,
    private _graphSvc: GraphDataService,
    private sanitizer: DomSanitizer,
    @Inject(WINDOW) private _window: Window
  ) {
    this.requests = [];
    this.courseNames = [];
    this.requestsLoading = true;
    this.requestsLoadedSuccessfully = true;
    this.arrangeByCourse = false;
    this.searchStatus = false;
    this.assignedComponentSubscriptions = {};
    this.arrayPropertyFilter = new ArrayPropertyFilterPipe();
    this.startingIndex = 0;
  }
  subscribeToSearchStatus() {
    this.assignedComponentSubscriptions.searchStatusSub = this.cdmService
      .getSearchStatus()
      .subscribe(status => {
        this.searchStatus = status;
        if (status) {
          this.requestsLoading = true;
          this.requestsLoadedSuccessfully = false;
        }
      });
  }
  subscribeToSearchResults() {
    this.assignedComponentSubscriptions.searchResultsSub = this.cdmService
      .getSearchResults()
      .subscribe(requests => {
        if (this.searchStatus) {
          this.requests = [];
          if (requests != null) {
            requests.forEach(request => {
              if (request.IsAssigned == true) {
                this.requests.push(request);
              }
            });
          }
          this.getSocialDetailsForRequests(this.requests);
          this.requestsLoadedSuccessfully = true;
          this.requestsLoading = false;
        }
      });
  }
  subscribeToFilters() {
    this.assignedComponentSubscriptions.filtersSub = this.cdmService
      .getRequestsFilters()
      .subscribe(filterObj => {
        this.startingIndex = parseInt(filterObj['index']);
        if (!this.searchStatus) {
          if (filterObj['tab'] == 'assigned') {
            this.requests = [];
            this.requestsLoading = true;
            this.requestsLoadedSuccessfully = false;
            this.courseNames = [];
            let payload = {
              acceptedRequests: filterObj['acceptedRequests'],
              actionedNo: filterObj['actionedNo'],
              actionedYes: filterObj['actionedYes'],
              arrangeByCourse: filterObj['arrangeByCourse'],
              arrangeByDate: filterObj['arrangeByDate'],
              billablestatus: filterObj['billablestatus'],
              competency: filterObj['competency'],
              courseName: filterObj['courseName'],
              deniedRequests: filterObj['deniedRequests'],
              isACMorPCMAssigned: filterObj['isACMorPCMAssigned'],
              isOther201sInProgress: filterObj['isOther201sInProgress'],
              location: filterObj['location'],
              onHoldRequests: filterObj['onHoldRequests'],
              preRequisiteCoursesCompleted:
                filterObj['preRequisiteCoursesCompleted'],
              preRequisiteCoursesNonCompleted:
                filterObj['preRequisiteCoursesNonCompleted'],
              resignationstatus: filterObj['resignationstatus'],
              searchMids: filterObj['searchMids']
            };
            this.arrangeByCourse = filterObj['arrangeByCourse'];
            this.cdmService
              .getAssignedRequests(
                filterObj['limit'],
                filterObj['index'],
                filterObj['nextOrPrevious'],
                payload
              )
              .then((requests: any) => {
                if (requests == null) {
                  requests = [];
                }
                this.requestsLoadedSuccessfully = true;
                this.requestsLoading = false;
                this.requests = requests.ActionedRequestsList;
                this.getSocialDetailsForRequests(this.requests);
                this.cdmService.updateLoadedRequestsDetails({
                  loadedRequestsLength: requests.ActionedRequestsList.length,
                  totalRequestsLength: requests.RequestCount
                });
              })
              .catch(err => {
                this.requestsLoadedSuccessfully = false;
                this.requestsLoading = false;
                this.requests = [];
              });
          }
        }
      });
  }
  getSocialDetailsForRequests(requests) {
    requests.forEach(request => {
      if (request.PackageID != 0 && request.PackageID != undefined) {
        request.PackageCourses = [];
        request.PacakgeCoursesLoaded = false;
        request.PacakgeCoursesLoading = false;
      }
      if (!this.arrangeByCourse) {
        request.header = false;
      } else {
        if (this.courseNames.indexOf(request.RequestedCourseName) == -1) {
          this.courseNames.push(request.RequestedCourseName);
          request.header = true;
        } else {
          request.header = false;
        }
      }
      this.getGraphDetails(request);

      //to check the status of pre-requisite course
      /* just empty the array */
      if (request.Cost == null) {
        request.Cost = '';
      }
      request.CostDetails = request.Cost.split('+');
      let prerequisiteCompletedArray = [];
      let prerequisiteNotCompletedArray = [];
      if (request.PreRequisiteCourses == null) request.PreRequisiteCourses = [];
      if (request.PreRequisiteCourses.length > 0) {
        request.PreRequisiteCourses.forEach((i, k) => {
          if (i.CompletedDate != null) {
            i.PreRequisiteCoursesStatus = 'Completed';
            prerequisiteCompletedArray[k] = i.PreRequisiteCoursesStatus;
          } else if (i.CompletedDate == null) {
            i.PreRequisiteCoursesStatus = 'Not Completed';
            prerequisiteNotCompletedArray[k] = i.PreRequisiteCoursesStatus;
          }
        });
        // if there is any item in this array then the pre-requisite is not completed otherwise it is completed
        if (
          prerequisiteNotCompletedArray.length != 0 &&
          request.IsPreRequisiteMandatory == true
        ) {
          request.PreRequisiteCoursesStatus = 'Not Completed';
        } else if (
          prerequisiteCompletedArray.length ==
            request.PreRequisiteCourses.length &&
          request.IsPreRequisiteMandatory == true
        ) {
          request.PreRequisiteCoursesStatus = 'Completed';
        } else if (
          prerequisiteNotCompletedArray.length != 0 &&
          request.IsPreRequisiteMandatory == false
        ) {
          request.PreRequisiteCoursesStatus =
            'Not Completed, but not Mandatory';
        } else if (
          prerequisiteCompletedArray.length ==
            request.PreRequisiteCourses.length &&
          request.IsPreRequisiteMandatory == false
        ) {
          request.PreRequisiteCoursesStatus = 'Completed';
        }
      } else {
        if (
          request.IsPreRequisiteMandatory == true ||
          request.IsPreRequisiteMandatory == false
        ) {
          request.PreRequisiteCoursesStatus = 'No Pre-Requisites';
        }
      }
    });
  }
  getGraphDetails(request) {
    this.assignedComponentSubscriptions.graphUserImageSub = this._graphSvc
      .getUserImage(request.UserId)
      .subscribe(
        data => {
          request.userImage = this.createImageURL(data);
        },
        error => {
          request.userImage = null;
        }
      );
    this.assignedComponentSubscriptions.graphUserNameSub = this._graphSvc
      .getUserName(request.UserId)
      .subscribe(
        data => {
          request.Name = data.value;
        },
        error => {
          request.Name = request.UserId;
        }
      );
    if (request.RMMID != null && request.RMMID != '') {
      this.assignedComponentSubscriptions.graphUserRMNameSub = this._graphSvc
        .getUserName(request.RMMID)
        .subscribe(
          data => {
            request.RMName = data.value;
          },
          error => {
            request.RMName = request.RMMID;
          }
        );
    } else {
      request.RMName = request.RMMID;
    }
    if (request.ActionedBy == null || request.ActionedBy == '') {
      //do not call graph api
    } else {
      this.assignedComponentSubscriptions.graphAssingerNamesub = this._graphSvc
        .getUserName(request.ActionedBy)
        .subscribe(
          data => {
            request.approverName = data.value;
          },
          error => {
            request.approverName = request.ActionedBy;
          }
        );
      this.assignedComponentSubscriptions.graphUserJobTitle = this._graphSvc
        .getUserJobTitle(request.ActionedBy)
        .subscribe(
          data => {
            request.approverDesignation = data.value;
          },
          error => {}
        );
    }
    // if (request.AssignedBy == null || request.AssignedBy == '') {
    //   //do not call graph api
    // } else {
    //   pssService.getUserName(request.AssignedBy).then(function(response) {
    //     request.assignerName = response.data.value;
    //   });
    // }
  }
  createImageURL(imageBlob) {
    const imageURL = this._window.URL.createObjectURL(imageBlob);
    return this.sanitizer.bypassSecurityTrustUrl(imageURL);
  }
  getCoursesStatusInsidePackage(request) {
    request.PacakgeCoursesLoading = true;
    this.cdmService
      .getCourseStatusInsidePackage(request.RequestId)
      .then(response => {
        request.PacakgeCoursesLoaded = true;
        request.PacakgeCoursesLoading = false;
        request.PackageCourses = response;
      });
  }
  ngOnDestroy() {
    this.unsubscribeAllSubscriptions();
  }
  unsubscribeAllSubscriptions() {
    for (let subscriberKey in this.assignedComponentSubscriptions) {
      let subscriber = this.assignedComponentSubscriptions[subscriberKey];
      if (subscriber instanceof Subscriber) {
        subscriber.unsubscribe();
      }
    }
  }
  ngOnInit() {
    this.subscribeToSearchStatus();
    this.subscribeToFilters();
    this.subscribeToSearchResults();
  }
}
