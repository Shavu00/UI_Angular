import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { CdmService } from '../../cdm.service';
import { ArrayPropertyFilterPipe } from 'libs/pipes/src/lib/array-property-filter.pipe';
import { GraphDataService } from '@YorbitWorkspace/graph';
import { WINDOW } from '../../../shared/services/window.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Subscriber } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'yorbit-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {
  requestFilters: any;
  mid: any;
  userRole: string;
  requests: Array<any>;
  requestsLoading: boolean;
  requestsLoadedSuccessfully: boolean;
  searchStatus: boolean;
  arrayPropertyFilter: any;
  startingIndex: number;
  arrangeByCourse: boolean;
  courseNames: Array<string>;
  requestActionsPayload: any;
  selectedIds: Array<string | number>;
  overallComments: string;
  groupApprovalInProgress: boolean;
  groupDenyInProgress: boolean;
  groupOnHoldInProgress: boolean;
  groupApprovalSuccess: boolean;
  groupDenySuccess: boolean;
  groupOnHoldSuccess: boolean;
  showSelectAll: boolean;
  searchComponentSubscriptions: any;
  showWarningForGroupRequests: boolean;
  warningMessage: string;
  selectedCourseNames: any;
  //requests types and data def
  reviewRequests: Array<any>;
  pendingRequests: Array<any>;
  actionedRequests: Array<any>;
  assignedRequests: Array<any>;
  invalidSearch: boolean;
  constructor(
    private cdmService: CdmService,
    private _graphSvc: GraphDataService,
    private sanitizer: DomSanitizer,
    @Inject(WINDOW) private _window: Window,
    private router: Router,
    private activatedRouter: ActivatedRoute
  ) {
    this.reviewRequests = [];
    this.pendingRequests = [];
    this.actionedRequests = [];
    this.assignedRequests = [];
    this.mid = '';
    this.requestFilters = {
      acceptedRequests: false,
      actionedNo: false,
      actionedYes: false,
      arrangeByCourse: false,
      arrangeByDate: false,
      billablestatus: '',
      competency: '',
      courseName: '',
      deniedRequests: false,
      isACMorPCMAssigned: false,
      isOther201sInProgress: false,
      location: '',
      onHoldRequests: false,
      preRequisiteCoursesCompleted: false,
      preRequisiteCoursesNonCompleted: false,
      resignationstatus: '',
      searchMids: []
    };
    this.userRole = '';
    this.requests = [];
    this.courseNames = [];
    this.selectedIds = [];
    this.selectedCourseNames = {};
    this.overallComments = '';
    this.groupApprovalInProgress = false;
    this.groupDenyInProgress = false;
    this.groupOnHoldInProgress = false;
    this.groupApprovalSuccess = false;
    this.groupDenySuccess = false;
    this.groupOnHoldSuccess = false;
    this.showSelectAll = true;
    this.requestsLoading = true;
    this.requestsLoadedSuccessfully = false;
    this.arrangeByCourse = false;
    this.searchStatus = false;
    this.searchComponentSubscriptions = {};

    this.arrayPropertyFilter = new ArrayPropertyFilterPipe();
    this.startingIndex = 0;
    this.requestActionsPayload = {
      ItemsIds: [],
      Comments: null
    };
    this.showWarningForGroupRequests = false;
    this.warningMessage = '';
    this.invalidSearch = false;
    this.subscribeToRouterparams();
  }

  ngOnInit() {
    this.subscribeToUserRole();
    this.updateSearchStatus();
    this.subscribeToSearchResults();
    this.subscribeToFilters();
  }
  subscribeToRouterparams() {
    this.activatedRouter.params.subscribe(params => {
      if (params['mid'] == undefined || params['mid'] == null) {
        this.invalidSearch = true;
        this.requestsLoading = false;
        this.requestsLoadedSuccessfully = true;
      } else {
        this.invalidSearch = false;
        this.mid = params['mid'];
        this.requestsLoading = true;
        this.requestsLoadedSuccessfully = false;
      }
    });
  }
  removeGlobalWarningMessage(event) {
    this.showWarningForGroupRequests = false;
    //console.log('overallComments', this.overallComments);
  }
  subscribeToUserRole() {
    this.searchComponentSubscriptions.subscribeToUserRole = this.cdmService
      .getRoleOfUser()
      .subscribe(role => {
        if (role == 'cdm') {
          this.userRole = 'cdm';
          this.warningMessage = 'Give comments to hold/deny a request!';
        } else if (role == 'rm') {
          this.userRole = 'rm';
          this.warningMessage = 'Give comments to deny a request!';
        }
      });
  }
  clearPayload() {
    this.requestActionsPayload = {
      ItemsIds: [],
      Comments: null
    };
  }
  updateSearchStatus() {
    this.cdmService.updateSearchStatus(true);
  }
  subscribeToSearchResults() {
    this.searchComponentSubscriptions.searchResultsSubscription = this.cdmService
      .getSearchResults()
      .subscribe(requests => {
        if (requests == null) {
          requests = [];
        }
        this.requests = [];
        this.pendingRequests = [];
        this.reviewRequests = [];
        this.actionedRequests = [];
        this.assignedRequests = [];
        this.requests = requests;
        this.getSocialDetailsForRequests(this.requests);
        this.requestsLoadedSuccessfully = true;
        this.requestsLoading = false;
      });
  }
  subscribeToFilters() {
    this.searchComponentSubscriptions.filtersSub = this.cdmService
      .getRequestsFilters()
      .subscribe(filterObj => {
        this.startingIndex = parseInt(filterObj['index']);
        this.courseNames = [];
        this.selectedIds = [];
        this.overallComments = '';
        this.groupApprovalInProgress = false;
        this.groupDenyInProgress = false;
        this.groupOnHoldInProgress = false;
        this.groupApprovalSuccess = false;
        this.groupDenySuccess = false;
        this.groupOnHoldSuccess = false;
        this.showSelectAll = true;
        this.arrangeByCourse = filterObj['arrangeByCourse'];
        this.requestsLoading = true;
        this.requestsLoadedSuccessfully = false;
        let payload = {
          acceptedRequests: filterObj['acceptedRequests'],
          actionedNo: filterObj['actionedNo'],
          actionedYes: filterObj['actionedYes'],
          arrangeByCourse: filterObj['arrangeByCourse'],
          arrangeByDate: filterObj['arrangeByDate'],
          billablestatus: filterObj['billablestatus'],
          competency: filterObj['competency'],
          courseName: filterObj['courseName'],
          deniedRequests: filterObj['deniedRequests'],
          isACMorPCMAssigned: filterObj['isACMorPCMAssigned'],
          isOther201sInProgress: filterObj['isOther201sInProgress'],
          location: filterObj['location'],
          onHoldRequests: filterObj['onHoldRequests'],
          preRequisiteCoursesCompleted:
            filterObj['preRequisiteCoursesCompleted'],
          preRequisiteCoursesNonCompleted:
            filterObj['preRequisiteCoursesNonCompleted'],
          resignationstatus: filterObj['resignationstatus'],
          searchMids: [this.mid.toString()]
        };
        let isCertificationSelected = false;
        this.cdmService.getSearchResultsFromAPI(
          filterObj['limit'],
          filterObj['index'],
          filterObj['nextOrPrevious'],
          payload,
          isCertificationSelected,
          this.userRole
        );
      });
  }
  getSocialDetailsForRequests(requests) {
    requests.forEach(request => {
      if (request.Status.toLowerCase() == 'under review') {
        request.showWarning = false;
        request.comments = '';
        request.checked = false;
        request.approved = false;
        request.denied = false;
        request.onHold = false;
        request.approveInProgress = false;
        request.denyInProgress = false;
        request.holdInProgress = false;
        if (request.PackageID != 0 && request.PackageID != undefined) {
          request.PackageCourses = [];
          request.PacakgeCoursesLoaded = false;
          request.PacakgeCoursesLoading = false;
        }
        if (!this.arrangeByCourse) {
          request.header = false;
        } else {
          this.selectedIds = [];
          if (this.courseNames.indexOf(request.RequestedCourseName) == -1) {
            this.courseNames.push(request.RequestedCourseName);
            this.selectedCourseNames[request.RequestedCourseName] = false;
            request.header = true;
          } else {
            request.header = false;
          }
        }
        this.getGraphDetails(request);

        //to check the status of pre-requisite course
        /* just empty the array */
        if (request.Cost == null) {
          request.Cost = '';
        }
        request.CostDetails = request.Cost.split('+');
        let prerequisiteCompletedArray = [];
        let prerequisiteNotCompletedArray = [];
        if (request.PreRequisiteCourses == null)
          request.PreRequisiteCourses = [];
        if (request.PreRequisiteCourses.length > 0) {
          request.PreRequisiteCourses.forEach((i, k) => {
            if (i.CompletedDate != null) {
              i.PreRequisiteCoursesStatus = 'Completed';
              prerequisiteCompletedArray[k] = i.PreRequisiteCoursesStatus;
            } else if (i.CompletedDate == null) {
              i.PreRequisiteCoursesStatus = 'Not Completed';
              prerequisiteNotCompletedArray[k] = i.PreRequisiteCoursesStatus;
            }
          });
          // if there is any item in this array then the pre-requisite is not completed otherwise it is completed
          if (
            prerequisiteNotCompletedArray.length != 0 &&
            request.IsPreRequisiteMandatory == true
          ) {
            request.PreRequisiteCoursesStatus = 'Not Completed';
          } else if (
            prerequisiteCompletedArray.length ==
              request.PreRequisiteCourses.length &&
            request.IsPreRequisiteMandatory == true
          ) {
            request.PreRequisiteCoursesStatus = 'Completed';
          } else if (
            prerequisiteNotCompletedArray.length != 0 &&
            request.IsPreRequisiteMandatory == false
          ) {
            request.PreRequisiteCoursesStatus =
              'Not Completed, but not Mandatory';
          } else if (
            prerequisiteCompletedArray.length ==
              request.PreRequisiteCourses.length &&
            request.IsPreRequisiteMandatory == false
          ) {
            request.PreRequisiteCoursesStatus = 'Completed';
          }
        } else {
          if (
            request.IsPreRequisiteMandatory == true ||
            request.IsPreRequisiteMandatory == false
          ) {
            request.PreRequisiteCoursesStatus = 'No Pre-Requisites';
          }
        }
        this.reviewRequests.push(request);
      } else if (request.Status == 'Pending' && request.IsAssigned == false) {
        request.showWarning = false;
        request.comments = '';
        request.checked = false;
        request.approved = false;
        request.denied = false;
        request.onHold = false;
        request.approveInProgress = false;
        request.denyInProgress = false;
        request.holdInProgress = false;
        if (request.PackageID != 0 && request.PackageID != undefined) {
          request.PackageCourses = [];
          request.PacakgeCoursesLoaded = false;
          request.PacakgeCoursesLoading = false;
        }
        if (!this.arrangeByCourse) {
          request.header = false;
        } else {
          this.selectedIds = [];
          if (this.courseNames.indexOf(request.RequestedCourseName) == -1) {
            this.courseNames.push(request.RequestedCourseName);
            this.selectedCourseNames[request.RequestedCourseName] = false;
            request.header = true;
          } else {
            request.header = false;
          }
        }
        this.getGraphDetails(request);

        //to check the status of pre-requisite course
        /* just empty the array */
        if (request.Cost == null) {
          request.Cost = '';
        }
        request.CostDetails = request.Cost.split('+');
        let prerequisiteCompletedArray = [];
        let prerequisiteNotCompletedArray = [];
        if (request.PreRequisiteCourses == null)
          request.PreRequisiteCourses = [];
        if (request.PreRequisiteCourses.length > 0) {
          request.PreRequisiteCourses.forEach((i, k) => {
            if (i.CompletedDate != null) {
              i.PreRequisiteCoursesStatus = 'Completed';
              prerequisiteCompletedArray[k] = i.PreRequisiteCoursesStatus;
            } else if (i.CompletedDate == null) {
              i.PreRequisiteCoursesStatus = 'Not Completed';
              prerequisiteNotCompletedArray[k] = i.PreRequisiteCoursesStatus;
            }
          });
          // if there is any item in this array then the pre-requisite is not completed otherwise it is completed
          if (
            prerequisiteNotCompletedArray.length != 0 &&
            request.IsPreRequisiteMandatory == true
          ) {
            request.PreRequisiteCoursesStatus = 'Not Completed';
          } else if (
            prerequisiteCompletedArray.length ==
              request.PreRequisiteCourses.length &&
            request.IsPreRequisiteMandatory == true
          ) {
            request.PreRequisiteCoursesStatus = 'Completed';
          } else if (
            prerequisiteNotCompletedArray.length != 0 &&
            request.IsPreRequisiteMandatory == false
          ) {
            request.PreRequisiteCoursesStatus =
              'Not Completed, but not Mandatory';
          } else if (
            prerequisiteCompletedArray.length ==
              request.PreRequisiteCourses.length &&
            request.IsPreRequisiteMandatory == false
          ) {
            request.PreRequisiteCoursesStatus = 'Completed';
          }
        } else {
          if (
            request.IsPreRequisiteMandatory == true ||
            request.IsPreRequisiteMandatory == false
          ) {
            request.PreRequisiteCoursesStatus = 'No Pre-Requisites';
          }
        }
        this.pendingRequests.push(request);
      } else if (request.IsAssigned == true) {
        if (request.PackageID != 0 && request.PackageID != undefined) {
          request.PackageCourses = [];
          request.PacakgeCoursesLoaded = false;
          request.PacakgeCoursesLoading = false;
        }
        if (!this.arrangeByCourse) {
          request.header = false;
        } else {
          if (this.courseNames.indexOf(request.RequestedCourseName) == -1) {
            this.courseNames.push(request.RequestedCourseName);
            request.header = true;
          } else {
            request.header = false;
          }
        }
        this.getGraphDetails(request);

        //to check the status of pre-requisite course
        /* just empty the array */
        if (request.Cost == null) {
          request.Cost = '';
        }
        request.CostDetails = request.Cost.split('+');
        let prerequisiteCompletedArray = [];
        let prerequisiteNotCompletedArray = [];
        if (request.PreRequisiteCourses == null)
          request.PreRequisiteCourses = [];
        if (request.PreRequisiteCourses.length > 0) {
          request.PreRequisiteCourses.forEach((i, k) => {
            if (i.CompletedDate != null) {
              i.PreRequisiteCoursesStatus = 'Completed';
              prerequisiteCompletedArray[k] = i.PreRequisiteCoursesStatus;
            } else if (i.CompletedDate == null) {
              i.PreRequisiteCoursesStatus = 'Not Completed';
              prerequisiteNotCompletedArray[k] = i.PreRequisiteCoursesStatus;
            }
          });
          // if there is any item in this array then the pre-requisite is not completed otherwise it is completed
          if (
            prerequisiteNotCompletedArray.length != 0 &&
            request.IsPreRequisiteMandatory == true
          ) {
            request.PreRequisiteCoursesStatus = 'Not Completed';
          } else if (
            prerequisiteCompletedArray.length ==
              request.PreRequisiteCourses.length &&
            request.IsPreRequisiteMandatory == true
          ) {
            request.PreRequisiteCoursesStatus = 'Completed';
          } else if (
            prerequisiteNotCompletedArray.length != 0 &&
            request.IsPreRequisiteMandatory == false
          ) {
            request.PreRequisiteCoursesStatus =
              'Not Completed, but not Mandatory';
          } else if (
            prerequisiteCompletedArray.length ==
              request.PreRequisiteCourses.length &&
            request.IsPreRequisiteMandatory == false
          ) {
            request.PreRequisiteCoursesStatus = 'Completed';
          }
        } else {
          if (
            request.IsPreRequisiteMandatory == true ||
            request.IsPreRequisiteMandatory == false
          ) {
            request.PreRequisiteCoursesStatus = 'No Pre-Requisites';
          }
        }
        this.assignedRequests.push(request);
      } else if (
        (request.Status == 'Rejected' ||
          request.Status == 'Approved' ||
          request.Status == 'On Hold' ||
          request.Status == 'Cancelled' ||
          request.Status == 'Completed' ||
          request.Status == 'Not Started') &&
        request.IsAssigned == false
      ) {
        request.comments = '';
        request.showWarning = false;
        if (request.Status == 'Rejected') {
          request.Status = 'Denied';
        }
        if (!this.arrangeByCourse) {
          request.header = false;
        } else {
          if (this.courseNames.indexOf(request.RequestedCourseName) == -1) {
            this.courseNames.push(request.RequestedCourseName);
            request.header = true;
          } else {
            request.header = false;
          }
        }
        this.getGraphDetails(request);

        //to check the status of pre-requisite course
        /* just empty the array */
        if (request.Cost == null) {
          request.Cost = '';
        }
        request.CostDetails = request.Cost.split('+');
        let prerequisiteCompletedArray = [];
        let prerequisiteNotCompletedArray = [];
        if (request.PreRequisiteCourses == null)
          request.PreRequisiteCourses = [];
        if (request.PreRequisiteCourses.length > 0) {
          request.PreRequisiteCourses.forEach((i, k) => {
            if (i.CompletedDate != null) {
              i.PreRequisiteCoursesStatus = 'Completed';
              prerequisiteCompletedArray[k] = i.PreRequisiteCoursesStatus;
            } else if (i.CompletedDate == null) {
              i.PreRequisiteCoursesStatus = 'Not Completed';
              prerequisiteNotCompletedArray[k] = i.PreRequisiteCoursesStatus;
            }
          });
          // if there is any item in this array then the pre-requisite is not completed otherwise it is completed
          if (
            prerequisiteNotCompletedArray.length != 0 &&
            request.IsPreRequisiteMandatory == true
          ) {
            request.PreRequisiteCoursesStatus = 'Not Completed';
          } else if (
            prerequisiteCompletedArray.length ==
              request.PreRequisiteCourses.length &&
            request.IsPreRequisiteMandatory == true
          ) {
            request.PreRequisiteCoursesStatus = 'Completed';
          } else if (
            prerequisiteNotCompletedArray.length != 0 &&
            request.IsPreRequisiteMandatory == false
          ) {
            request.PreRequisiteCoursesStatus =
              'Not Completed, but not Mandatory';
          } else if (
            prerequisiteCompletedArray.length ==
              request.PreRequisiteCourses.length &&
            request.IsPreRequisiteMandatory == false
          ) {
            request.PreRequisiteCoursesStatus = 'Completed';
          }
        } else {
          if (
            request.IsPreRequisiteMandatory == true ||
            request.IsPreRequisiteMandatory == false
          ) {
            request.PreRequisiteCoursesStatus = 'No Pre-Requisites';
          }
        }
        this.actionedRequests.push(request);
      }
    });
  }
  getGraphDetails(request) {
    if (request.Status.toLowerCase() == 'under review') {
      this.searchComponentSubscriptions.graphUserImageSub = this._graphSvc
        .getUserImage(request.UserId)
        .subscribe(
          data => {
            request.userImage = this.createImageURL(data);
          },
          error => {
            request.userImage = null;
          }
        );
      this.searchComponentSubscriptions.graphUserNameSub = this._graphSvc
        .getUserName(request.UserId)
        .subscribe(
          data => {
            request.Name = data.value;
          },
          error => {
            request.Name = request.UserId;
          }
        );
      if (request.RMMID != null && request.RMMID != '') {
        this.searchComponentSubscriptions.graphUserRMName = this._graphSvc
          .getUserName(request.RMMID)
          .subscribe(
            data => {
              request.RMName = data.value;
            },
            error => {
              request.RMName = request.RMMID;
            }
          );
      } else {
        request.RMName = request.RMMID;
      }
      if (
        (!request.IsSkillPlan && !request.IsCrossSkill) ||
        (request.IsSkillPlan && !request.IsCrossSkill && !request.IsFutureSkill)
      ) {
        if (request.AssignedBy != '' && request.AssignedBy != null) {
          this._graphSvc.getUserName(request.AssignedBy).subscribe(
            response => {
              request.AssignerName = response.value;
            },
            err => {
              request.AssignerName = request.AssignedBy;
            }
          );
        } else if (request.IsSkillPlan || request.IsCrossSkill) {
          request.AssignedBy = 'NA';
          request.AssignerName = 'NA';
        }
      } else if (
        request.IsSkillPlan ||
        request.IsCrossSkill ||
        request.IsFutureSkill
      ) {
        //do not call graph api
        request.AssignedBy = 'SELF';
        request.AssignerName = 'SELF';
      }
    } else if (request.Status == 'Pending' && request.IsAssigned == false) {
      this.searchComponentSubscriptions.graphUserImageSub = this._graphSvc
        .getUserImage(request.UserId)
        .subscribe(
          data => {
            request.userImage = this.createImageURL(data);
          },
          error => {
            request.userImage = null;
          }
        );
      this.searchComponentSubscriptions.graphUserNameSub = this._graphSvc
        .getUserName(request.UserId)
        .subscribe(
          data => {
            request.Name = data.value;
          },
          error => {
            request.Name = request.UserId;
          }
        );
      if (request.RMMID != null && request.RMMID != '') {
        this.searchComponentSubscriptions.graphUserRMNameSub = this._graphSvc
          .getUserName(request.RMMID)
          .subscribe(
            data => {
              request.RMName = data.value;
            },
            error => {
              request.RMName = request.RMMID;
            }
          );
      } else {
        request.RMName = request.RMMID;
      }
      // this.getImages(request.UserId);
      // pssService.getUserName(request.UserId).then(function(response) {
      //   request.Name = response.data.value;
      // });
      // // to get RM Name
      // if (request.RMMID == null || request.RMMID == '') {
      //   //do not call graph api
      // } else {
      //   pssService.getUserName(request.RMMID).then(function(response) {
      //     request.RMName = response.data.value;
      //   });
      // }
      // if (request.ActionedBy == null || request.ActionedBy == '') {
      //   //do not call graph api
      // } else if (request.ActionedBy.toLowerCase() == 'auto approved') {
      //   request.approverName = 'AUTO APPROVED';
      // } else {
      //   pssService.getUserName(request.ActionedBy).then(function(response) {
      //     request.approverName = response.data.value;
      //   });
      //   pssService.getUserJobTitle(request.ActionedBy).then(function(response) {
      //     request.approverDesignation = response.data.value;
      //   });
      // }

      if (
        (!request.IsSkillPlan && !request.IsCrossSkill) ||
        (request.IsSkillPlan && !request.IsCrossSkill && !request.IsFutureSkill)
      ) {
        if (request.AssignedBy != '' && request.AssignedBy != null) {
          this._graphSvc.getUserName(request.AssignedBy).subscribe(
            response => {
              request.AssignerName = response.value;
            },
            err => {
              request.AssignerName = request.AssignedBy;
            }
          );
        } else if (request.IsSkillPlan || request.IsCrossSkill) {
          request.AssignedBy = 'NA';
          request.AssignerName = 'NA';
        }
      } else if (
        request.IsSkillPlan &&
        (request.IsCrossSkill || request.IsFutureSkill)
      ) {
        //do not call graph api
        request.AssignedBy = 'SELF';
        request.AssignerName = 'SELF';
      }
    } else if (request.IsAssigned == true) {
      this.searchComponentSubscriptions.graphUserImageSub = this._graphSvc
        .getUserImage(request.UserId)
        .subscribe(
          data => {
            request.userImage = this.createImageURL(data);
          },
          error => {
            request.userImage = null;
          }
        );
      this.searchComponentSubscriptions.graphUserNameSub = this._graphSvc
        .getUserName(request.UserId)
        .subscribe(
          data => {
            request.Name = data.value;
          },
          error => {
            request.Name = request.UserId;
          }
        );
      if (request.RMMID != null && request.RMMID != '') {
        this.searchComponentSubscriptions.graphUserRMNameSub = this._graphSvc
          .getUserName(request.RMMID)
          .subscribe(
            data => {
              request.RMName = data.value;
            },
            error => {
              request.RMName = request.RMMID;
            }
          );
      } else {
        request.RMName = request.RMMID;
      }
      if (request.ActionedBy == null || request.ActionedBy == '') {
        //do not call graph api
      } else {
        this.searchComponentSubscriptions.graphAssingerNamesub = this._graphSvc
          .getUserName(request.ActionedBy)
          .subscribe(
            data => {
              request.approverName = data.value;
            },
            error => {
              request.approverName = request.ActionedBy;
            }
          );
        this.searchComponentSubscriptions.graphUserJobTitle = this._graphSvc
          .getUserJobTitle(request.ActionedBy)
          .subscribe(
            data => {
              request.approverDesignation = data.value;
            },
            error => {}
          );
      }
      if (request.AssignedBy == null || request.AssignedBy == '') {
        //do not call graph api
      } else {
        this._graphSvc.getUserName(request.AssignedBy).subscribe(response => {
          request.AssignerName = response.value;
        });
      }
    } else if (
      (request.Status == 'Rejected' ||
        request.Status == 'Approved' ||
        request.Status == 'On Hold' ||
        request.Status == 'Cancelled' ||
        request.Status == 'Completed' ||
        request.Status == 'Not Started') &&
      request.IsAssigned == false
    ) {
      this.searchComponentSubscriptions.graphUserImageSub = this._graphSvc
        .getUserImage(request.UserId)
        .subscribe(
          data => {
            request.userImage = this.createImageURL(data);
          },
          error => {
            request.userImage = null;
          }
        );
      this.searchComponentSubscriptions.graphUserNameSub = this._graphSvc
        .getUserName(request.UserId)
        .subscribe(
          data => {
            request.Name = data.value;
          },
          error => {
            request.Name = request.UserId;
          }
        );
      if (request.RMMID != null && request.RMMID != '') {
        this.searchComponentSubscriptions.userRMNameSub = this._graphSvc
          .getUserName(request.RMMID)
          .subscribe(
            data => {
              request.RMName = data.value;
            },
            error => {
              request.RMName = request.RMMID;
            }
          );
      } else {
        request.RMName = request.RMMID;
      }
      if (request.ActionedBy == null || request.ActionedBy == '') {
        //do not call graph api
      } else if (request.ActionedBy.toLowerCase() == 'auto approved') {
        request.approverName = 'AUTO APPROVED';
      } else {
        this.searchComponentSubscriptions.getUserApproverNameSub = this._graphSvc
          .getUserName(request.ActionedBy)
          .subscribe(
            data => {
              request.approverName = data.value;
            },
            error => {
              request.approverName = request.ActionedBy;
            }
          );
        this._graphSvc.getUserJobTitle(request.ActionedBy).subscribe(
          data => {
            request.approverDesignation = data.value;
          },
          error => {}
        );
      }
      if (request.AssignedBy == null || request.AssignedBy == '') {
        //do not call graph api
      } else {
        this._graphSvc.getUserName(request.AssignedBy).subscribe(data => {
          request.AssignerName = data.value;
        });
      }
    }
  }
  createImageURL(imageBlob) {
    const imageURL = this._window.URL.createObjectURL(imageBlob);
    return this.sanitizer.bypassSecurityTrustUrl(imageURL);
  }
  approveRequest(request) {
    this.clearPayload();
    this.requestActionsPayload.ItemsIds.push(request.RequestId);
    this.requestActionsPayload.Comments = request.comments;
    request.approveInProgress = true;
    //api to approve
    this.cdmService
      .approveRequests(this.requestActionsPayload, false)
      .then(response => {
        request.approveInProgress = false;
        request.approved = true;
      })
      .catch(err => {
        request.approveInProgress = false;
        request.approved = false;
      });
  }
  approveSelectedRequests() {
    this.clearPayload();
    this.requestActionsPayload.ItemsIds = this.selectedIds;
    this.requestActionsPayload.Comments = this.overallComments;
    this.groupApprovalInProgress = true;
    //api to approve
    this.cdmService
      .approveRequests(this.requestActionsPayload, false)
      .then(response => {
        this.groupApprovalInProgress = false;
        this.groupApprovalSuccess = true;
        this.requests.forEach(request => {
          if (this.selectedIds.indexOf(request.RequestId) != -1) {
            request.approveInProgress = false;
            request.approved = true;
          }
        });
      })
      .catch(err => {
        this.groupApprovalInProgress = false;
        this.groupApprovalSuccess = false;
        this.requests.forEach(request => {
          if (this.selectedIds.indexOf(request.RequestId) != -1) {
            request.approveInProgress = false;
            request.approved = false;
          }
        });
      });
  }
  denyRequest(request) {
    this.clearPayload();
    if (request.comments.length != 0) {
      request.showWarning = false;
      this.requestActionsPayload.ItemsIds.push(request.RequestId);
      this.requestActionsPayload.Comments = request.comments;
      request.denyInProgress = true;
      //call api to deny
      this.cdmService
        .denyRequests(this.requestActionsPayload, false)
        .then(response => {
          request.denyInProgress = false;
          request.denied = true;
        })
        .catch(err => {
          request.denyInProgress = false;
          request.denied = false;
        });
    } else {
      request.showWarning = true;
      //show error msg
    }
  }
  denySelectedRequests() {
    this.clearPayload();
    if (this.overallComments.length != 0) {
      this.showWarningForGroupRequests = false;
      this.requestActionsPayload.ItemsIds = this.selectedIds;
      this.requestActionsPayload.Comments = this.overallComments;
      this.groupDenyInProgress = true;
      //api to deny
      this.cdmService
        .denyRequests(this.requestActionsPayload, false)
        .then(response => {
          this.groupDenyInProgress = false;
          this.groupDenySuccess = true;
          this.requests.forEach(request => {
            if (this.selectedIds.indexOf(request.RequestId) != -1) {
              request.denyInProgress = false;
              request.denied = true;
            }
          });
        })
        .catch(err => {
          this.groupDenyInProgress = false;
          this.groupDenySuccess = false;
          this.requests.forEach(request => {
            if (this.selectedIds.indexOf(request.RequestId) != -1) {
              request.denyInProgress = false;
              request.denied = false;
            }
          });
        });
    } else {
      this.showWarningForGroupRequests = true;
      //show error msg
    }
  }
  holdRequest(request) {
    this.clearPayload();
    if (request.comments.length != 0) {
      request.showWarning = false;
      this.requestActionsPayload.ItemsIds.push(request.RequestId);
      this.requestActionsPayload.Comments = request.comments;
      request.holdInProgress = true;
      //api to onhold
      this.cdmService
        .holdRequests(this.requestActionsPayload, false)
        .then(response => {
          request.holdInProgress = false;
          request.onHold = true;
        })
        .catch(err => {
          request.holdInProgress = false;
          request.onHold = false;
        });
    } else {
      request.showWarning = true;
      //show error msg
    }
  }
  holdSelectedRequests() {
    this.clearPayload();
    if (this.overallComments.length != 0) {
      this.showWarningForGroupRequests = false;
      this.requestActionsPayload.ItemsIds = this.selectedIds;
      this.requestActionsPayload.Comments = this.overallComments;
      this.groupOnHoldInProgress = true;
      this.cdmService
        .holdRequests(this.requestActionsPayload, false)
        .then(response => {
          this.groupOnHoldInProgress = false;
          this.groupOnHoldSuccess = true;
          this.requests.forEach(request => {
            if (this.selectedIds.indexOf(request.RequestId) != -1) {
              request.holdInProgress = false;
              request.onHold = true;
            }
          });
        })
        .catch(err => {
          this.groupOnHoldInProgress = false;
          this.groupOnHoldSuccess = false;
          this.requests.forEach(request => {
            if (this.selectedIds.indexOf(request.RequestId) != -1) {
              request.holdInProgress = false;
              request.onHold = false;
            }
          });
        });
    } else {
      this.showWarningForGroupRequests = true;
      //show error msg
    }
  }
  getCoursesStatusInsidePackage(request) {
    request.PacakgeCoursesLoading = true;
    this.cdmService
      .getCourseStatusInsidePackage(request.RequestId)
      .then(response => {
        request.PacakgeCoursesLoaded = true;
        request.PacakgeCoursesLoading = false;
        request.PackageCourses = response;
      });
  }
  ngOnDestroy() {
    this.unsubscribeAllSubscriptions();
  }
  unsubscribeAllSubscriptions() {
    for (let subscriberKey in this.searchComponentSubscriptions) {
      let subscriber = this.searchComponentSubscriptions[subscriberKey];
      if (subscriber instanceof Subscriber) {
        subscriber.unsubscribe();
      }
    }
  }
}
