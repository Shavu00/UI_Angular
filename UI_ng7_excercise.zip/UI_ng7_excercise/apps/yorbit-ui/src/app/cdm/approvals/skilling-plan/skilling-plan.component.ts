import { Component, OnInit } from '@angular/core';
import { SkillingPlanService } from './skilling-plan.service';
@Component({
  selector: 'yorbit-skilling-plan',
  templateUrl: './skilling-plan.component.html',
  styleUrls: ['./skilling-plan.component.scss']
})
export class SkillingPlanComponent implements OnInit {
  skillPlans: Array<string>;
  skillPlansLoading: boolean;
  skillPlansLoadedSuccessfully: boolean;
  skillPlanDetails: any;
  constructor(private skillingPlanService: SkillingPlanService) {
    this.skillPlans = [];
    this.skillPlansLoading = true;
    this.skillPlansLoadedSuccessfully = false;
    this.skillPlanDetails = {};
  }

  ngOnInit() {
    this.getSkillPlans();
  }
  getSkillPlans() {
    this.skillingPlanService
      .getSkillPlans()
      .then((plans: any) => {
        this.skillPlans = plans;
        this.skillPlansLoading = false;
        this.skillPlansLoadedSuccessfully = true;
        this.skillPlans.forEach((plan: any) => {
          plan.showSkills = true;
          this.skillPlanDetails[plan.Id] = {
            loading: true,
            loadedSuccessfully: false,
            skills: []
          };
        });
      })
      .catch(err => {
        this.skillPlansLoading = false;
        this.skillPlansLoadedSuccessfully = false;
      });
  }
  getSkillPlanDetails(id) {
    this.skillingPlanService
      .getSkillPlanDetails(id)
      .then((skills: any) => {
        this.skillPlanDetails[id] = {
          loadedSuccessfully: true,
          loading: false,
          skills: skills
        };
      })
      .catch(err => {
        this.skillPlanDetails[id] = {
          loadedSuccessfully: true,
          loading: false,
          skills: []
        };
      });
  }
}
