import { Component, OnInit, Inject, OnDestroy, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { CdmService } from '../cdm.service';
import { WINDOW } from '../../shared/services/window.service';
import { DomSanitizer } from '@angular/platform-browser';
import { GraphDataService } from '@YorbitWorkspace/graph';
import { MatMenuTrigger } from '@angular/material';
import { Subscriber } from 'rxjs';

@Component({
  selector: 'yorbit-approvals',
  templateUrl: './approvals.component.html',
  styleUrls: ['./approvals.component.scss']
})
export class ApprovalsComponent implements OnInit, OnDestroy {
  @ViewChild('cdmNavbar') cdmNavbar: any;
  selectedTab: string;
  userRole: string | null;
  searchStatus: boolean;
  requestFilters: any;
  requestsLimit: number;
  requestsIndex: number;
  loadNextOrPrevious: string;
  loadedRequestsLength: number;
  totalRequestsLength: number;
  isACMorPCMAssigned: boolean;
  preRequisiteCoursesCompleted: boolean;
  competency: string;
  location: string;
  billableStatus: string;
  resignationStatus: string;
  arrangeByCourseFlag: boolean;
  coursesList: any;
  acceptedFilterSelected: boolean;
  deniedFilterSelected: boolean;
  onHoldFilterSelected: boolean;
  competencyList: any;
  billableStatusList: any;
  locationList: any;
  suggestionList: any;
  searchBy: string;
  showSuggestionsList: boolean;
  showSearchIcon: boolean;
  selectedRequestsForAction: Array<any>;
  selectedCourse: string;
  approvalsComponentSubscriptions: any;
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private cdmService: CdmService,
    private sanitizer: DomSanitizer,
    @Inject(WINDOW) private _window: Window,
    private _graphSvc: GraphDataService
  ) {
    this.userRole = '';
    this.searchStatus = false;
    this.selectedTab = 'review';
    this.requestFilters = {
      acceptedRequests: false,
      actionedNo: false,
      actionedYes: false,
      arrangeByCourse: false,
      arrangeByDate: false,
      billablestatus: '',
      competency: '',
      courseName: '',
      deniedRequests: false,
      isACMorPCMAssigned: false,
      isOther201sInProgress: false,
      location: '',
      onHoldRequests: false,
      preRequisiteCoursesCompleted: false,
      preRequisiteCoursesNonCompleted: false,
      resignationstatus: '',
      searchMids: [],
      tab: this.selectedTab
    };
    this.coursesList = [];
    this.suggestionList = [];
    this.requestsLimit = 20;
    this.requestsIndex = 0;
    this.loadNextOrPrevious = 'next';
    this.loadedRequestsLength = 0;
    this.totalRequestsLength = 0;
    this.isACMorPCMAssigned = false;
    this.preRequisiteCoursesCompleted = false;
    this.competency = '';
    this.location = '';
    this.billableStatus = '';
    this.resignationStatus = '';
    this.acceptedFilterSelected = false;
    this.deniedFilterSelected = false;
    this.onHoldFilterSelected = false;
    this.searchBy = '';
    this.showSearchIcon = true;
    this.showSuggestionsList = false;
    this.selectedRequestsForAction = [];
    this.selectedCourse = '';
    this.approvalsComponentSubscriptions = {};
    this.subscribeToRouter();
    this.subscribeToSearchStatus();
    this.subscribeToFilters();
    this.subscribeToLoadedRequestsData();
    this.getCompetency();
    this.getLocation();
    this.getBillableStatus();
  }

  ngOnInit() {
    this.setSelectedTabAndUserRole();
  }
  subscribeToLoadedRequestsData() {
    this.approvalsComponentSubscriptions.getLoadedRequestsSub = this.cdmService
      .getLoadedRequestsDetails()
      .subscribe((data: any) => {
        this.loadedRequestsLength = parseInt(data['loadedRequestsLength']);
        this.totalRequestsLength = parseInt(data['totalRequestsLength']);
      });
  }
  getCompetency() {
    this.cdmService.getCompetencyList().then(competencyList => {
      this.competencyList = competencyList;
    });
  }
  getLocation() {
    this.cdmService.getLocationList().then(locationList => {
      this.locationList = locationList;
    });
  }
  getBillableStatus() {
    this.cdmService.getBillableStatusList().then(billableStatusList => {
      this.billableStatusList = billableStatusList;
    });
  }
  setSelectedTabAndUserRole() {
    if (this.router.url.indexOf('cdm') != -1) {
      this.selectedTab = this.router.url.split('cdm/')[1];
      this.userRole = 'cdm';
      this.cdmService.updateRoleOfUser('cdm');
    } else if (this.router.url.indexOf('rm') != -1) {
      this.selectedTab = this.router.url.split('rm/')[1];
      this.userRole = 'rm';
      this.cdmService.updateRoleOfUser('rm');
    }
    if (this.router.url.indexOf('search')!=-1) {
      this.searchBy = this.router.url.split('search/')[1];
      this.showSearchIcon = false;
    }
    this.requestFilters = { ...this.requestFilters, tab: this.selectedTab };
    this.updateRequestFilters(this.requestFilters);
  }
  subscribeToRouter() {
    this.approvalsComponentSubscriptions.routerEventsSub = this.router.events
      .pipe(filter(events => events instanceof NavigationEnd))
      .subscribe((event: any) => {
        this.setSelectedTabAndUserRole();
      });
  }
  loadChildComponents(tab) {
    if (!this.searchStatus) {
      this.resetAllFilters();
      let filtersObj = {
        limit: 20,
        index: 0,
        nextOrPrevious: 'next',
        acceptedRequests: false,
        actionedNo: false,
        actionedYes: false,
        arrangeByCourse: false,
        arrangeByDate: false,
        billablestatus: '',
        competency: '',
        courseName: '',
        deniedRequests: false,
        isACMorPCMAssigned: false,
        isOther201sInProgress: false,
        location: '',
        onHoldRequests: false,
        preRequisiteCoursesCompleted: false,
        preRequisiteCoursesNonCompleted: false,
        resignationstatus: '',
        searchMids: [],
        tab: tab
      };
      this.updateRequestFilters(filtersObj);
    } else if (
      (tab == 'certification' && this.selectedTab != 'certification') ||
      (tab != 'certification' && this.selectedTab == 'certification')
    ) {
      this.closeSearch();
    }
    this.router.navigate([tab], { relativeTo: this.activatedRoute });
  }
  subscribeToSearchStatus() {
    this.approvalsComponentSubscriptions.getSearchStatusSub = this.cdmService
      .getSearchStatus()
      .subscribe(status => {
        this.searchStatus = status;
        if (status && this.cdmNavbar != undefined) {
          this.cdmNavbar.close();
        } else if (!status && this.cdmNavbar != undefined) {
          this.cdmNavbar.open();
          this.router.navigate(['review'], {
            relativeTo: this.activatedRoute
          });
        }
      });
  }
  updateRequestFilters(filterObj) {
    this.cdmService.updateRequestsFilters(filterObj);
  }
  subscribeToFilters() {
    this.approvalsComponentSubscriptions.getRequestFiltersSub = this.cdmService
      .getRequestsFilters()
      .subscribe(filterObj => {
        this.requestFilters = { ...this.requestFilters, ...filterObj };
        this.requestsIndex = parseInt(filterObj['index']);
        if (this.searchStatus) {
          this.cdmNavbar.close();
          this.router.navigate(
            ['search/' + this.requestFilters.searchMids[0]],
            { relativeTo: this.activatedRoute }
          );
        }
        // let payload = {
        //   acceptedRequests: filterObj['acceptedRequests'],
        //   actionedNo: filterObj['actionedNo'],
        //   actionedYes: filterObj['actionedYes'],
        //   arrangeByCourse: filterObj['arrangeByCourse'],
        //   arrangeByDate: filterObj['arrangeByDate'],
        //   billablestatus: filterObj['billablestatus'],
        //   competency: filterObj['competency'],
        //   courseName: filterObj['courseName'],
        //   deniedRequests: filterObj['deniedRequests'],
        //   isACMorPCMAssigned: filterObj['isACMorPCMAssigned'],
        //   isOther201sInProgress: filterObj['isOther201sInProgress'],
        //   location: filterObj['location'],
        //   onHoldRequests: filterObj['onHoldRequests'],
        //   preRequisiteCoursesCompleted:
        //     filterObj['preRequisiteCoursesCompleted'],
        //   preRequisiteCoursesNonCompleted:
        //     filterObj['preRequisiteCoursesNonCompleted'],
        //   resignationstatus: filterObj['resignationstatus'],
        //   searchMids: filterObj['searchMids']
        // };
        // let isCertificationSelected = false;
        // if (this.selectedTab == 'certification') {
        //   isCertificationSelected = true;
        // }
        // this.cdmService.getSearchResultsFromAPI(
        //   filterObj['limit'],
        //   filterObj['index'],
        //   filterObj['nextOrPrevious'],
        //   payload,
        //   isCertificationSelected,
        //   this.userRole
        // );
      });
  }
  arrangeByCourse() {
    this.cdmService.updateRequestsFilters({
      ...this.requestFilters,
      arrangeByCourse: true,
      arrangeByDate: false,
      courseName: ''
    });
    if (this.coursesList.length == 0) {
      this.getCoursesList();
    }
  }
  onCourseSelection(course) {
    this.cdmService.updateRequestsFilters({
      ...this.requestFilters,
      courseName: course
    });
  }
  getCoursesList() {
    this.cdmService.getPSSFilters().then((filters: any) => {
      this.coursesList = filters.CourseNames.sort();
    });
  }
  arrangeByDate() {
    this.selectedCourse = '';
    this.cdmService.updateRequestsFilters({
      ...this.requestFilters,
      arrangeByDate: true,
      arrangeByCourse: false,
      courseName: ''
    });
  }
  applyFiltersFromMenu() {
    this.cdmService.updateRequestsFilters({
      ...this.requestFilters,
      isACMorPCMAssigned: this.isACMorPCMAssigned,
      preRequisiteCoursesCompleted: this.preRequisiteCoursesCompleted,
      competency: this.competency,
      location: this.location,
      billablestatus: this.billableStatus,
      resignationstatus: this.resignationStatus
    });
  }
  acceptedBtnOnClick() {
    this.requestsLimit = 20;
    this.requestsIndex = 0;
    this.loadNextOrPrevious = 'next';
    this.loadedRequestsLength = 0;
    this.totalRequestsLength = 0;
    if (this.acceptedFilterSelected) {
      this.acceptedFilterSelected = false;
      this.cdmService.updateRequestsFilters({
        ...this.requestFilters,
        acceptedRequests: false,
        limit: 20,
        index: 0,
        nextOrPrevious: 'next'
      });
    } else {
      this.acceptedFilterSelected = true;
      this.deniedFilterSelected = false;
      this.onHoldFilterSelected = false;
      this.cdmService.updateRequestsFilters({
        ...this.requestFilters,
        acceptedRequests: true,
        deniedRequests: false,
        onHoldRequests: false,
        limit: 20,
        index: 0,
        nextOrPrevious: 'next'
      });
    }
  }
  deniedBtnOnClick() {
    this.requestsLimit = 20;
    this.requestsIndex = 0;
    this.loadNextOrPrevious = 'next';
    this.loadedRequestsLength = 0;
    this.totalRequestsLength = 0;
    if (this.deniedFilterSelected) {
      this.deniedFilterSelected = false;
      this.cdmService.updateRequestsFilters({
        ...this.requestFilters,
        deniedRequests: false,
        limit: 20,
        index: 0,
        nextOrPrevious: 'next'
      });
    } else {
      this.acceptedFilterSelected = false;
      this.deniedFilterSelected = true;
      this.onHoldFilterSelected = false;
      this.cdmService.updateRequestsFilters({
        ...this.requestFilters,
        acceptedRequests: false,
        deniedRequests: true,
        onHoldRequests: false,
        limit: 20,
        index: 0,
        nextOrPrevious: 'next'
      });
    }
  }
  onHoldBtnOnClick() {
    this.requestsLimit = 20;
    this.requestsIndex = 0;
    this.loadNextOrPrevious = 'next';
    this.loadedRequestsLength = 0;
    this.totalRequestsLength = 0;
    if (this.onHoldFilterSelected) {
      this.onHoldFilterSelected = false;
      this.cdmService.updateRequestsFilters({
        ...this.requestFilters,
        onHoldRequests: true,
        limit: 20,
        index: 0,
        nextOrPrevious: 'next'
      });
    } else {
      this.acceptedFilterSelected = false;
      this.deniedFilterSelected = false;
      this.onHoldFilterSelected = true;
      this.cdmService.updateRequestsFilters({
        ...this.requestFilters,
        acceptedRequests: false,
        deniedRequests: false,
        onHoldRequests: true,
        limit: 20,
        index: 0,
        nextOrPrevious: 'next'
      });
    }
  }
  onChangeOfRequestsPerPage(data) {
    this.cdmService.updateRequestsFilters({
      ...this.requestFilters,
      limit: data,
      index: 0
    });
  }
  onChangeOfCourseSelected(name) {
    this.cdmService.updateRequestsFilters({
      ...this.requestFilters,
      courseName: name
    });
  }
  onNextRequestsBtnClick() {
    const index = this.requestsIndex + this.requestsLimit;
    this.cdmService.updateRequestsFilters({
      ...this.requestFilters,
      nextOrPrevious: 'next',
      index: index
    });
  }
  onPreviousRequestsBtnClick() {
    const index = this.requestsIndex - this.requestsLimit;
    this.cdmService.updateRequestsFilters({
      ...this.requestFilters,
      nextOrPrevious: 'previous',
      index: index
    });
  }
  getUserSuggestionList(name) {
    if (name.length > 2) {
      this.showSearchIcon = false;
      this.cdmService.searchUser(name).then((result: any) => {
        this.showSuggestionsList = true;
        this.suggestionList = result.value;
        this.suggestionList.forEach(user => {
          user.userImage = null;
          user.MId = user.userPrincipalName.split('@')[0];
          this._graphSvc.getUserImage(user.MId).subscribe(
            data => {
              user.imageUrl = this.createImageURL(data);
            },
            error => {
              user.userImage = null;
            }
          );
        });
      });
    } else if (name.length == 0 && this.searchBy.length != 0) {
      console.log('1');
      this.showSuggestionsList = false;
      this.closeSearch();
    } else {
      console.log('2');
      this.showSuggestionsList = false;
      this.showSearchIcon = true;
    }
  }
  createImageURL(imageBlob) {
    const imageURL = this._window.URL.createObjectURL(imageBlob);
    return this.sanitizer.bypassSecurityTrustUrl(imageURL);
  }
  getRequestsOfSelectedUser(user) {
    this.cdmService.updateSearchStatus(true);
    this.searchBy = user.MId;
    this.showSuggestionsList = false;
    this.resetAllFilters();
    if (this.selectedTab == 'certification') {
      this.cdmService.getCertificationSearchResults(this.searchBy);
    } else {
      let filtersObj = {
        limit: 20,
        index: 0,
        nextOrPrevious: 'next',
        acceptedRequests: false,
        actionedNo: false,
        actionedYes: false,
        arrangeByCourse: false,
        arrangeByDate: false,
        billablestatus: '',
        competency: '',
        courseName: '',
        deniedRequests: false,
        isACMorPCMAssigned: false,
        isOther201sInProgress: false,
        location: '',
        onHoldRequests: false,
        preRequisiteCoursesCompleted: false,
        preRequisiteCoursesNonCompleted: false,
        resignationstatus: '',
        searchMids: [],
        tab: this.selectedTab
      };
      filtersObj.searchMids.push(user.MId);
      this.updateRequestFilters(filtersObj);
    }
  }
  closeSearch() {
    this.showSuggestionsList = false;
    this.showSearchIcon = true;
    this.searchBy = '';
    this.cdmService.updateSearchStatus(false);
    this.resetAllFilters();
    let filtersObj = {
      limit: 20,
      index: 0,
      nextOrPrevious: 'next',
      acceptedRequests: false,
      actionedNo: false,
      actionedYes: false,
      arrangeByCourse: false,
      arrangeByDate: false,
      billablestatus: '',
      competency: '',
      courseName: '',
      deniedRequests: false,
      isACMorPCMAssigned: false,
      isOther201sInProgress: false,
      location: '',
      onHoldRequests: false,
      preRequisiteCoursesCompleted: false,
      preRequisiteCoursesNonCompleted: false,
      resignationstatus: '',
      searchMids: [],
      tab: this.selectedTab
    };
    this.updateRequestFilters(filtersObj);
  }
  resetAllFilters() {
    this.requestsLimit = 20;
    this.requestsIndex = 0;
    this.loadNextOrPrevious = 'next';
    this.loadedRequestsLength = 0;
    this.totalRequestsLength = 0;
    this.isACMorPCMAssigned = false;
    this.preRequisiteCoursesCompleted = false;
    this.competency = '';
    this.location = '';
    this.billableStatus = '';
    this.resignationStatus = '';
    this.acceptedFilterSelected = false;
    this.deniedFilterSelected = false;
    this.onHoldFilterSelected = false;
    if (!this.searchStatus) {
      this.searchBy = '';
    }
    this.arrangeByCourseFlag = false;
  }
  ngOnDestroy() {
    this.unsubscribeAllSubscriptions();
  }
  unsubscribeAllSubscriptions() {
    for (let subscriberKey in this.approvalsComponentSubscriptions) {
      let subscriber = this.approvalsComponentSubscriptions[subscriberKey];
      if (subscriber instanceof Subscriber) {
        subscriber.unsubscribe();
      }
    }
  }
}
