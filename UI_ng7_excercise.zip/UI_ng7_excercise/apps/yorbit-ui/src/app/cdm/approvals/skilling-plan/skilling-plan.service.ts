import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import {
  EnvironmentService,
  Ienvironment
} from '@YorbitWorkspace/global-environments';

@Injectable()
export class SkillingPlanService {
  config: Ienvironment;
  constructor(private http: HttpClient, private _envSvc: EnvironmentService) {
    this.config = this._envSvc.getEnvironment();
  }
  getSkillPlans() {
    return this.http
      .get(this.config.apiUrl + 'SkillPlan/Department')
      .toPromise();
  }
  getSkillPlanDetails(id) {
    return this.http
      .get(this.config.apiUrl + 'skillPlan/ViewDetails/' + id)
      .toPromise();
  }
}
