import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActionedComponent } from './actioned.component';

describe('ActionedComponent', () => {
  let component: ActionedComponent;
  let fixture: ComponentFixture<ActionedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActionedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActionedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
