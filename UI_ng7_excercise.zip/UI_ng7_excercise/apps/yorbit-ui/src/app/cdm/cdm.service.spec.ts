import { TestBed, inject } from '@angular/core/testing';

import { CdmService } from './cdm.service';

describe('CdmService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CdmService]
    });
  });

  it('should be created', inject([CdmService], (service: CdmService) => {
    expect(service).toBeTruthy();
  }));
});
