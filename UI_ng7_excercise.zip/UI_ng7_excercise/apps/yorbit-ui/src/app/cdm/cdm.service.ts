import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import {
  EnvironmentService,
  Ienvironment
} from '@YorbitWorkspace/global-environments';
@Injectable({
  providedIn: 'root'
})
export class CdmService {
  config: Ienvironment;
  filtersObj: any;
  role: BehaviorSubject<string | null>;
  loadedRequestsDetails: BehaviorSubject<any>;
  filtersForRequests: BehaviorSubject<any>;
  filtersForPendingRequests: BehaviorSubject<any>;
  isSearchInProgress: BehaviorSubject<boolean>;
  filtersForReviewRequests: BehaviorSubject<any>;
  filtersForActionedRequests: BehaviorSubject<any>;
  filtersForAssignedRequests: BehaviorSubject<any>;
  filtersForSearch: BehaviorSubject<any>;
  searchResults: BehaviorSubject<any>;
  constructor(private http: HttpClient, private _envSvc: EnvironmentService) {
    this.config = this._envSvc.getEnvironment();
    this.filtersObj = {
      limit: 20,
      index: 0,
      nextOrPrevious: 'next',
      acceptedRequests: false,
      actionedNo: false,
      actionedYes: false,
      arrangeByCourse: false,
      arrangeByDate: false,
      billablestatus: '',
      competency: '',
      courseName: '',
      deniedRequests: false,
      isACMorPCMAssigned: false,
      isOther201sInProgress: false,
      location: '',
      onHoldRequests: false,
      preRequisiteCoursesCompleted: false,
      preRequisiteCoursesNonCompleted: false,
      resignationstatus: '',
      searchMids: []
    };
    this.loadedRequestsDetails = new BehaviorSubject({
      loadedRequestsLength: 0,
      totalRequestsLength: 0
    });
    this.filtersForRequests = new BehaviorSubject({
      ...this.filtersObj
    });
    this.isSearchInProgress = new BehaviorSubject(false);
    this.searchResults = new BehaviorSubject([]);
    this.role = new BehaviorSubject(null);
  }
  getRoleOfUser() {
    return this.role.asObservable();
  }
  updateRoleOfUser(data) {
    this.role.next(data);
  }
  getLoadedRequestsDetails() {
    return this.loadedRequestsDetails.asObservable();
  }
  updateLoadedRequestsDetails(data) {
    this.loadedRequestsDetails.next(data);
  }
  getRequestsFilters() {
    return this.filtersForRequests.asObservable();
  }
  updateRequestsFilters(data) {
    this.filtersForRequests.next({ ...this.filtersObj, ...data });
  }
  getSearchStatus() {
    return this.isSearchInProgress.asObservable();
  }
  updateSearchStatus(data) {
    this.isSearchInProgress.next(data);
  }
  getSearchResults() {
    return this.searchResults.asObservable();
  }
  updateSearchResults(data) {
    this.searchResults.next(data);
  }
  getPendingRequests(limit, index, nextOrPrevious, data, userRole) {
    let URL = '';
    if (userRole === 'cdm') {
      URL =
        'Workflow/Requests/Pending/' +
        limit +
        '/' +
        index +
        '/' +
        nextOrPrevious;
    } else if (userRole === 'rm') {
      URL =
        'Workflow/Requests/RMPending/' +
        limit +
        '/' +
        index +
        '/' +
        nextOrPrevious;
    }
    return this.http.post(this.config.apiUrl + URL, data).toPromise();
  }
  getReviewRequests(limit, index, nextOrPrevious, data, userRole) {
    let URL = '';
    if (userRole === 'cdm') {
      URL =
        'Workflow/Requests/UnderReview/' +
        limit +
        '/' +
        index +
        '/' +
        nextOrPrevious;
    } else if (userRole === 'rm') {
      URL =
        'Workflow/Requests/RMUnderReview/' +
        limit +
        '/' +
        index +
        '/' +
        nextOrPrevious;
    }
    return this.http.post(this.config.apiUrl + URL, data).toPromise();
  }
  getActionedRequests(limit, index, nextOrPrevious, data, userRole) {
    let URL = '';
    if (userRole === 'cdm') {
      URL =
        'Workflow/Requests/Actioned/' +
        limit +
        '/' +
        index +
        '/' +
        nextOrPrevious;
    } else if (userRole === 'rm') {
      URL =
        'Workflow/Requests/RMActioned/' +
        limit +
        '/' +
        index +
        '/' +
        nextOrPrevious;
    }
    return this.http.post(this.config.apiUrl + URL, data).toPromise();
  }
  getAssignedRequests(limit, index, nextOrPrevious, data) {
    return this.http
      .post(
        this.config.apiUrl +
          'Workflow/Requests/Assigned/' +
          limit +
          '/' +
          index +
          '/' +
          nextOrPrevious,
        data
      )
      .toPromise();
  }
  getSearchResultsFromAPI(
    limit,
    index,
    nextOrPrevious,
    data,
    isCertificationSelected,
    userRole
  ) {
    if (isCertificationSelected) {
      this.getCertificationSearchResults(data['searchMids'][0]);
    }
    let URL = '';
    if (userRole == 'cdm') {
      URL = 'Workflow/CDM/Search/' + limit + '/' + index + '/' + nextOrPrevious;
    } else if (userRole == 'rm') {
      URL = 'Workflow/RMSearch/' + limit + '/' + index + '/' + nextOrPrevious;
    }
    this.http
      .post(this.config.apiUrl + URL, data)
      .toPromise()
      .then((requests: any) => {
        if (requests == null) {
          requests.ActionedRequestsList = [];
          requests.RequestCount = 0;
        }
        this.updateLoadedRequestsDetails({
          loadedRequestsLength: requests.ActionedRequestsList.length,
          totalRequestsLength: requests.RequestCount
        });
        this.updateSearchResults(requests.ActionedRequestsList);
      })
      .catch(err => {
        this.updateSearchResults([]);
      });
  }
  getCertificationSearchResults(searchMids) {
    this.http
      .post(
        this.config.apiUrl +
          'Workflow/CDM/CertificateSearch?searchMids=' +
          searchMids,
        {}
      )
      .toPromise()
      .then((requests: any) => {
        this.updateLoadedRequestsDetails({
          loadedRequestsLength: requests.length,
          totalRequestsLength: requests.length
        });
        this.updateSearchResults(requests);
      })
      .catch(err => {
        this.updateSearchResults([]);
      });
  }
  getCertificateApprovalCDMorRM(role, limit, index, nextOrPrevious) {
    let url;
    //console.log(role);
    if (role === 'cdm') {
      url = 'Get/ExternalCertificateDetails/';
    } else {
      url = 'Get/RMExternalCertificateDetails/';
    }
    return this.http
      .post(
        this.config.apiUrl + url + limit + '/' + index + '/' + nextOrPrevious,
        {}
      )
      .toPromise();
  }
  getPSSFilters() {
    return this.http.get(this.config.apiUrl + 'PSS/Filters').toPromise();
  }
  getCompetencyList() {
    return this.http
      .get(this.config.apiUrl + 'Workflow/CapacityReport/CompetencyList')
      .toPromise();
  }
  getLocationList() {
    return this.http
      .get(this.config.apiUrl + 'Workflow/CapacityReport/LocationList')
      .toPromise();
  }
  getBillableStatusList() {
    return this.http
      .get(this.config.apiUrl + 'Workflow/CapacityReport/BillableStatusList')
      .toPromise();
  }
  searchUser(name) {
    return this.http
      .get(
        'https://graph.windows.net/mindtree.com/users?api-version=1.6&$filter=startswith(displayName,' +
          "'" +
          name +
          "') or startswith(userPrincipalName," +
          "'" +
          name +
          "')&$top=5"
      )
      .toPromise();
  }
  approveRequests(payload, isCertificate) {
    return this.http
      .post(
        this.config.apiUrl + 'Course/Approve/items/' + isCertificate,
        payload
      )
      .toPromise();
  }
  denyRequests(payload, isCertificate) {
    return this.http
      .post(
        this.config.apiUrl + 'Course/Reject/items/' + isCertificate,
        payload
      )
      .toPromise();
  }
  holdRequests(payload, isCertificate) {
    return this.http
      .post(
        this.config.apiUrl + 'Workflow/CDM/OnHold/' + isCertificate,
        payload
      )
      .toPromise();
  }
  getCourseStatusInsidePackage(requestId) {
    return this.http
      .post(this.config.apiUrl + 'Workflow/CDM/201Status/' + requestId, {})
      .toPromise();
  }
}
