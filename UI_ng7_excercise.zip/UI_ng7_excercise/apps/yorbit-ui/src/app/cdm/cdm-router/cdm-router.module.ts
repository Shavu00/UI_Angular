import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ApprovalsComponent } from '../approvals/approvals.component';
import { ReviewComponent } from '../approvals/review/review.component';
import { PendingComponent } from '../approvals/pending/pending.component';
import { ActionedComponent } from '../approvals/actioned/actioned.component';
import { AssignedComponent } from '../approvals/assigned/assigned.component';
import { CertificationComponent } from '../approvals/certification/certification.component';
import { SkillingPlanComponent } from '../approvals/skilling-plan/skilling-plan.component';
import { SearchComponent } from '../approvals/search/search.component';
import { SendNotificationsComponent } from '../approvals/send-notifications/send-notifications.component';
const routes: Routes = [
  {
    path: '',
    component: ApprovalsComponent,
    children: [
      {
        path: '',
        redirectTo: 'review',
        pathMatch: 'full'
      },
      {
        path: 'review',
        component: ReviewComponent,
        data: {
          title: 'Review Requests'
        }
      },
      {
        path: 'pending',
        component: PendingComponent,
        data: {
          title: 'Pending Requests'
        }
      },
      {
        path: 'actioned',
        component: ActionedComponent,
        data: {
          title: 'Actioned Request'
        }
      },
      {
        path: 'assigned',
        component: AssignedComponent,
        data: {
          title: 'Assigned Requests'
        }
      },
      {
        path: 'certification',
        component: CertificationComponent,
        data: {
          title: 'Certification Requests'
        }
      },
      {
        path: 'sendnotifications',
        component: SendNotificationsComponent,
        data: {
          title: 'Send Notifications'
        }
      },
      {
        path: 'search/:mid',
        component: SearchComponent,
        data: {
          title: 'Search'
        }
      }
    ]
  }
];
@NgModule({
  imports: [CommonModule, RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CdmRouterModule {}
