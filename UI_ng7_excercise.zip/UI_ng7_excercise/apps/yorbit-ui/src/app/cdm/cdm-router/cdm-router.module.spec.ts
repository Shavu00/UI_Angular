import { CdmRouterModule } from './cdm-router.module';

describe('CdmRouterModule', () => {
  let cdmRouterModule: CdmRouterModule;

  beforeEach(() => {
    cdmRouterModule = new CdmRouterModule();
  });

  it('should create an instance', () => {
    expect(cdmRouterModule).toBeTruthy();
  });
});
