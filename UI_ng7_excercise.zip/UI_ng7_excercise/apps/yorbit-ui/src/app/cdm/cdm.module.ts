import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ReusableUiModule } from '@YorbitWorkspace/reusable-ui';

import { CdmRouterModule } from './cdm-router/cdm-router.module';
import { ApprovalsComponent } from './approvals/approvals.component';
import { ReviewComponent } from './approvals/review/review.component';
import { PendingComponent } from './approvals/pending/pending.component';
import { ActionedComponent } from './approvals/actioned/actioned.component';
import { AssignedComponent } from './approvals/assigned/assigned.component';
import { CertificationComponent } from './approvals/certification/certification.component';
import { SkillingPlanComponent } from './approvals/skilling-plan/skilling-plan.component';
import { SendNotificationsComponent } from './approvals/send-notifications/send-notifications.component';
import { MatDividerModule, MatIconModule, MatButtonModule, MatSidenavModule, MatMenuModule } from '@angular/material';
import { SearchComponent } from './approvals/search/search.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,

    MatDividerModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatMenuModule,


    CdmRouterModule,
    FlexLayoutModule,
    ReusableUiModule
  ],
  declarations: [
    ApprovalsComponent,
    ReviewComponent,
    PendingComponent,
    ActionedComponent,
    AssignedComponent,
    CertificationComponent,
   SkillingPlanComponent,
    SendNotificationsComponent,
    SearchComponent
  ]
})
export class CdmModule {}
