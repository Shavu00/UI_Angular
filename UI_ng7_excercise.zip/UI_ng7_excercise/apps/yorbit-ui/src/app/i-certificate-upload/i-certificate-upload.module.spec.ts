import { ICertificateUploadModule } from './i-certificate-upload.module';

describe('ICertificateUploadModule', () => {
  let iCertificateUploadModule: ICertificateUploadModule;

  beforeEach(() => {
    iCertificateUploadModule = new ICertificateUploadModule();
  });

  it('should create an instance', () => {
    expect(iCertificateUploadModule).toBeTruthy();
  });
});
