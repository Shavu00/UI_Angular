import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ICertificateUploadComponent } from './i-certificate-upload.component';

const routes: Routes = [{ path: '', component: ICertificateUploadComponent }];

@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes)]
})
export class ICertificateUploadRoutingModule {}
