import { Component, OnInit, ViewChild } from '@angular/core';
import {
  MatDialog,
  MatDialogConfig,
  MatDialogRef,
  MatInput
} from '@angular/material';
import { MediaChange, MediaObserver } from '@angular/flex-layout';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { ICertificatePopupComponent } from './i-certificate-popup/i-certificate-popup.component';
import { ICertificateUploadService } from './i-certificate-upload.service';

interface Course {
  CourseName: string;
  CourseId: string;
  Expertise: string;
  Coursetype: string;
  Academy: string;
  vendorName: string;
  RequestId: Number;
}
@Component({
  selector: 'yorbit-i-certificate-upload',
  templateUrl: './i-certificate-upload.component.html',
  styleUrls: ['./i-certificate-upload.component.scss']
})
export class ICertificateUploadComponent implements OnInit {
  @ViewChild('certificateDate', { read: MatInput })
  certificateDate: MatInput;
  @ViewChild('expiryDate', { read: MatInput })
  expiryDate: MatInput;
  panelOpenState: boolean;
  listOfCourse: Array<Course>;
  selectedCourse: Course;
  selectedCertificationDate: any;
  selectedExpiryDate: any;
  courseLoaded: boolean;
  noExpDateCheckBox: boolean;
  iCertifcateUploadFile: any;
  uploadBtnTitle: string;
  mUploadBtnTitle: string;
  courseNotSelected: boolean;
  certificateDateNotSelected: boolean;
  expiryNotSelected: boolean;
  fileNotSelected: boolean;
  disableUploadButton: boolean;
  btnTitle: string;
  disableExpiryDate: boolean;
  uploadBtnClicked: boolean;
  minCertDate: Date;
  minExpDate: Date;
  showMobileView: boolean;
  showDesktopView: boolean;
  constructor(
    private icertificateService: ICertificateUploadService,
    private _popup: MatDialog,
    private mediaObserver: MediaObserver
  ) {
    this.showMobileView = false;
    this.showDesktopView = false;
    this.subscribeMediaChanges();
    //initialize variable
    this.resetAllVariable();
  }

  ngOnInit() {
    this.courseLoaded = false;
    //get upload course list
    this.getPendingCourseList();
  }
  subscribeMediaChanges() {
    this.mediaObserver.media$.subscribe((media: MediaChange) => {
      if (media.mqAlias === 'xs') {
        this.showMobileView = true;
        this.showDesktopView = false;
      } else if (media.mqAlias !== 'xs') {
        this.showDesktopView = true;
        this.showMobileView = false;
      }
    });
  }
  resetAllVariable() {
    this.listOfCourse = [];
    this.iCertifcateUploadFile = '';
    this.uploadBtnTitle = 'Upload';
    this.mUploadBtnTitle = 'Upload Certificate';
    this.disableUploadButton = true;
    this.btnTitle = 'Please Enter All Mandatory Fields';
    this.disableExpiryDate = false;
    this.courseNotSelected = true;
    this.certificateDateNotSelected = true;
    this.expiryNotSelected = true;
    this.fileNotSelected = true;
    this.uploadBtnClicked = false;
    this.minCertDate = new Date();
    this.minExpDate = new Date();
  }
  resetInputFile() {
    const ele = document.getElementById('fileUploadLabel');
    ele.innerHTML = "<span>Browse</span><div title=''>Select a file</div>";
    this.certificateDate.value = '';
    this.expiryDate.value = '';
  }
  getPendingCourseList() {
    this.icertificateService.getUploadCourseList().subscribe(list => {
      this.listOfCourse = list;
      // const data = {
      //   CourseName: 'Node JS',
      //   CourseId: 'DI_72',
      //   Coursetype: 'VILT',
      //   Expertise: '201',
      //   Academy: 'Digital',
      //   vendorName: 'Coursera'
      // };
      // this.listOfCourse.push(data);
      const obj = {
        CourseName: 'Select the course',
        CourseId: '',
        Coursetype: '',
        Expertise: '',
        Academy: '',
        vendorName: '',
        RequestId: 0
      };
      this.listOfCourse.unshift(obj);
      this.selectedCourse = this.listOfCourse[0];
      this.courseLoaded = true;
    });
  }
  certificateDateSelected(event: MatDatepickerInputEvent<Date>) {
    this.selectedCertificationDate = event.value;
    this.btnTitle = 'Please Enter All Mandatory Fields';
    this.validateAllCondition();
  }
  expiryDateSelected(event: MatDatepickerInputEvent<Date>) {
    this.selectedExpiryDate = event.value;
    this.btnTitle = 'Please Enter All Mandatory Fields';
    this.validateAllCondition();
  }
  disableExpDateOrCheckBoxFunction() {
    if (this.noExpDateCheckBox) {
      this.expiryNotSelected = false;
      this.disableExpiryDate = true;
      this.selectedExpiryDate = '';
    } else {
      this.expiryNotSelected = true;
      this.disableExpiryDate = false;
    }
    this.validateAllCondition();
  }
  setDefaultValuesForUploads() {}
  fileModel(event) {
    this.iCertifcateUploadFile = event.file;
    this.btnTitle = 'Please Enter All Mandatory Fields';
    this.validateAllCondition();
  }
  uploadFile() {
    this.uploadBtnClicked = true;
    if (this.noExpDateCheckBox === undefined) {
      this.noExpDateCheckBox = false;
    }
    this.validateAllCondition();
  }
  validateAllCondition() {
    if (
      this.iCertifcateUploadFile === undefined ||
      this.iCertifcateUploadFile === ''
    ) {
      this.fileNotSelected = true;
      this.btnTitle = 'Please select the file';
    } else {
      const uploadedFileSize = this.iCertifcateUploadFile.size / (1024 * 1024);
      if (
        this.iCertifcateUploadFile.type === 'application/pdf' ||
        this.iCertifcateUploadFile.type === 'image/jpeg' ||
        this.iCertifcateUploadFile.type === 'application/x-zip-compressed'
      ) {
        if (uploadedFileSize < 10) {
          this.fileNotSelected = false;
          this.btnTitle = 'Click to Upload Certificate';
        } else {
          this.fileNotSelected = true;
          this.btnTitle = 'Please choose file less than 10MB !';
        }
      } else {
        this.fileNotSelected = true;
        this.btnTitle = 'Please choose only pdf/jpg/jpeg/zip file !';
      }
    }
    if (this.selectedCourse.CourseName === 'Select the course') {
      this.courseNotSelected = true;
      this.btnTitle = 'Please select the course name';
    } else {
      this.courseNotSelected = false;
    }
    if (
      this.selectedCertificationDate === undefined ||
      this.selectedCertificationDate === '' ||
      this.selectedCertificationDate === null
    ) {
      this.certificateDateNotSelected = true;
      this.btnTitle = 'Please select the certification date';
    } else {
      this.certificateDateNotSelected = false;
    }
    if (
      (this.selectedExpiryDate === undefined ||
        this.selectedExpiryDate === '' ||
        this.selectedExpiryDate === null) &&
      !this.noExpDateCheckBox
    ) {
      this.expiryNotSelected = true;
      this.btnTitle = 'Please select the expiry date';
    } else {
      this.expiryNotSelected = false;
    }
    if (
      this.courseNotSelected ||
      this.certificateDateNotSelected ||
      this.expiryNotSelected ||
      this.fileNotSelected
    ) {
      this.disableUploadButton = true;
    } else {
      this.btnTitle = 'Click to Upload Certificate';
      this.disableUploadButton = false;
      if (this.uploadBtnClicked) {
        this.uploadBtnTitle = 'Uploading...';
        this.mUploadBtnTitle = 'Uploading...';
        this.apiCallForBlob();
        this.disableUploadButton = true;
      }
    }
  }
  apiCallForBlob() {
    this.icertificateService
      .uploadToBlob(this.iCertifcateUploadFile, this.selectedCourse.CourseId)
      .then((response: any) => {
        this.apiCallForSql(response.Msg);
      })
      .catch((error: any) => {
        this.resetInputFile();
        this.openpopup('Failure', 'file is not uploaded to blob');
        //reset all variable
        this.resetAllVariable();
        this.selectedCertificationDate = '';
        this.selectedExpiryDate = '';
        this.noExpDateCheckBox = false;
        this.iCertifcateUploadFile = '';
        //get updated course list
        this.getPendingCourseList();
      });
  }
  apiCallForSql(fileUrl) {
    const certStartDate =
      this.selectedCertificationDate.getFullYear() +
      '-' +
      (this.selectedCertificationDate.getMonth() + 1) +
      '-' +
      this.selectedCertificationDate.getDate();
    let certExptDate;
    if (this.selectedExpiryDate !== '') {
      certExptDate =
        this.selectedExpiryDate.getFullYear() +
        '-' +
        (this.selectedExpiryDate.getMonth() + 1) +
        '-' +
        this.selectedExpiryDate.getDate();
    } else {
      certExptDate = this.selectedExpiryDate;
    }
    const obj = {
      RequestId: this.selectedCourse.RequestId,
      CourseId: this.selectedCourse.CourseId,
      VendorName: this.selectedCourse.vendorName,
      filepath: fileUrl,
      CertificationCompletionDate: certStartDate,
      ExpiryDt: certExptDate,
      IsChecknoexpiry: this.noExpDateCheckBox
    };
    const successMessage =
      'Certificate has been uploaded successfully for ' +
      this.selectedCourse.RequestId +
      ' - ' +
      this.selectedCourse.CourseName;
    const errorMessage = 'Some thing went wrong';
    this.icertificateService.uploadToSql(obj).subscribe(
      res => {
        this.uploadBtnTitle = 'Uploaded';
        this.mUploadBtnTitle = 'Uploaded';
        this.resetInputFile();
        this.openpopup('Success', successMessage);
        //reset all variable
        this.resetAllVariable();
        this.selectedCertificationDate = '';
        this.selectedExpiryDate = '';
        this.noExpDateCheckBox = false;
        this.iCertifcateUploadFile = '';
        //get updated course list
        this.getPendingCourseList();
      },
      error => {
        this.uploadBtnTitle = 'Failed';
        this.mUploadBtnTitle = 'Failed';
        this.resetInputFile();
        this.openpopup('Failure', errorMessage);
        //reset all variable
        this.resetAllVariable();
        this.selectedCertificationDate = '';
        this.selectedExpiryDate = '';
        this.noExpDateCheckBox = false;
        this.iCertifcateUploadFile = '';
        //get updated course list
        this.getPendingCourseList();
      }
    );
  }
  openpopup(status, data) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.panelClass = 'popupDialogContainer';
    dialogConfig.data = {
      status: status,
      data: data
    };
    const response = this._popup.open(ICertificatePopupComponent, dialogConfig);
    response.afterClosed().subscribe(res => {
      //do something after pop up close
    });
  }
  back() {
    window.history.back();
  }
}
