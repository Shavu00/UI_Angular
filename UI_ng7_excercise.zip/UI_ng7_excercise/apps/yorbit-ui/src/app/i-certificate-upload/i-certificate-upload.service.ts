import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap } from 'rxjs/operators';
import {
  EnvironmentService,
  Ienvironment
} from '@YorbitWorkspace/global-environments';

@Injectable({
  providedIn: 'root'
})
export class ICertificateUploadService {
  config: Ienvironment;
  constructor(private http: HttpClient, private _envSvc: EnvironmentService) {
    this.config = this._envSvc.getEnvironment();
  }
  getUploadCourseList(): Observable<any> {
    return this.http.get(this.config.apiUrl + 'PSS/PSSInternalCourses').pipe(
      map((res: Response) => res),
      catchError((e: Response) => throwError(e))
    );
  }
  uploadToBlob(file, courseId):any{
    const fd = new FormData();
    fd.append("file", file,file.name);
    //const httpHeaders = new HttpHeaders().append('Content-Type', 'undefined');
    return this.http.post(this.config.apiUrl + 'AzureBlob/Upload/InternalCertificate/' + courseId, fd).toPromise()
  }
  uploadToSql(certData):Observable<any> {
    return this.http.post(this.config.apiUrl + 'PSSUploadSql/InternalCertificate', certData).pipe(
      tap((res: Response) => res),
      catchError((e: Response) => throwError(e))
    );
  }
}
