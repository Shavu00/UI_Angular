import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ICertificatePopupComponent } from "./i-certificate-popup/i-certificate-popup.component";
import { ICertificateUploadComponent } from './i-certificate-upload.component';
import { ICertificateUploadRoutingModule } from './i-certificate-upload.routing.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { DirectivesModule} from '@YorbitWorkspace/directives';
import { ReusableUiModule } from '@YorbitWorkspace/reusable-ui';
import { MatDialogModule, MatButtonModule, MatInputModule, MatIconModule, MatDatepickerModule, MatNativeDateModule, MatExpansionModule } from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    ICertificateUploadRoutingModule,

    MatDialogModule,
    MatButtonModule,
    MatInputModule,
    MatIconModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatExpansionModule,


    FlexLayoutModule,
    FormsModule,
    DirectivesModule,
    ReusableUiModule
  ],
  entryComponents: [ICertificatePopupComponent],
  declarations: [ICertificateUploadComponent, ICertificatePopupComponent]
})
export class ICertificateUploadModule {}
