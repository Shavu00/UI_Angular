import { TestBed, inject } from '@angular/core/testing';

import { ICertificateUploadService } from './i-certificate-upload.service';

describe('ICertificateUploadService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ICertificateUploadService]
    });
  });

  it('should be created', inject(
    [ICertificateUploadService],
    (service: ICertificateUploadService) => {
      expect(service).toBeTruthy();
    }
  ));
});
