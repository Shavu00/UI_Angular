import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ICertificateUploadComponent } from './i-certificate-upload.component';

describe('ICertificateUploadComponent', () => {
  let component: ICertificateUploadComponent;
  let fixture: ComponentFixture<ICertificateUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ICertificateUploadComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ICertificateUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
