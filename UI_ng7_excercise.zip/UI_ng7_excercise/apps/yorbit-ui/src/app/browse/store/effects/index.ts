import { BrowseEffects } from './browse.effect';

export const effectsBrowse: any[] = [BrowseEffects];

export * from './browse.effect';
