import { BrowseStoreModule } from './browse-store.module';

describe('BrowseStoreModule', () => {
  let browseStoreModule: BrowseStoreModule;

  beforeEach(() => {
    browseStoreModule = new BrowseStoreModule();
  });

  it('should create an instance', () => {
    expect(browseStoreModule).toBeTruthy();
  });
});
