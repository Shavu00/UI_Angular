import { IBrowseContent } from "./browse-content.interface";

export interface IBrowseAcademy {
  AcademyTerms?: IAcademyTerm[];
}

export interface IAcademyTerm {
  Name:        string;
  UniqueId:    number;
  CreatedDate: string;
  New:         boolean;
  GenreTerms?: IAcademyTerm[];
  SkillTerms?: IAcademyTerm[];
  Contents?:IBrowseContent;
}

