import { Injectable } from "@angular/core";
import { Actions, Effect, ofType } from "@ngrx/effects";
import { BrowseService } from "../../browse.service";
import * as browseActions from '../actions/browse.action';
import { switchMap, map, catchError, concat, concatMap } from "rxjs/operators";
import { of } from "rxjs";

@Injectable()
export class BrowseEffects{
  userDetailsService: any;
  constructor(
    private actions$: Actions,
    private browseService:BrowseService
  ){}

  @Effect()
  getAcademyList$ = this.actions$
    .ofType(browseActions.BROWSE_GET_ACADEMY_LIST)
    .pipe(
      switchMap(() => {
        return this.browseService.getAcademyList().pipe(
          map(
            academyList =>
              new browseActions.BrowseGetAcademyListSuccess(academyList)
          ),
          catchError(error =>
            of(new browseActions.BrowseGetAcademyListFail(error))
          )
        );
      })
    );

    @Effect()
    getAcademyContent$ = this.actions$.ofType(browseActions.BROWSE_GET_ACADEMY_CONTENT)
      .pipe(
        switchMap((action:browseActions.BrowseGetAcademyContent) => {
          return this.browseService.getAcademyContent(action.payload).pipe(
            map(
              academyContent =>{
                const Response ={
                  Content:academyContent,
                  AcademyData:action.payload
                }
                return new browseActions.BrowseGetAcademyContentSuccess(Response)
              }
            ),
            catchError(error =>
              of(new browseActions.BrowseGetAcademyContentFail(error))
            )
          );
        })
      );

}
