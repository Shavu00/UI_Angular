export interface IBrowseContent {
  packages:      IPackage[];
  pageIndex:     string;
  totalPackages: number;
}

export interface IPackage {
  Id:                       number;
  UniqueId:                 string;
  PackageId:                string;
  PackageIds:               any[];
  Name:                     string;
  Description:              string;
  TopicsCovered:            string;
  Expertise:                string;
  Duration:                 string;
  TotalUsers:               number;
  TotalShares:              number;
  TotalExperts:             number;
  TotalLikes:               number;
  IconUrl:                  string;
  ItemType:                 string;
  ContentCount:             number;
  IntroVideo:               string;
  IntroVideoType:           string;
  Experts:                  IExpert[] | null;
  Badges:                   IBadges;
  BadgeIds:                 number[];
  Liked:                    boolean;
  RolePackageId:            number;
  TechnologyPackageId:      number;
  Internal:                 boolean;
  WorkflowStatus:           null|string;
  Vendor:                   string;
  WebLink:                  string;
  Price:                    string;
  ELearning:                string;
  ELearningDescription:     string;
  ProjectWork:              string;
  ProjectWorkDescription:   string;
  OnlineQuiz:               string;
  OnlineQuizDescription:    string;
  Academy:                  string;
  Genre:                    string;
  Skill:                    string;
  CreatedDate:              string;
  ManagerApproval:          boolean;
  Type:                     string;
  Classroom:                string;
  ClassroomDescription:     string;
  Assignment:               string;
  AssignmentDescription:    string;
  Assessment:               string;
  AssessmentDescription:    string;
  PreRequisiteMandatory:    string;
  PreRequisiteCourses:      null|any[];
  PostRecommendedCourses:   null|any[];
  Declaration:              boolean;
  DeclarationID:            number;
  CourseUniqueId:           string;
  Category:                 null|string;
  Account:                  null|string;
  Project:                  null|string;
  AccountPackage:           boolean;
  ProjectPackage:           boolean;
  YorbitCourseUniqueIds:    null|string;
  IsPreRequisiteMandatory:  boolean;
  PreRequisiteCourseIDs:    any[];
  PostRecommendedCourseIDs: any[];
  ListofCourses:            null|string[];
  CourseCustomOrder:        null|string[];
  StackAndSkillsList:       any[];
  PrePreperatoryCourses:    any[];
  PrePreperatoryPackages:   any[];
  ProgramHighlightImage:    string;
  IsPreAssessmentRequired:  boolean;
  IsHidden:                 boolean;
  AcademyUniqueId:          string;
  GenreUniqueId:            string;
  SkillUniqueId:            string;
  HasCustomerAccess:        boolean;
  ModifiedDate:             string;
  Credits:                  number;
}

export interface IBadges {
  BadgesList: any[];
}

export interface IExpert {
  expertName:   null|string;
  expertMailId: null|string;
  expertPhoto:  null|string;
  expertId:     string;
}

