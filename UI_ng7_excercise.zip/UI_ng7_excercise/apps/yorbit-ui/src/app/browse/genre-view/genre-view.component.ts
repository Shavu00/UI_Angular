import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  ElementRef
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import * as fromBrowseStore from '../store';
import { BrowseService } from '../browse.service';
import { Subscriber } from 'rxjs';
import { ArrayPropertyFilterPipe,ItemTypePipe } from '@YorbitWorkspace/pipes';
import { MediaChange, MediaObserver } from '@angular/flex-layout';
import {
  SkillPipe,
  CourseTypePipe,
  ExpertisePipe,
  FilterContentTileByItsPropertiesPipe,
  VendorPipe
} from '@YorbitWorkspace/pipes';
import * as fromRoleAccessStore from '@YorbitWorkspace/role-access';

@Component({
  selector: 'yorbit-genre-view',
  templateUrl: './genre-view.component.html',
  styleUrls: ['./genre-view.component.scss']
})
export class GenreViewComponent implements OnInit, OnDestroy {
  //filters
  filterBrowseContent: any;
  //filter models
  searchContentTilesModel: any;
  selectedExpertiseToFilter: any;
  selectedCourseTypeToFilter: any;
  selectedSkillsToFilter: Array<String>;
  genreViewCompSubscriptions: any;
  routeParams: any;
  academyList: any;
  selectedAcademy: any;
  selectedGenre: any;
  showCourses: boolean;
  showSkills: boolean;
  packageList: Array<any>;
  filteredPackagesList: Array<any>;
  courseTypes: Array<string>;
  vendors: Array<string>;
  filterByProperty = new ArrayPropertyFilterPipe();
  mediaBreakPoint: string;
  showExpertiseFiltersMenu: boolean;
  filterContentTiles: any;
  accountsList: any;
  accountsLoaded: boolean;
  isAccountBrowse: boolean;
  roleList: fromRoleAccessStore.IroleData;
  showPagePreloader: boolean;
  pageLoadedSuccessfully: boolean;
  showCoursesPreloader: boolean;
  coursesLoadedSuccessfully: boolean;
  showSearchIcon: boolean;
  vendorFilter: VendorPipe;
  selectedVendorToFilter: any[];
  courseTypeFilter: CourseTypePipe;
  expertiseFilter: ExpertisePipe;
  skillFilter: SkillPipe;
  filterByItsProperties: FilterContentTileByItsPropertiesPipe;
  filterModel: { Skill: String[]; Expertise: any; Type: any; SearchBy: any; };
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private browseStore: Store<fromBrowseStore.IbrowseAcademyReducerState>,
    private browseService: BrowseService,
    private mediaObserver: MediaObserver,
    private userRoleAccessStore: Store<fromRoleAccessStore.IRoleReducerState>
  ) {
    //filters
    this.showPagePreloader = true;
    this.pageLoadedSuccessfully = false;
    this.showCoursesPreloader = false;
    this.coursesLoadedSuccessfully = false;
    this.courseTypeFilter = new CourseTypePipe();
    this.vendorFilter = new VendorPipe();
    this.expertiseFilter = new ExpertisePipe();
    this.skillFilter = new SkillPipe();
    this.filterByItsProperties = new FilterContentTileByItsPropertiesPipe();
    //filter models
    this.searchContentTilesModel = '';
    this.selectedExpertiseToFilter = ['101', '201', '301'];
    this.selectedCourseTypeToFilter = [];
    this.selectedVendorToFilter = [];
    this.selectedSkillsToFilter = [];

    this.genreViewCompSubscriptions = {};
    this.courseTypes = [];
    this.vendors=[];
    this.showCourses = false;
    this.showSkills = true;
    this.selectedAcademy = {};
    this.selectedGenre = {};
    this.selectedAcademy.GenreTerms = [];
    this.mediaBreakPoint = '';
    this.showExpertiseFiltersMenu = false;
    this.subscribeToShowSkillsStatusFlag();
    this.subscribeToGetSelectedSkillsInGenre();
    this.browseService.updateShowSkillsFlagStatus(true);
    this.browseService.updateShowCoursesFlagStatus(false);
    this.accountsList = [];
    this.packageList = [];
    this.filteredPackagesList = [];
    this.accountsLoaded = false;
    this.isAccountBrowse = false;
    this.showSearchIcon = true;
    this.filterModel = {
      Skill: this.selectedSkillsToFilter,
      Expertise: this.selectedExpertiseToFilter,
      Type: this.selectedCourseTypeToFilter,
      SearchBy: this.searchContentTilesModel
    };
  }
  validateRoute() {
    if (this.router.url.indexOf('accountsAndProjects') == -1) {
      this.subscribeToBrowseStore();
      this.subscribeMediaChanges();
    } else {
      this.isAccountBrowse = true;
      this.loadAccounts();
    }
  }
  loadAccounts() {
    this.browseService.getAccountsList().subscribe(accountList => {
      if (!this.accountsLoaded && accountList.length != 0) {
        this.academyList = accountList;
        if (this.academyList.length == 0) {
          this.showPagePreloader = false;
          this.pageLoadedSuccessfully = false;
          this.showCoursesPreloader = false;
          this.coursesLoadedSuccessfully = false;
        } else {
          this.showPagePreloader = false;
          this.pageLoadedSuccessfully = true;
          this.showCoursesPreloader = false;
          this.coursesLoadedSuccessfully = false;
          this.subscribeToRouterParams();
        }
        this.accountsLoaded = true;
      }
    });
  }
  subscribeToShowSkillsStatusFlag() {
    this.browseService.showCoursesInGenreView$.subscribe(flag => {
      this.showCourses = flag;
    });
  }
  subscribeToGetSelectedSkillsInGenre() {
    this.browseService.getSelectedSkill().subscribe((skills: any) => {
      if (skills.length != 0) {
        this.selectedSkillsToFilter = skills;
        if (this.selectedGenre.UniqueId != undefined) {
          this.selectedGenre.SkillTerms.forEach(skill => {
            if (this.selectedSkillsToFilter.indexOf(skill.Name) == -1) {
              skill.isSelected = false;
            } else {
              skill.isSelected = true;
            }
          });
        }
      }
    });
  }
  subscribeToRouterParams() {
    this.genreViewCompSubscriptions.routerParamsSub = this.activatedRoute.params.subscribe(
      params => {
        this.routeParams = params;
        let academyId: any = '';
        let genreId: any = '';
        if (this.router.url.indexOf('accountsAndProjects') != -1) {
          academyId = params['accountId'];
          if (params['projectId'] != null && params['projectId'] != 'null') {
            genreId = params['projectId'];
          } else {
            genreId = params['accountId'];
          }
        } else {
          academyId = parseInt(params['academyId']);
          genreId = parseInt(params['genreId']);
        }

        if (
          (academyId != undefined || academyId != null) &&
          (genreId != null || genreId != undefined)
        ) {
          //filter genre with academyId and genreId
          this.selectedAcademy = this.filterByProperty.transform(
            this.academyList,
            {
              property: 'UniqueId',
              flag: academyId
            }
          )[0];
          this.selectedGenre = this.filterByProperty.transform(
            this.selectedAcademy.GenreTerms,
            {
              property: 'UniqueId',
              flag: genreId
            }
          )[0];
          this.selectedGenre.showSkills = true;
          this.selectedGenre.SkillTerms.forEach(skill => {
            if (this.selectedSkillsToFilter.indexOf(skill.Name) == -1) {
              skill.isSelected = false;
            } else {
              skill.isSelected = true;
            }
          });
          let genreDetails = {
            GenreName: this.selectedGenre.Name,
            GenreId: this.selectedGenre.UniqueId
          };
          this.browseService.updateSelectedGenre(genreDetails);
          this.getCoursesFromGenre();
        }
      }
    );
  }
  subscribeToBrowseStore() {
    this.genreViewCompSubscriptions.browseStoreSub = this.browseStore
      .select(fromBrowseStore.getBrowseAcadmeyList)
      .subscribe(academyList => {
        //if loaded
        if (academyList.AcademyTerms) {
          this.academyList = academyList.AcademyTerms;
          if (this.academyList.length == 0) {
            this.showPagePreloader = false;
            this.pageLoadedSuccessfully = false;
            this.showCoursesPreloader = false;
            this.coursesLoadedSuccessfully = false;
          } else {
            this.showPagePreloader = false;
            this.pageLoadedSuccessfully = true;
            this.showCoursesPreloader = false;
            this.coursesLoadedSuccessfully = false;
            this.subscribeToRouterParams();
          }
        }
      });
  }
  getCoursesFromGenre() {
    this.showPagePreloader = false;
    this.pageLoadedSuccessfully = true;
    this.showCoursesPreloader = true;
    this.coursesLoadedSuccessfully = false;
    if (this.router.url.indexOf('accountsAndProjects') == -1) {
      this.loadYorbitCourses();
    } else {
      this.loadAccountCourses();
    }
  }
  loadAccountCourses() {
    if (this.selectedGenre.IsAccount) {
      let payload = { ItemId: this.selectedGenre.AccountId };
      this.browseService.getAccountContent(payload).then((response: any) => {
        this.packageList = response.packages;
        this.showPagePreloader = false;
        this.pageLoadedSuccessfully = true;
        this.showCoursesPreloader = false;
        this.coursesLoadedSuccessfully = true;
        this.packageList.forEach(content => {
          this.getFilterObj(content);
        });
      });
    } else if (this.selectedGenre.IsProject) {
      let payload = { ItemId: this.selectedGenre.ProjectId };
      this.browseService.getProjectContent(payload).then((response: any) => {
        this.packageList = response.packages;
        this.showPagePreloader = false;
        this.pageLoadedSuccessfully = true;
        this.showCoursesPreloader = false;
        this.coursesLoadedSuccessfully = true;
        this.packageList.forEach(content => {
          this.getFilterObj(content);
        });
      });
    }
  }
  loadYorbitCourses() {
    let payload = {
      Academy: this.selectedAcademy.Name,
      Genre: this.selectedGenre.Name
    };
    this.browseStore.dispatch(
      new fromBrowseStore.BrowseGetAcademyContent(payload)
    );
    this.browseStore
      .select(fromBrowseStore.getBrowseAcadmeyContentLoaded)
      .subscribe(response => {
        if (response) {
          if (this.selectedGenre && this.selectedGenre.Contents) {
            this.packageList = this.selectedGenre.Contents.packages;
            this.showPagePreloader = false;
            this.pageLoadedSuccessfully = true;
            this.showCoursesPreloader = false;
            this.coursesLoadedSuccessfully = true;
            this.packageList.forEach(content => {
              this.getFilterObj(content);
            });
          }
        }
      });
  }
  onGenreSelection(genre) {
    this.resetAllFilters();
    if (
      genre.UniqueId == this.selectedGenre.UniqueId &&
      this.mediaBreakPoint != 'xs'
    ) {
      genre.showSkills = !genre.showSkills;
    } else if (this.mediaBreakPoint == 'xs') {
      this.showCoursesInGenreView();
    } else {
      //change genreId in url
      this.selectedSkillsToFilter = [];
      this.packageList = [];
      if (this.router.url.indexOf('accountsAndProjects') == -1) {
        this.router.navigate(
          [
            'academy/' +
              this.selectedAcademy.UniqueId +
              '/genre/' +
              genre.UniqueId
          ],
          {
            relativeTo: this.activatedRoute.parent
          }
        );
      } else {
        this.router.navigate([
          'accountsAndProjects/' +
            this.selectedAcademy.UniqueId +
            '/' +
            genre.UniqueId
        ]);
      }
    }
  }
  subscribeMediaChanges() {
    this.genreViewCompSubscriptions.mediaChangeSubscription = this.mediaObserver.media$.subscribe(
      (media: MediaChange) => {
        this.mediaBreakPoint = media.mqAlias;
      }
    );
  }
  showCoursesInGenreView() {
    this.showCourses = true;
    this.browseService.updateShowSkillsFlagStatus(false);
    this.browseService.updateShowCoursesFlagStatus(true);
  }
  resetAllFilters() {
    //filter models
    this.searchContentTilesModel = '';
    this.selectedExpertiseToFilter = ['101', '201', '301'];
    this.selectedCourseTypeToFilter = [];
    this.selectedVendorToFilter = [];
  }
  filterBySkills(skill) {
    skill.isSelected = !skill.isSelected;
    if (skill.isSelected) {
      this.selectedSkillsToFilter.push(skill.Name);
    } else {
      this.selectedSkillsToFilter.splice(
        this.selectedSkillsToFilter.indexOf(skill.Name),
        1
      );
    }
    this.resetAllFilters();
    this.onFiltersChange();
  }
  filterByExpertise(expertise, checked) {
    if (expertise.toLowerCase() == 'all') {
      if (checked) {
        this.selectedExpertiseToFilter = ['101', '201', '301'];
      } else {
        //this.selectedExpertiseToFilter = [];
      }
    } else {
      if (checked) {
        this.selectedExpertiseToFilter.push(expertise);
      } else {
        this.selectedExpertiseToFilter.splice(
          this.selectedExpertiseToFilter.indexOf(expertise),
          1
        );
      }
    }
    this.onFiltersChange();
  }
  filterByCourseType(type, checked) {
    if (type.toLowerCase() == 'all') {
      if (checked) {
        this.selectedCourseTypeToFilter = this.courseTypes;
      } else {
        this.selectedCourseTypeToFilter = [];
      }
    } else {
      if (checked) {
        this.selectedCourseTypeToFilter.push(type);
      } else {
        this.selectedCourseTypeToFilter.splice(
          this.selectedCourseTypeToFilter.indexOf(type),
          1
        );
      }
      this.onFiltersChange();
    }
  }
  onFiltersChange() {
    this.filteredPackagesList = this.filterBrowseContent.transform(
      this.packageList,
      this.filterModel
    );
  }
  onSearchInputChange() {
    if (this.searchContentTilesModel.length != 0) {
      this.showSearchIcon = false;
    } else {
      this.showSearchIcon = true;
    }
    this.onFiltersChange();
  }
  filterByVendor(type, checked) {
    if (type.toLowerCase() == 'all') {
      if (checked) {
        this.selectedVendorToFilter = this.vendors;
      } else {
        this.selectedVendorToFilter = [];
      }
    } else {
      if (checked) {
        this.selectedVendorToFilter.push(type);
      } else {
        this.selectedVendorToFilter.splice(
          this.selectedVendorToFilter.indexOf(type),
          1
        );
      }
    }
  }
  ngOnInit() {
    this.validateRoute();
    this.userRoleAccessStore
      .select(fromRoleAccessStore.getRoleAccessList)
      .subscribe(roleList => {
        this.roleList = roleList;
      });
  }
  ngOnDestroy() {
    this.unsubscribeAllSubscriptions();
    this.browseService.updateSelectedGenre(null);
  }
  unsubscribeAllSubscriptions() {
    for (let subscriberKey in this.genreViewCompSubscriptions) {
      let subscriber = this.genreViewCompSubscriptions[subscriberKey];
      if (subscriber instanceof Subscriber) {
        subscriber.unsubscribe();
      }
    }
  }
  goToAcademyView() {
    if (this.router.url.indexOf('accountsAndProjects') == -1) {
      this.router.navigate(['academy/' + this.selectedAcademy.UniqueId], {
        relativeTo: this.activatedRoute.parent
      });
    } else {
      this.router.navigate(['browse/accountsAndProjects']);
    }
    this.browseService.updateShowSkillsFlagStatus(false);
    this.browseService.updateShowCoursesFlagStatus(false);
  }
  getFilterObj(content){
    if (
      this.courseTypes.indexOf(content.Type) === -1 &&
      content.Type != '' &&
      content.Type != null
    ) {
      this.courseTypes.push(content.Type);
    }
    if (
      this.vendors.indexOf(content.Vendor) === -1 &&
      content.Vendor != '' &&
      content.Vendor != null
    ) {
      this.vendors.push(content.Vendor);
    }
  }
}
