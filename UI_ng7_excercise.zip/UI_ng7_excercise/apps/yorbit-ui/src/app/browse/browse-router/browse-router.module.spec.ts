import { BrowseRouterModule } from './browse-router.module';

describe('BrowseRouterModule', () => {
  let browseRouterModule: BrowseRouterModule;

  beforeEach(() => {
    browseRouterModule = new BrowseRouterModule();
  });

  it('should create an instance', () => {
    expect(browseRouterModule).toBeTruthy();
  });
});
