import { Component, OnInit } from '@angular/core';
import { AoService } from './ao.service';
import { CourseRequestService } from '../course-request/course-request.service';

@Component({
  selector: 'yorbit-ao',
  templateUrl: './ao.component.html',
  styleUrls: ['./ao.component.scss']
})
export class AoComponent implements OnInit {
  menuSelection: Array<boolean>;
  showPending: boolean;
  pendingRequests: Array<any>;
  actionedRequests: Array<any>;
  taxonomyList: any;
  reassignAcademyList: any;
  isRequestsLoading: boolean;
  loadingRequestsError: boolean;

  isTaxonomyLoading: boolean;
  taxonomyLoadingError: boolean;
  newRequestStatus: Array<any>;
  reassignAcademy: Array<any>;
  reassignStatus: Array<any>;

  // Course request
  actionedTabsIndex = {
    ACCEPTED: 0,
    DENIED: 1,
    ONHOLD: 2,
    COMPLETED: 3
  };
  showAccepted: boolean;
  showDenied: boolean;
  showOnHold: boolean;
  showCompleted: boolean;
  nestedTabs: {
    Accepted: boolean;
    Denied: boolean;
    OnHold: boolean;
    Completed: boolean;
  };

  constructor(
    private _AOSvc: AoService,
    private _courseReqSvc: CourseRequestService
  ) {}
  ngOnInit() {
    this.menuSelection = new Array(3);
    this.menuSelection.fill(false);
    this.menuSelection[0] = true;
    this.showPending = true;
    this.pendingRequests = [];
    this.actionedRequests = [];
    this.reassignAcademyList = [];
    this.newRequestStatus = [];
    this.reassignAcademy = [];
    this.reassignStatus = [];
    this.nestedTabs = {
      Accepted: this.showAccepted,
      Denied: this.showDenied,
      OnHold: this.showOnHold,
      Completed: this.showCompleted
    };
    this.getPendingNewCourseRequests();
    this.getTaxonomy();
  }

  selectionHandler(tabId) {
    for (let i = 0; i < this.menuSelection.length; i++) {
      this.menuSelection[i] = false;
    }
    switch (tabId) {
      case 0:
        this.menuSelection[0] = true;
        break;
      case 1:
        this.menuSelection[1] = true;
        break;
      case 2:
        this.menuSelection[2] = true;
        break;
    }
  }

  getPendingNewCourseRequests() {
    this.showAccepted = false;
    this.showDenied = false;
    this.showOnHold = false;
    this.showCompleted = false;

    this.pendingRequests = [];
    this.isRequestsLoading = true;
    this.loadingRequestsError = false;
    const coursePayload = {
      arrangeByCourse: false,
      arrangeByDate: false,
      acceptedRequests: false,
      deniedRequests: false,
      onHoldRequests: false,
      CompletedRequests: false
    };

    this._AOSvc.getCoursePendingRequest(coursePayload).subscribe(
      data => {
        this.isRequestsLoading = false;
        this.loadingRequestsError = false;
        if (
          typeof data === 'string' &&
          data.toLowerCase() === 'no records to show'
        ) {
          this.pendingRequests = [];
        } else if (data.length > 0) {
          this.pendingRequests = data;
        } else {
          this.pendingRequests = [];
        }
      },
      error => {
        this.isRequestsLoading = false;
        this.loadingRequestsError = true;
      }
    );
  }

  getTaxonomy() {
    this.isTaxonomyLoading = true;
    this.taxonomyLoadingError = false;
    this._courseReqSvc.getTaxonomy().subscribe(
      data => {
        this.isTaxonomyLoading = false;
        this.taxonomyLoadingError = false;
        if (data.AcademyList.length > 0) {
          this.taxonomyList = data.AcademyList;
          this.taxonomyList.forEach((value, key) => {
            this.reassignAcademyList.push(value.Academy);
          });
        }
      },
      error => {
        this.isTaxonomyLoading = false;
        this.taxonomyLoadingError = true;
      }
    );
  }

  //newCoursePending()
  newCourseActioned() {
    this.showPending = false;
    this.actionTabsHandler(this.actionedTabsIndex.ACCEPTED);
  }

  actionTabsHandler(tabIndex) {
    this.showAccepted = false;
    this.showDenied = false;
    this.showOnHold = false;
    this.showCompleted = false;

    let coursePayload = {
      arrangeByCourse: false,
      arrangeByDate: false,
      acceptedRequests: false,
      deniedRequests: false,
      onHoldRequests: false,
      CompletedRequests: false
    };

    switch (tabIndex) {
      case this.actionedTabsIndex.ACCEPTED:
        this.showAccepted = true;
        coursePayload.acceptedRequests = true;
        // this.completeReqInProgress.fill(false);
        // this.isReqComplete.fill(false);
        // this.completeReqErr.fill(false);
        //   vmAO.setTaxonomy();
        break;
      case this.actionedTabsIndex.DENIED:
        this.showDenied = true;
        coursePayload.deniedRequests = true;
        break;
      case this.actionedTabsIndex.ONHOLD:
        this.showOnHold = true;
        coursePayload.onHoldRequests = true;
        break;
      case this.actionedTabsIndex.COMPLETED:
        this.showCompleted = true;
        coursePayload.CompletedRequests = true;
        break;
    }
    this.getActionedRequests(coursePayload);
  }

  getActionedRequests(coursePayload) {
    this.actionedRequests = [];
    this.loadingRequestsError = false;
    this.isRequestsLoading = true;

    this._AOSvc.getCourseActionedRequest(coursePayload).subscribe(
      data => {
        this.isRequestsLoading = false;
        if (typeof data === 'string') {
          this.actionedRequests = [];
        } else if (data.length > 0) {
          this.actionedRequests = data;
          // angular.forEach(this.actionedRequest, function (value, key) {
          //     pssService.getUserName(vmAO.actionedRequest[key].CreatedBy).then(function (response) {
          //         vmAO.actionedRequest[key].requestedByName = response.data.value;
          //     });
          //     vmAO.getUserProfilePic(vmAO.actionedRequest[key].CreatedBy);
          //   })
          // vmAO.setTaxonomy();
        }
      },
      error => {
        this.isRequestsLoading = false;
        this.loadingRequestsError = true;
      }
    );
  }
}
