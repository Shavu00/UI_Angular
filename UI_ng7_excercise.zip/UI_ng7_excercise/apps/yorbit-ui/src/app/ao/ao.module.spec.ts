import { AoModule } from './ao.module';

describe('AoModule', () => {
  let aoModule: AoModule;

  beforeEach(() => {
    aoModule = new AoModule();
  });

  it('should create an instance', () => {
    expect(aoModule).toBeTruthy();
  });
});
