import { TestBed, inject } from '@angular/core/testing';

import { AoService } from './ao.service';

describe('AoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AoService]
    });
  });

  it('should be created', inject([AoService], (service: AoService) => {
    expect(service).toBeTruthy();
  }));
});
