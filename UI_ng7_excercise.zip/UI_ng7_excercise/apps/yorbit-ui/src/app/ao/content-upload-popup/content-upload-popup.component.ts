import { Component, OnInit,Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'yorbit-content-upload-popup',
  templateUrl: './content-upload-popup.component.html',
  styleUrls: ['./content-upload-popup.component.scss']
})
export class ContentUploadPopupComponent implements OnInit {
params :any;
msg:any;
  constructor( public dialogRef: MatDialogRef<ContentUploadPopupComponent>,
    @Inject(MAT_DIALOG_DATA) data
  ) {
    this.params = data;
    this.msg = "This works !"
  }


  ngOnInit() {
  }

  close(){
    this.dialogRef.close();
  }

}
