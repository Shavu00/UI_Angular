import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContentUploadPopupComponent } from './content-upload-popup.component';

describe('ContentUploadPopupComponent', () => {
  let component: ContentUploadPopupComponent;
  let fixture: ComponentFixture<ContentUploadPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContentUploadPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContentUploadPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
