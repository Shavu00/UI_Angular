import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { EnvironmentService } from '@YorbitWorkspace/global-environments';
import { catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { PARAMETERS } from '@angular/core/src/util/decorators';

@Injectable({
  providedIn: 'root'
})
export class ContentUploadService {

  _baseURL: string;
  constructor(private _http: HttpClient, private _envSvc: EnvironmentService) {
    this._baseURL = this._envSvc.getEnvironment().apiUrl;
  }

  getTaxonomy() {
    return this._http
      .get<any>(this._baseURL + 'Course/GetTaxonomy')
      .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  getVendor() {
    return this._http
      .get<any>(this._baseURL + 'GetVendorList')
      .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  getCourseTypeList(expertise) {
    return this._http
      .get<any>(this._baseURL + 'GetCourseType', expertise)
      .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  getCourseModeOfPayment() {
    return this._http
      .get<any>(this._baseURL + 'GetCourseModeOfPayment')
      .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  getCourseClassification(){
    return this._http
    .get<any>(this._baseURL + 'GetCourseClassification')
    .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  getCourseInfrastructure(){
    return this._http
    .get<any>(this._baseURL + 'GetCourseInfrastructure')
    .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  getCourseInfrastructureType(){
    return this._http
    .get<any>(this._baseURL + 'GetCourseInfrastructureType')
    .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  getCourseLogin(){
    return this._http
    .get<any>(this._baseURL + 'GetCourseLogin')
    .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  getCourseLoginType(){
    return this._http
    .get<any>(this._baseURL + 'GetCourseLoginType')
    .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  getCourseSessionType(){
    return this._http
    .get<any>(this._baseURL + 'GetCourseSessionType')
    .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  getCourseCompletion(){
    return this._http
    .get<any>(this._baseURL + 'GetCourseCompletion')
    .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  getCourseCompletionType(){
    return this._http
    .get<any>(this._baseURL + 'GetCourseCompletionType')
    .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  getCourseEligibility(){
    return this._http
    .get<any>(this._baseURL + 'GetCourseEligibility')
    .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  getCourseAccessibility(){
    return this._http
    .get<any>(this._baseURL + 'GetCourseAccessibility')
    .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  insertContentFormFor201(formData,header) {
    return this._http.post<any>(
      this._baseURL + 'ContentInsertFor201',
      formData,header
    );
  }
   uploadToBlob(file, prefixString):any{
    const fd = new FormData();
    fd.append("file", file);
    //const httpHeaders = new HttpHeaders().append('Content-Type', 'undefined');
    return this._http.post(this._baseURL + 'AzureBlob/Upload/contentUpload201Files/' + prefixString, fd).toPromise()
  }
}
