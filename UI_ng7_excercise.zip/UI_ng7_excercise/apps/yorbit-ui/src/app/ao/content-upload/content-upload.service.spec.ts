import { TestBed, inject } from '@angular/core/testing';

import { ContentUploadService } from './content-upload.service';

describe('ContentUploadService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ContentUploadService]
    });
  });

  it('should be created', inject([ContentUploadService], (service: ContentUploadService) => {
    expect(service).toBeTruthy();
  }));
});
