import { Component, OnInit, ViewChild } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import {
  FormGroup,
  FormControl,
  FormArray,
  FormBuilder,
  Validators
} from '@angular/forms';
import { ContentUploadService } from 'apps/yorbit-ui/src/app/ao/content-upload/content-upload.service';
import { $ } from 'protractor';
import { flattenStyles } from '@angular/platform-browser/src/dom/dom_renderer';
import { HttpHeaders } from '@angular/common/http';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { ContentUploadPopupComponent } from '../content-upload-popup/content-upload-popup.component';


@Component({
  selector: 'yorbit-content-upload',
  templateUrl: './content-upload.component.html',
  styleUrls: ['./content-upload.component.scss']
})
export class ContentUploadComponent implements OnInit {
  contentForm: FormGroup;
  taxonomy: any[];
  academyList: any[];
  genreList: any[];
  skillList: any[];
  genreSkillList: any[];
  vendorList: any[];
  courseTypeList: any[];
  courseModeOfPaymentList: any[];
  courseClassificationList: any[];
  courseInfrastructureList: any[];
  courseInfrastructureTypeList: any[];
  courseLoginList: any[];
  courseLoginTypeList: any[];
  courseSessionTypeList: any[];
  courseCompletionList: any[];
  courseCompletionTypeList: any[];
  courseEligibilityList: any[];
  courseAccessibilityList: any[];
  basicCourseTabClicked = true;
  operationalCourseTabClicked: boolean;
  CourseCompletionCertificate = 1;
  badgeRadio = 2;
  learningRadio = 2;
  classRoomRadio = 2;
  classRoomSelect = 1;
  assignmentRadio = 2;
  evaluationRadio = 2;
  classroomScheduledRadio = 2;
  projectWorkRadio = 2;
  evaluationProjectRadio = 2;
  assessmentRadio = 2;
  yesNoRadio = ['Yes', 'No'];
  internalExternalRadio = ['Internal', 'External'];
  OnsiteOffsiteRadio = ['Onsite', 'Offsite'];
  words2 = [{ value: '' }, { value: '' }];
  fileNotSelected: boolean;
  eUploadFile: any;
  constructor(
    private _contentUploadSvc: ContentUploadService,
    private fb: FormBuilder,
    private _popup: MatDialog,
  ) {}

  ngOnInit() {
    this.contentForm = new FormGroup({
      academy: new FormControl(null, [Validators.required]),
      genre: new FormControl(null, [Validators.required]),
      skill: new FormControl(null, [Validators.required]),
      name: new FormControl(null, [Validators.required]),
      topicCovered: new FormControl(null),
      description: new FormControl(null, [Validators.required]),
      type: new FormControl('Select the Course Type'),
      internal: new FormControl('No'),
      vendor: new FormControl(null),
      paid: new FormControl('No'),
      price: new FormControl(null),
      curreny: new FormControl(null),
      paymentMode: new FormControl(null),
      duration: new FormControl(null),
      managerApproval: new FormControl('No'),
      preRequisiteCourseIDs: new FormControl(null),
      postRecommendedCourseIDs: new FormControl(null),
      isPreRequisiteMandatory: new FormControl(null),
      eligibility: new FormControl(null),
      accessibility: new FormControl(null),
      credits: new FormControl(null),
      classification: new FormControl(null),
      badge: new FormControl(null),
      expertMids: new FormControl(null),
      contentOwner: new FormControl(null),
      isIntroductoryVideo: new FormControl('No'),
      creditSpecial: new FormControl('No'),
      sourceType: new FormControl(null),
      introductoryVideo: new FormControl(null),
      isInfrastructure: new FormControl(false),
      infrastructure: new FormArray([]),
      infrastructureType: new FormArray([]),
      isLoginRequired: new FormControl(false),
      loginType: new FormArray([]),
      coursesNameForSelfRegistration: new FormArray([]),
      linktoCoursesForSelfRegistration: new FormArray([]),
      loginDetails: new FormControl(null),
      coursesNameForLearningOPMTeam: new FormArray([]),
      linktoCoursesForLearningOPMTeam: new FormArray([]),
      isLearningMaterial: new FormControl('No'),
      preSessionGroup: new FormGroup({
        preSessionLearningMaterial: new FormControl(1),
        preSessionLearningMaterialTextBox: new FormControl(null),
        preSessionLearningMaterialFileBox: new FormControl(null)
      }),
      duringSessionGroup: new FormGroup({
        duringSessionLearningMaterial: new FormControl(1),
        duringSessionLearningMaterialTextBox: new FormControl(null),
        duringSessionLearningMaterialFileBox: new FormControl(null)
      }),
      postSessionGroup: new FormGroup({
        postSessionLearningMaterial: new FormControl(1),
        postSessionLearningMaterialTextBox: new FormControl(null),
        postSessionLearningMaterialFileBox: new FormControl(null)
      }),
      courseCompletionGroup: new FormGroup({
        courseCompletionFormArray: new FormArray([]),
        courseCompletionTypeFormArray: new FormArray([])
      }),
      classRoomGroup: new FormGroup({
        isClassRoomRequired: new FormControl('No'),
        classroomExecution: new FormControl(1),
        classRoom: new FormArray([])
      }),
      projectGroup: new FormGroup({
        hasProjectWork: new FormControl('No'),
        hasJumbleProject: new FormControl('No'),
        projectWorkDetails: new FormArray([]),
        hasProjectEvaluation: new FormControl('No'),
        projectEvaluationDetails: new FormArray([])
      }),
      assessmentGroup: new FormGroup({
        assessmentRadio: new FormControl('No'),
        assessmentDescription: new FormControl(null),
        assesmentInfrastructure: new FormArray([]),
        assesmentinfrastructureType: new FormArray([])
      })
    });

    // Default values
    this.contentForm.controls['academy'].setValue('Select an Academy');
    this.contentForm.controls['genre'].setValue('Select a Genre');
    this.contentForm.controls['skill'].setValue('Select a Skill');
    this.contentForm.controls['paymentMode'].setValue('Select Payment Mode');
    this.contentForm.controls['type'].setValue('Select the Course Type');

    //caling all the methods to bind drop downs
    this.getTaxonomy();
    this.getVendor();
    this.getCourseTypeList('201');
    this.getCourseModeOfPayment();
    this.getCourseClassification();
    this.getCourseInfrastructure();
    this.getCourseInfrastructureType();
    this.getCourseLogin();
    this.getCourseLoginType();
    this.getCourseSessionType();
    this.getCourseCompletion();
    this.getCourseCompletionType();
    this.getCourseEligibility();
    this.getCourseAccessibility();
    this.addClassRoom();
    this.addProjectWork();
    this.addProjectEvaluation();
  }

  fileModel(event) {
    this.fileNotSelected = false;
    this.eUploadFile = event.file;
    this.validateAllCondition('All', 0);
  }

  //build infrastructure check box
  buildInfrastructure() {
    const control = <FormArray>this.contentForm.controls['infrastructure'];
    this.courseInfrastructureList.forEach(infrastructure => {
      control.push(new FormControl(false));
    });
    return control;
  }

  //build infrastructure textboxes
  buildInfrastructureType() {
    const control = <FormArray>this.contentForm.controls['infrastructureType'];
    this.courseInfrastructureTypeList.forEach(infrastructureType => {
      control.push(new FormControl(null));
    });
  }
  buildAssesmentInfrastructure() {
    const control = <FormArray>(
      this.contentForm.get('assessmentGroup.assesmentInfrastructure')
    );
    this.courseInfrastructureList.forEach(infrastructure => {
      control.push(new FormControl(false));
    });
    return control;
  }

  //build infrastructure textboxes
  buildAssesmentInfrastructureType() {
    const control = <FormArray>(
      this.contentForm.get('assessmentGroup.assesmentinfrastructureType')
    );
    this.courseInfrastructureTypeList.forEach(infrastructureType => {
      control.push(new FormControl(infrastructureType));
    });
  }
  //build login type checkboxes
  buildLoginType() {
    const control = <FormArray>this.contentForm.controls['loginType'];
    this.courseLoginList.forEach(loginType => {
      control.push(new FormControl(false));
    });
    return control;
  }

  //build login description texboxes
  buildLearnertoSelfRegistrationForLink() {
    const control = <FormArray>(
      this.contentForm.controls['linktoCoursesForSelfRegistration']
    );
    control.push(new FormControl(null));
  }

  buildLearnertoSelfRegistrationForName() {
    const control = <FormArray>(
      this.contentForm.controls['coursesNameForSelfRegistration']
    );
    control.push(new FormControl(null));
  }

  buildLearnertoOPMRegistrationForLink() {
    const control = <FormArray>(
      this.contentForm.controls['linktoCoursesForLearningOPMTeam']
    );
    control.push(new FormControl(null));
  }

  buildLearnertoOPMRegistrationForName() {
    const control = <FormArray>(
      this.contentForm.controls['coursesNameForLearningOPMTeam']
    );
    control.push(new FormControl(null));
  }

  buildCourseCompletion() {
    const control = <FormArray>(
      this.contentForm.get('courseCompletionGroup.courseCompletionFormArray')
    );
    this.courseCompletionList.forEach(item => {
      control.push(new FormControl(false));
    });
  }
  buildCourseCompletionType() {
    const control = <FormArray>(
      this.contentForm.get(
        'courseCompletionGroup.courseCompletionTypeFormArray'
      )
    );
    this.courseCompletionTypeList.forEach(item => {
      control.push(new FormControl(null));
    });
  }

  addSelfRegistrationLink(): void {
    this.buildLearnertoSelfRegistrationForLink();
  }
  deleteSelfRegistrationLink(index: number) {
    const control = <FormArray>(
      this.contentForm.controls['linktoCoursesForSelfRegistration']
    );
    control.removeAt(index);
  }
  addSelfRegistrationName(): void {
    this.buildLearnertoSelfRegistrationForName();
  }
  deleteSelfRegistrationName(index: number) {
    const control = <FormArray>(
      this.contentForm.controls['coursesNameForSelfRegistration']
    );
    control.removeAt(index);
  }
  addLearnerOPMLink(): void {
    this.buildLearnertoOPMRegistrationForLink();
  }
  deleteLearnerOPMLink(index: number) {
    const control = <FormArray>(
      this.contentForm.controls['linktoCoursesForLearningOPMTeam']
    );
    control.removeAt(index);
  }
  addLearnerOPMName(): void {
    this.buildLearnertoOPMRegistrationForName();
  }
  deleteLearnerOPMName(index: number) {
    const control = <FormArray>(
      this.contentForm.controls['coursesNameForLearningOPMTeam']
    );
    control.removeAt(index);
  }
  addClassRoom() {
    const control = <FormArray>this.contentForm.get('classRoomGroup.classRoom');
    control.push(this.buildClassRoom());
  }
  deleteClassRoom(index: number) {
    const control = <FormArray>this.contentForm.get('classRoomGroup.classRoom');
    control.removeAt(index);
  }
  public buildClassRoom() {
    return this.fb.group({
      noOfClassRoomSessions: new FormControl(
        { value: '', disabled: true },
        Validators.required
      ),
      nameOfClassRoomSessions: new FormControl(null),
      classroomDescription: new FormControl(null),
      vendorOrFaultyName: new FormControl(null),
      isAssignmentRequired: ['No', [Validators.required]],
      assignmentDescription: new FormControl(null),
      assignmentContent: new FormControl(null),
      isEvaluationRequired: new FormControl('No'),
      evaluatorName: new FormControl(null),
      evaluatorEmailID: new FormControl(null),
      evaluatorVendor: new FormControl(null),
      evaluatorType: new FormControl(null),
      locationofEvaluator: new FormControl(null),
      evaluationTemplate: new FormControl(null),
      isClassroomScheduled: new FormControl('No'),
      classroomScheduledDateTime: new FormControl(null)
    });
  }

  addProjectWork() {
    const control = <FormArray>(
      this.contentForm.get('projectGroup.projectWorkDetails')
    );
    control.push(this.buildProjectWork());
  }

  deleteProjectWork(index: number) {
    const control = <FormArray>(
      this.contentForm.get('projectGroup.projectWorkDetails')
    );
    control.removeAt(index);
  }
  public buildProjectWork() {
    return this.fb.group({
      projectDescription: new FormControl(null),
      problemStatement: new FormControl(null),
      projectDemo: new FormControl('No'),
      projectMaterial: new FormControl(null),
      maxScore: new FormControl(null),
      passingScore: new FormControl(null),
      evaluationTemplate: new FormControl(null)
    });
  }

  addProjectEvaluation() {
    const control = <FormArray>(
      this.contentForm.get('projectGroup.projectEvaluationDetails')
    );
    control.push(this.buildProjectEvaluation());
  }

  deleteProjectEvaluation(index: number) {
    const control = <FormArray>(
      this.contentForm.get('projectGroup.projectEvaluationDetails')
    );
    control.removeAt(index);
  }

  public buildProjectEvaluation() {
    return this.fb.group({
      evaluatorName: new FormControl(null),
      evaluatorEmailID: new FormControl(null),
      evaluatorVendor: new FormControl(null),
      evaluatorType: new FormControl(null),
      locationofEvaluator: new FormControl(null),
    });
  }

  basicCourseClick() {
    this.basicCourseTabClicked = true;
    this.operationalCourseTabClicked = false;
  }

  operationalCourseClick() {
    this.basicCourseTabClicked = false;
    this.operationalCourseTabClicked = true;
  }

  uploadFile(prefix: string, index: number) {
    // this.uploadBtnClicked = true;
    // if (this.noExpDateCheckBox === undefined) {
    //   this.noExpDateCheckBox = false;
    // }
    this.validateAllCondition(prefix, index);
  }
  validateAllCondition(prefix: string, index: number) {
    const uploadedFileSize = this.eUploadFile.size / (1024 * 1024);
    if (
      this.eUploadFile.type === 'application/pdf' ||
      this.eUploadFile.type === 'image/jpeg' ||
      this.eUploadFile.type === 'application/x-zip-compressed'
    ) {
      if (uploadedFileSize < 10) {
        this.fileNotSelected = false;
        //this.btnTitle = 'Click here to upload the certificate.';
      } else {
        this.fileNotSelected = true;
        // this.btnTitle = 'Please choose file less than 10MB !';
      }
    } else {
      this.fileNotSelected = true;
      //this.btnTitle = 'Please choose only pdf/jpg/jpeg/zip file !';
    }
    if (prefix !== 'All') {
      this.apiCallForBlob(prefix, index);
    }
  }
  apiCallForBlob(prefix: string, index: number) {
    this._contentUploadSvc
      .uploadToBlob(this.eUploadFile, prefix)
      .then((response: any) => {
        if (prefix === 'PreSession')
          this.contentForm.controls[
            'preSessionLearningMaterialFileBox'
          ].setValue(response.Msg);
        else if (prefix === 'DuringSession')
          this.contentForm.controls[
            'duringSessionLearningMaterialFileBox'
          ].setValue(response.Msg);
        else if (prefix === 'PostSession')
          this.contentForm.controls[
            'postSessionLearningMaterialFileBox'
          ].setValue(response.Msg);
        else if (
          prefix === 'Sample Certificate' ||
          prefix === 'Sample Badges' ||
          prefix === 'Sample Screenshot' ||
          prefix === 'Sample Letter Head'
        ) {
          const controls = <FormArray>(
            this.contentForm.controls[
              'courseCompletionGroup courseCompletionFormArray'
            ]
          );
          let counter = 0;
          for (let controlItem of controls.controls) {
            if (counter === index) {
              controlItem.setValue(response.Msg);
            }
            counter++;
          }
        } else if (
          prefix === 'ClassAssignmentContent' ||
          prefix === 'ClassAssignmentEvaluationTemplate'
        ) {
          const classRoomcontrols = <FormArray>(
            this.contentForm.get('classRoomGroup.classRoom')
          );
          prefix === 'ClassAssignmentContent'
            ? classRoomcontrols.controls[index]
                .get('assignmentContent')
                .setValue(response.Msg)
            : classRoomcontrols.controls[index]
                .get('evaluationTemplate')
                .setValue(response.Msg);
        } else if (
          prefix === 'ProjectMaterial' ||
          prefix === 'ProblemStatement'||
          prefix === 'EvaluationTemplate'
        ) {
          const projectControls = <FormArray>(
            this.contentForm.get('projectGroup.projectWorkDetails')
          );
          if(prefix === 'ProjectMaterial')
          projectControls.controls[index]
              .get('projectMaterial')
              .setValue(response.Msg)
          else if(prefix === 'ProblemStatement')
          projectControls.controls[index]
              .get('problemStatement')
              .setValue(response.Msg);
          else if(prefix === 'EvaluationTemplate')
          projectControls.controls[index]
              .get('evaluationTemplate')
              .setValue(response.Msg);
        }
      })
      .catch((error: any) => {
        // if (
        //   error.error.Msg ===
        //   "Currently this course is in Pending/Approved Status so you can't upload"
        // ) {
        //   this.courseScheduled = true;
        // } else if (error.error.Msg === 'This course already exist in your LP') {
        //   this.courseExist = true;
        // } else {
        //   this.openpopup('failure', 'some thing went wrong !');
        //   this.uploadBtnClicked = false;
        //   this.disableUploadButton = true;
        // }
      });
  }


  setRadioValue() {
    this.contentForm.get('internal').value === 'No'
      ? this.contentForm.controls['internal'].setValue(false)
      : this.contentForm.controls['internal'].setValue(true);
    this.contentForm.get('paid').value === 'No'
      ? this.contentForm.controls['paid'].setValue(false)
      : this.contentForm.controls['paid'].setValue(true);
    this.contentForm.get('managerApproval').value === 'No'
      ? this.contentForm.controls['managerApproval'].setValue(false)
      : this.contentForm.controls['managerApproval'].setValue(true);
    this.contentForm.get('isPreRequisiteMandatory').value === 'No'
      ? this.contentForm.controls['isPreRequisiteMandatory'].setValue(false)
      : this.contentForm.controls['isPreRequisiteMandatory'].setValue(true);
    this.contentForm.get('isIntroductoryVideo').value === 'No'
      ? this.contentForm.controls['isIntroductoryVideo'].setValue(false)
      : this.contentForm.controls['isIntroductoryVideo'].setValue(true);
    this.contentForm.get('creditSpecial').value === 'No'
      ? this.contentForm.controls['creditSpecial'].setValue(false)
      : this.contentForm.controls['creditSpecial'].setValue(true);
    this.contentForm.get('isLearningMaterial').value === 'No'
      ? this.contentForm.controls['isLearningMaterial'].setValue(false)
      : this.contentForm.controls['isLearningMaterial'].setValue(true);
    this.contentForm.get('classRoomGroup.isClassRoomRequired').value === 'No'
      ? this.contentForm
          .get('classRoomGroup.isClassRoomRequired')
          .setValue(false)
      : this.contentForm
          .get('classRoomGroup.isClassRoomRequired')
          .setValue(true);
    this.contentForm.get('projectGroup.hasProjectWork').value === 'No'
      ? this.contentForm.get('projectGroup.hasProjectWork').setValue(false)
      : this.contentForm.get('projectGroup.hasProjectWork').setValue(true);
    this.contentForm.get('projectGroup.hasJumbleProject').value === 'No'
      ? this.contentForm.get('projectGroup.hasJumbleProject').setValue(false)
      : this.contentForm.get('projectGroup.hasJumbleProject').setValue(true);
    this.contentForm.get('projectGroup.hasProjectEvaluation').value === 'No'
      ? this.contentForm
          .get('projectGroup.hasProjectEvaluation')
          .setValue(false)
      : this.contentForm
          .get('projectGroup.hasProjectEvaluation')
          .setValue(true);
  }

  onInfrastructureChange(event, index, item) {
    const controls = <FormArray>this.contentForm.controls['infrastructure'];
    let counter = 0;
    for (let controlItem of controls.controls) {
      if (counter !== index) {
        controlItem.setValue(false);
      }
      if (controlItem.value === true) {
        this.contentForm.controls['isInfrastructure'].setValue(item.checked);
      }
      counter++;
    }
  }
  onLoginChange(event, index, item) {
    const controls = <FormArray>this.contentForm.controls['loginType'];
    let counter = 0;
    for (let controlItem of controls.controls) {
      if (counter !== index) {
        controlItem.setValue(false);
      }
      if (controlItem.value === true) {
        this.contentForm.controls['isLoginRequired'].setValue(item.checked);
      }
      counter++;
    }
  }

  openpopup(status, data) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.panelClass = 'popupDialogContainer';
    dialogConfig.data = {
      status: status,
      data: data
    };
    const response = this._popup.open(
      ContentUploadPopupComponent,
      dialogConfig
    );
    response.afterClosed().subscribe(res => {
      //do something after pop up close
    });
  }

  getTaxonomy() {
    this.academyList = [];
    this._contentUploadSvc.getTaxonomy().subscribe(
      (response: any) => {
        if (response.AcademyList.length > 0) {
          this.taxonomy = response.AcademyList;
          this.taxonomy.forEach(value => {
            this.academyList.push(value.Academy);
          });
        } else {
          this.taxonomy = [];
        }
      },
      (error: any) => {
        this.taxonomy = [];
      }
    );
  }

  filterGenre() {
    this.genreList = [];
    this.genreSkillList = [];
    this.taxonomy.forEach(value => {
      if (this.contentForm.get('academy').value !== '') {
        if (
          value.Academy.toLowerCase() ===
          this.contentForm.get('academy').value.toLowerCase()
        ) {
          this.genreSkillList = value.GenreSkillList;
        }
      }
    });
    if (this.genreSkillList.length > 0) {
      this.genreSkillList.forEach(value => {
        this.genreList.push(value.Genre);
      });
      return this.genreList;
    } else {
      return [];
    }
  }

  filterSkill() {
    this.skillList = [];
    if (this.genreSkillList.length > 0) {
      this.genreSkillList.forEach(value => {
        if (this.contentForm.get('genre').value !== '') {
          if (
            value.Genre.toLowerCase() ===
            this.contentForm.get('genre').value.toLowerCase()
          ) {
            this.skillList = value.Skills;
          }
        }
      });
      if (this.skillList.length > 0) {
        return this.skillList;
      } else {
        // this.noResultsForSkill = true;
        return [];
      }
    } else {
      return [];
    }
  }

  resetGenre() {
    // this.selectedGenre = '';
    // this.selectedSkill = '';
  }

  resetSkill() {
    // this.selectedSkill = '';
  }

  getVendor() {
    this._contentUploadSvc.getVendor().subscribe(
      (response: any) => {
        if (response.length > 0) {
          this.vendorList = response;
        } else {
          this.vendorList = [];
        }
      },
      (error: any) => {
        this.vendorList = [];
      }
    );
  }

  getCourseTypeList(expertise) {
    this._contentUploadSvc.getCourseTypeList(expertise).subscribe(
      (response: any) => {
        if (response.length > 0) {
          this.courseTypeList = response;
        } else {
          this.courseTypeList = [];
        }
      },
      (error: any) => {
        this.courseTypeList = [];
      }
    );
  }

  getCourseModeOfPayment() {
    this._contentUploadSvc.getCourseModeOfPayment().subscribe(
      (response: any) => {
        if (response.length > 0) {
          this.courseModeOfPaymentList = response;
        } else {
          this.courseModeOfPaymentList = [];
        }
      },
      (error: any) => {
        this.courseModeOfPaymentList = [];
      }
    );
  }
  getCourseClassification() {
    this._contentUploadSvc.getCourseClassification().subscribe(
      (response: any) => {
        if (response.length > 0) {
          this.courseClassificationList = response;
        } else {
          this.courseClassificationList = [];
        }
      },
      (error: any) => {
        this.courseClassificationList = [];
      }
    );
  }
  getCourseInfrastructure() {
    this._contentUploadSvc.getCourseInfrastructure().subscribe(
      (response: any) => {
        if (response.length > 0) {
          this.courseInfrastructureList = response;
          this.buildInfrastructure();
          this.buildAssesmentInfrastructure();
        } else {
          this.courseInfrastructureList = [];
        }
      },
      (error: any) => {
        this.courseInfrastructureList = [];
      }
    );
  }
  getCourseInfrastructureType() {
    this._contentUploadSvc.getCourseInfrastructureType().subscribe(
      (response: any) => {
        if (response.length > 0) {
          this.courseInfrastructureTypeList = response;
          this.buildInfrastructureType();
          this.buildAssesmentInfrastructureType();
        } else {
          this.courseInfrastructureTypeList = [];
        }
      },
      (error: any) => {
        this.courseInfrastructureTypeList = [];
      }
    );
  }
  getCourseLogin() {
    this._contentUploadSvc.getCourseLogin().subscribe(
      (response: any) => {
        if (response.length > 0) {
          this.courseLoginList = response;
          this.buildLoginType();
        } else {
          this.courseLoginList = [];
        }
      },
      (error: any) => {
        this.courseLoginList = [];
      }
    );
  }
  getCourseLoginType() {
    this._contentUploadSvc.getCourseLoginType().subscribe(
      (response: any) => {
        if (response.length > 0) {
          this.courseLoginTypeList = response;
          this.buildLoginDescription();
        } else {
          this.courseLoginTypeList = [];
        }
      },
      (error: any) => {
        this.courseLoginTypeList = [];
      }
    );
  }
  getCourseSessionType() {
    this._contentUploadSvc.getCourseSessionType().subscribe(
      (response: any) => {
        if (response.length > 0) {
          this.courseSessionTypeList = response;
        } else {
          this.courseSessionTypeList = [];
        }
      },
      (error: any) => {
        this.courseSessionTypeList = [];
      }
    );
  }
  getCourseCompletion() {
    this._contentUploadSvc.getCourseCompletion().subscribe(
      (response: any) => {
        if (response.length > 0) {
          this.courseCompletionList = response;
          this.buildCourseCompletion();
        } else {
          this.courseCompletionList = [];
        }
      },
      (error: any) => {
        this.courseCompletionList = [];
      }
    );
  }
  getCourseCompletionType() {
    this._contentUploadSvc.getCourseCompletionType().subscribe(
      (response: any) => {
        if (response.length > 0) {
          this.courseCompletionTypeList = response;
          this.buildCourseCompletionType();
        } else {
          this.courseCompletionTypeList = [];
        }
      },
      (error: any) => {
        this.courseCompletionTypeList = [];
      }
    );
  }

  getCourseEligibility() {
    this._contentUploadSvc.getCourseEligibility().subscribe(
      (response: any) => {
        if (response.length > 0) {
          this.courseEligibilityList = response;
          this.courseEligibilityList.forEach(value => {
            if (value.EligibleGroup === 'Offshore Minds')
              this.contentForm.controls['eligibility'].setValue(
                value.EligibleGroup
              );
          });
        } else {
          this.courseEligibilityList = [];
        }
      },
      (error: any) => {
        this.courseEligibilityList = [];
      }
    );
  }

  getCourseAccessibility() {
    this._contentUploadSvc.getCourseAccessibility().subscribe(
      (response: any) => {
        if (response.length > 0) {
          this.courseAccessibilityList = response;
          this.courseAccessibilityList.forEach(value => {
            if (value.Access === 'Open')
              this.contentForm.controls['accessibility'].setValue(
                value.Access
              );
          });
        } else {
          this.courseAccessibilityList = [];
        }
      },
      (error: any) => {
        this.courseAccessibilityList = [];
      }
    );
  }

  OnContentFormSubmit()
  {
    const headers = new HttpHeaders().set('content-type', 'application/json');
    const data=JSON.stringify(this.contentForm.value);
    this._contentUploadSvc.insertContentFormFor201(data,{headers}).subscribe(
      (response: any) => {
        if (response.length > 0) {
          this.courseAccessibilityList = response;
          this.courseAccessibilityList.forEach(value => {
            if (value.Access === 'Open')
              this.contentForm.controls['courseAccessibility'].setValue(
                value.Access
              );
          });
        } else {
          this.courseAccessibilityList = [];
        }
      },
      (error: any) => {
        this.courseAccessibilityList = [];
      }
    );
  }
  buildLoginDescription(){

  }

}
