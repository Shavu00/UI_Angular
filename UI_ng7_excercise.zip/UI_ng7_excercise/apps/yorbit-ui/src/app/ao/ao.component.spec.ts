import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AoComponent } from './ao.component';

describe('AoComponent', () => {
  let component: AoComponent;
  let fixture: ComponentFixture<AoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
