import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FlexLayoutModule} from '@angular/flex-layout';
import { AoRoutingModule } from './ao-routing.module';
import { AoComponent } from './ao.component';
import {ReusableUiModule} from '@YorbitWorkspace/reusable-ui';
import { NewCourseRequestApprovalComponent } from './new-course-request-approval/new-course-request-approval.component';
import { ContentUploadComponent } from './content-upload/content-upload.component';
//import { MatInputModule, } from '@angular/material';
import { ContentUploadPopupComponent } from './content-upload-popup/content-upload-popup.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DirectivesModule } from '@YorbitWorkspace/directives';
import { MatInputModule, MatExpansionModule, MatCheckboxModule, MatDatepickerModule, MatIconModule, MatDialogModule } from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    AoRoutingModule,
    FlexLayoutModule,
    MatInputModule,
    MatIconModule,
    MatDialogModule,
    ReusableUiModule,
    FormsModule,
    ReactiveFormsModule,
    DirectivesModule,
    MatExpansionModule,
    MatCheckboxModule,
    MatDatepickerModule
  ],
  declarations: [AoComponent, NewCourseRequestApprovalComponent, ContentUploadComponent, ContentUploadPopupComponent],
  entryComponents: [
    ContentUploadPopupComponent
  ]
})
export class AoModule { }
