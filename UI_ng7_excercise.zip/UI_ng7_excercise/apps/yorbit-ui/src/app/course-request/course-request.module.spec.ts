import { CourseRequestModule } from './course-request.module';

describe('CourseRequestModule', () => {
  let courseRequestModule: CourseRequestModule;

  beforeEach(() => {
    courseRequestModule = new CourseRequestModule();
  });

  it('should create an instance', () => {
    expect(courseRequestModule).toBeTruthy();
  });
});
