import { TestBed, inject } from '@angular/core/testing';

import { CourseRequestService } from './course-request.service';

describe('CourseRequestService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CourseRequestService]
    });
  });

  it('should be created', inject([CourseRequestService], (service: CourseRequestService) => {
    expect(service).toBeTruthy();
  }));
});
