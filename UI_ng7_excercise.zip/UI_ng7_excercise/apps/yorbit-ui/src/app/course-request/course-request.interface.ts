export enum APIResponse{
  Success = 'newCourseReqSuccess',
  Error = 'newCourseReqError'
}

export enum Messages{
  SuccessMsg = 'Course request is submitted successfully',
  ErrorMsg = 'Something went wrong. Please try later'
}
