import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CourseRequestPopupComponent } from './course-request-popup.component';

describe('CourseRequestPopupComponent', () => {
  let component: CourseRequestPopupComponent;
  let fixture: ComponentFixture<CourseRequestPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CourseRequestPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CourseRequestPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
