import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PowerbiComponent } from './powerbi.component';
import { NgxPowerBiModule } from 'ngx-powerbi';
import { PowerbiService } from './powerbi.service';
import { PipesModule } from '@YorbitWorkspace/pipes';
import { MatIconModule, MatButtonModule, MatSidenavModule, MatDividerModule } from '@angular/material';

@NgModule({
  imports: [CommonModule, NgxPowerBiModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatDividerModule,

      PipesModule],
  declarations: [PowerbiComponent],
  providers: [PowerbiService],
  exports: [NgxPowerBiModule]
})
export class PowerbiModule {}
