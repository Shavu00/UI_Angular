import { PowerbiModule } from './powerbi.module';

describe('PowerbiModule', () => {
  let powerbiModule: PowerbiModule;

  beforeEach(() => {
    powerbiModule = new PowerbiModule();
  });

  it('should create an instance', () => {
    expect(powerbiModule).toBeTruthy();
  });
});
