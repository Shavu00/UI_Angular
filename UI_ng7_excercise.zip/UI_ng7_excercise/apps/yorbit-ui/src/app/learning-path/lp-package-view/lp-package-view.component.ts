import { Component, OnInit, OnDestroy } from '@angular/core';
import { LearningPathService } from '../learning-path.service';
import {
  Router,
  ActivatedRoute,
  ParamMap,
  NavigationEnd
} from '@angular/router';
import { Store } from '@ngrx/store';
import * as fromUserDetailsStore from '../../shared/user-details/store';
import {
  LearningPath,
  PackageList
} from '../../shared/user-details/store/user-details.interface';
import { ArrayPropertyFilterPipe } from 'libs/pipes/src/lib/array-property-filter.pipe';
import {
  LPBreadcrumbsStateModel,
  ICourseDetailsModel,
  IPackageDetailsModel,
  IVideoDetailsModel,
  IUnitDetailsModel
} from '../learning-path-breadcrumbs.model';
import { ILPBreadcrumbs } from '../learning-path-breadcrumbs.interface';
import { Subscriber } from 'rxjs';
@Component({
  selector: 'yorbit-lp-package-view',
  templateUrl: './lp-package-view.component.html',
  styleUrls: ['./lp-package-view.component.scss']
})
export class LPPackageViewComponent implements OnInit, OnDestroy {
  filterPipe = new ArrayPropertyFilterPipe();
  LPPackageCompSubscriptions: any;
  LPBreadcrumbs: ILPBreadcrumbs;
  LearningPath: LearningPath;
  packageEntity: PackageList;
  coursesList: Array<any>;
  pageLoading:boolean;
  pageLoadedSuccessfully:boolean;
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private lpService: LearningPathService,
    private userDetailsStore: Store<fromUserDetailsStore.IuserDetailsState>
  ) {
    this.LPPackageCompSubscriptions = {};
    this.LearningPath = {};
    this.packageEntity = {};
    this.coursesList = [];
    this.pageLoading=true;
    this.pageLoadedSuccessfully=false;
  }

  ngOnInit() {
    this.subscribeToRouterEvents();
    this.subscribeToBreadcrumbs();
  }
  subscribeToBreadcrumbs() {
    this.LPPackageCompSubscriptions.breadcrumbsSubscription = this.lpService
      .getBreadCrumbs()
      .subscribe(breadcrumbs => {
        this.LPBreadcrumbs = breadcrumbs;
      });
  }
  subscribeToRouterEvents() {
    this.LPPackageCompSubscriptions.routerParamsSubscriptions = this.activatedRoute.params.subscribe(
      params => {
        this.userDetailsStore
          .select(fromUserDetailsStore.getLearningPathListEntities)
          .subscribe(res => {
            if (res[params.lpId.toUpperCase()] != undefined && this.packageEntity.ItemId == undefined) {
              this.LearningPath = res[params.lpId.toUpperCase()];
              this.getPackageDetails(params.packageId);
            }
          });
      }
    );
  }
  getPackageDetails(packageId) {
    let packages = this.filterPipe.transform(
      this.LearningPath.PackageList,
      {
        property: 'ItemType',
        flag: 'Package'
      }
    );
    let familyPackages = this.filterPipe.transform(
      this.LearningPath.PackageList,
      {
        property: 'ItemType',
        flag: 'FamilyPackage'
      }
    );
    let allPackageEntitiesInLP = packages.concat(familyPackages);
    let undeletedEntities = this.filterPipe.transform(
      allPackageEntitiesInLP,
      {
        property: 'IsDeleted',
        flag: false
      }
    );
    this.packageEntity = this.filterPipe.transform(
      undeletedEntities,
      {
        property: 'ItemId',
        flag: packageId
      }
    )[0];
    let courseEntity = { ...ICourseDetailsModel };
    let unitEntity = { ...IUnitDetailsModel };
    let videoEntity = { ...IVideoDetailsModel };

    this.lpService.updateBreadcrumbs(
      this.LearningPath,
      this.packageEntity,
      null,
      null,
      null
    );
    this.getCoursesInsidePackage(this.packageEntity);
  }
  getCoursesInsidePackage(packageEntity) {
    let packageId = packageEntity.ItemId;
    let accountId = packageEntity.AccountId;
    let projectId = packageEntity.ProjectId;
    this.LPPackageCompSubscriptions.getCoursesInPackages = this.userDetailsStore
      .select(fromUserDetailsStore.getPackagesListWithCourses)
      .subscribe(PackagesListWithCourses => {
        if (
          PackagesListWithCourses != undefined &&
          PackagesListWithCourses[packageId] != undefined
        ) {
          this.coursesList = PackagesListWithCourses[packageId];
          this.pageLoading=false;
          this.pageLoadedSuccessfully=true;
        } else {
          this.lpService.loadCoursesInsidePackageToStore(
            this.packageEntity.AssignedBy,
            packageId,
            accountId,
            projectId
          );
        }
      });
  }
  navigateTo(data) {
    if (data.AccountId == '' || data.AccountId == undefined) {
      data.AccountId = null;
    }
    if (data.ProjectId == '' || data.ProjectId == undefined) {
      data.ProjectId = null;
    }
    this.router.navigate(
      [
        'course/' +
          data.ItemId +
          '/account/' +
          data.AccountPackage +
          '/project/' +
          data.ProjectPackage +
          '/accountId/' +
          data.AccountId +
          '/projectId/' +
          data.ProjectId +
          '/tabs/playlist'
      ],
      { relativeTo: this.activatedRoute }
    );
  }
  goBackToLP() {
    this.router.navigate([
      'learningpath/category/' +
        this.LPBreadcrumbs.LPDetails.LPCategory +
        '/id/' +
        this.LPBreadcrumbs.LPDetails.LPId
    ]);
  }
  ngOnDestroy() {
    this.unsubscribeAllSubscriptions;
  }
  unsubscribeAllSubscriptions() {
    for (let subscriberKey in this.LPPackageCompSubscriptions) {
      let subscriber = this.LPPackageCompSubscriptions[subscriberKey];
      if (subscriber instanceof Subscriber) {
        subscriber.unsubscribe();
      }
    }
  }
}
