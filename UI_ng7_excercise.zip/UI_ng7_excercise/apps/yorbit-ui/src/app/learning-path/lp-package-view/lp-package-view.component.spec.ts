import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LPPackageViewComponent } from './lp-package-view.component';

describe('LPPackageViewComponent', () => {
  let component: LPPackageViewComponent;
  let fixture: ComponentFixture<LPPackageViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LPPackageViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LPPackageViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
