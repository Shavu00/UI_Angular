import { Injectable } from '@angular/core';
import {
  Ienvironment,
  EnvironmentService
} from '@YorbitWorkspace/global-environments';
import { HttpClient } from '@angular/common/http';
import { Store } from '@ngrx/store';
import * as fromUserDetailsStore from '../shared/user-details/store';
import { BehaviorSubject, Observable } from 'rxjs';
import {
  LPBreadcrumbsStateModel,
  ILPDetailsModel,
  ICourseDetailsModel,
  IPackageDetailsModel,
  IVideoDetailsModel,
  IUnitDetailsModel
} from './learning-path-breadcrumbs.model';
import { ILPBreadcrumbs } from './learning-path-breadcrumbs.interface';
import { ArrayPropertyFilterPipe } from 'libs/pipes/src/lib/array-property-filter.pipe';

@Injectable()
export class LearningPathService {
  _addLpUrl = 'User/Add/LearningPath/';
  config: Ienvironment;
  _breadcrumbs: BehaviorSubject<any>;
  _searchLPModel: BehaviorSubject<any>;
  _resumeLPStatus: BehaviorSubject<boolean>;
  filterPipe: any;
  courses: any;
  skillPathPackageList: Array<any>;
  constructor(
    private http: HttpClient,
    private _envSvc: EnvironmentService,
    private userDetailsStore: Store<fromUserDetailsStore.IuserDetailsState>
  ) {
    this.config = this._envSvc.getEnvironment();
    let breadcrumbs = { ...LPBreadcrumbsStateModel };
    this._breadcrumbs = new BehaviorSubject(breadcrumbs);
    this._searchLPModel = new BehaviorSubject('');
    this._resumeLPStatus = new BehaviorSubject(false);
    this.filterPipe = new ArrayPropertyFilterPipe();
    this.courses = {};
    this.skillPathPackageList = [];
  }
  getResumeStatus() {
    return this._resumeLPStatus.asObservable();
  }
  updateResumeStatus(data) {
    this._resumeLPStatus.next(data);
  }
  getSearchLPModel() {
    return this._searchLPModel.asObservable();
  }
  updateSearchModel(data) {
    this._searchLPModel.next(data);
  }
  getBreadCrumbs() {
    return this._breadcrumbs.asObservable();
  }
  updateBreadcrumbs(
    lpEntity,
    packageEntity,
    courseEntity,
    unitEntity,
    videoEntity
  ) {
    //lp details
    let LPBreadcrumbs = { ...LPBreadcrumbsStateModel };
    if (lpEntity != null) {
      if (lpEntity.PathId != undefined) {
        LPBreadcrumbs.LPDetails.LPId = lpEntity.PathId;
        LPBreadcrumbs.LPDetails.IsLPMandatory = lpEntity.IsMandatory;
        if(lpEntity.PathName.toLowerCase() == 'business ethics and compliance'){
          LPBreadcrumbs.LPDetails.LPCategory = 'myCompliance';
          LPBreadcrumbs.LPDetails.LPId = lpEntity.PathName;
        }
        else if (lpEntity.IsSkillPlan) {
          LPBreadcrumbs.LPDetails.LPCategory = 'skilling';
        } else if (lpEntity.IsMandatory) {
          LPBreadcrumbs.LPDetails.LPCategory = 'mandatory';
          LPBreadcrumbs.LPDetails.LPId = lpEntity.PathName;
        } else {
          LPBreadcrumbs.LPDetails.LPCategory = 'self';
        }
        LPBreadcrumbs.LPDetails.LPName = lpEntity.PathName;
      } else {
        LPBreadcrumbs.LPDetails.LPId = lpEntity.LPId;
        LPBreadcrumbs.LPDetails.LPName = lpEntity.LPName;
        LPBreadcrumbs.LPDetails.LPCategory = lpEntity.LPCategory;
        LPBreadcrumbs.LPDetails.IsLPMandatory = lpEntity.IsLPMandatory;
        LPBreadcrumbs.LPDetails.SkillPlanId = lpEntity.SkillPlanId;
      }
      //lp name
    } else {
      LPBreadcrumbs.LPDetails = { ...ILPDetailsModel };
    }
    //package details
    if (packageEntity != null) {
      if (packageEntity.ItemExpertise != undefined) {
        LPBreadcrumbs.PackageDetails.Expertise = packageEntity.ItemExpertise;
      } else {
        LPBreadcrumbs.PackageDetails.Expertise = packageEntity.Expertise;
      }
      if (packageEntity.ItemName != undefined) {
        LPBreadcrumbs.PackageDetails.PackageName = packageEntity.ItemName;
      } else {
        LPBreadcrumbs.PackageDetails.PackageName = packageEntity.PackageName;
      }
      if (packageEntity.ItemId != undefined) {
        LPBreadcrumbs.PackageDetails.PackageId = packageEntity.ItemId;
      } else {
        LPBreadcrumbs.PackageDetails.PackageId = packageEntity.PackageId;
      }
      if (packageEntity.AccountPackage != undefined) {
        LPBreadcrumbs.PackageDetails.IsAccount = packageEntity.AccountPackage;
      } else {
        LPBreadcrumbs.PackageDetails.IsAccount = packageEntity.IsAccount;
      }
      if (packageEntity.ProjectPackage != undefined) {
        LPBreadcrumbs.PackageDetails.IsProject = packageEntity.ProjectPackage;
      } else {
        LPBreadcrumbs.PackageDetails.IsProject = packageEntity.IsProject;
      }
      if (
        LPBreadcrumbs.PackageDetails.IsProject == true ||
        LPBreadcrumbs.PackageDetails.IsAccount == true
      ) {
        if (packageEntity.UniqueId != undefined) {
          LPBreadcrumbs.PackageDetails.PackageId = packageEntity.UniqueId;
        }
      }
      LPBreadcrumbs.PackageDetails.AccountId = packageEntity.AccountId;
      LPBreadcrumbs.PackageDetails.ProjectId = packageEntity.ProjectId;
    } else {
      LPBreadcrumbs.PackageDetails = { ...IPackageDetailsModel };
    }
    if (courseEntity != null) {
      //Expertise
      if (courseEntity.ItemExpertise != undefined) {
        LPBreadcrumbs.CourseDetails.Expertise = courseEntity.ItemExpertise;
      } else {
        LPBreadcrumbs.CourseDetails.Expertise = courseEntity.Expertise;
      }
      //course name
      if (courseEntity.ItemName != undefined) {
        LPBreadcrumbs.CourseDetails.CourseName = courseEntity.ItemName;
      } else if (courseEntity.Name != undefined) {
        LPBreadcrumbs.CourseDetails.CourseName = courseEntity.Name;
      } else {
        LPBreadcrumbs.CourseDetails.CourseName = courseEntity.CourseName;
      }
      //Course Id
      if (courseEntity.ItemId != undefined) {
        LPBreadcrumbs.CourseDetails.CourseId = courseEntity.ItemId;
      } else if (courseEntity.Id != undefined) {
        LPBreadcrumbs.CourseDetails.CourseId = courseEntity.Id;
      } else {
        LPBreadcrumbs.CourseDetails.CourseId = courseEntity.CourseId;
      }
      //is account package
      if (courseEntity.AccountPackage != undefined) {
        LPBreadcrumbs.CourseDetails.IsAccount = courseEntity.AccountPackage;
      } else {
        LPBreadcrumbs.CourseDetails.IsAccount = courseEntity.IsAccount;
      }
      //is project package
      if (courseEntity.ProjectPackage != undefined) {
        LPBreadcrumbs.CourseDetails.IsProject = courseEntity.ProjectPackage;
      } else {
        LPBreadcrumbs.CourseDetails.IsProject = courseEntity.IsProject;
      }
      //is internal
      if (courseEntity.Internal != undefined) {
        LPBreadcrumbs.CourseDetails.IsInternal = courseEntity.Internal;
      } else {
        LPBreadcrumbs.CourseDetails.IsInternal = courseEntity.IsInternal;
      }
      //accountid
      if (courseEntity.AccountId != undefined) {
        LPBreadcrumbs.CourseDetails.AccountId = courseEntity.AccountId;
      } else if (courseEntity.Account != undefined) {
        LPBreadcrumbs.CourseDetails.AccountId = courseEntity.Account;
      }
      //accountid
      if (courseEntity.ProjectId != undefined) {
        LPBreadcrumbs.CourseDetails.ProjectId = courseEntity.ProjectId;
      } else if (courseEntity.Project != undefined) {
        LPBreadcrumbs.CourseDetails.ProjectId = courseEntity.Project;
      }
      if (
        LPBreadcrumbs.CourseDetails.IsProject == true ||
        LPBreadcrumbs.CourseDetails.IsAccount == true
      ) {
        if (courseEntity.UniqueId != undefined) {
          LPBreadcrumbs.CourseDetails.CourseId = courseEntity.UniqueId;
        }
      }
      LPBreadcrumbs.CourseDetails.VideoCount = courseEntity.VideoCount;
    } else {
      LPBreadcrumbs.CourseDetails = { ...ICourseDetailsModel };
    }
    if (unitEntity != null) {
      //Unit details
      LPBreadcrumbs.UnitDetails.UnitName = unitEntity.Name;
      if (unitEntity.AccountPackage || unitEntity.ProjectPackage) {
        LPBreadcrumbs.UnitDetails.UnitId = unitEntity.UniqueId;
      } else {
        LPBreadcrumbs.UnitDetails.UnitId = unitEntity.Id;
      }
      if (unitEntity.AccountPackage) {
        LPBreadcrumbs.UnitDetails.IsAccount = unitEntity.AccountPackage;
      } else {
        LPBreadcrumbs.UnitDetails.IsAccount = unitEntity.IsAccount;
      }
      if (unitEntity.ProjectPackage != undefined) {
        LPBreadcrumbs.UnitDetails.IsProject = unitEntity.ProjectPackage;
      } else {
        LPBreadcrumbs.UnitDetails.IsProject = unitEntity.IsProject;
      }
      if (unitEntity.Account != undefined) {
        LPBreadcrumbs.UnitDetails.AccountId = unitEntity.Account;
      } else {
        LPBreadcrumbs.UnitDetails.AccountId = unitEntity.AccountId;
      }
      if (unitEntity.Project != undefined) {
        LPBreadcrumbs.UnitDetails.ProjectId = unitEntity.Project;
      } else {
        LPBreadcrumbs.UnitDetails.ProjectId = unitEntity.ProjectId;
      }
      LPBreadcrumbs.UnitDetails.ContentCount = unitEntity.ContentCount;
    } else {
      LPBreadcrumbs.UnitDetails = { ...IUnitDetailsModel };
    }
    if (videoEntity != null) {
      //video details
      LPBreadcrumbs.VideoDetails.VideoType = videoEntity.SourceType;
      LPBreadcrumbs.VideoDetails.VideoId = videoEntity.Id;
      LPBreadcrumbs.VideoDetails.VideoName = videoEntity.Title;
      LPBreadcrumbs.UnitDetails.IsAccount = videoEntity.AccountPackage;
      LPBreadcrumbs.UnitDetails.IsProject = videoEntity.ProjectPackage;
      LPBreadcrumbs.UnitDetails.AccountId = videoEntity.Account;
      LPBreadcrumbs.UnitDetails.ProjectId = videoEntity.Project;
      LPBreadcrumbs.VideoDetails.IsCompliance = videoEntity.Compliance;
    } else {
      LPBreadcrumbs.VideoDetails = { ...IVideoDetailsModel };
    }
    this._breadcrumbs.next(LPBreadcrumbs);
  }
  quizAvailabilityCheck(data) {
    if (data.IsAccount) {
      return this.http
        .post(
          this.config.apiUrl +
            'AccountQuiz/CheckAndAdd/' +
            data.courseId +
            '/' +
            data.entityType +
            '/' +
            data.AccountId,
          {}
        )
        .toPromise();
    } else if (data.IsProject) {
      return this.http
        .post(
          this.config.apiUrl +
            'ProjectQuiz/CheckAndAdd/' +
            data.courseId +
            '/' +
            data.entityType +
            '/' +
            data.ProjectId,
          {}
        )
        .toPromise();
    } else {
      return this.http
        .post(
          this.config.apiUrl +
            'Quiz/CheckAndAdd/' +
            data.courseId +
            '/' +
            data.entityType,
          {}
        )
        .toPromise();
    }
  }
  checkLpExistAndAdd(_learningPathTitle, _learningPaths) {
    const lpTitle =
      undefined !== _learningPathTitle && null !== _learningPathTitle
        ? _learningPathTitle.trim()
        : '';
    if ('' !== lpTitle && null != lpTitle) {
      const nonDeletedLPs = _learningPaths.filter(val => {
        return val.IsDeleted === false;
      });
      let pathExists = false;
      nonDeletedLPs.forEach(lp => {
        if (lp.PathName.toLowerCase() === lpTitle.toLowerCase()) {
          pathExists = true;
        }
      });
      if (pathExists) {
        const promise = new Promise(() => {
          const response = {
            errorMessage:
              'LearningPath ' + "'" + lpTitle + "'" + ' Already Exist'
          };
          throw response;
        });
        return promise;
      } else {
        return this.addLearningPath(lpTitle)
          .then(result => {
            this.userDetailsStore.dispatch(
              new fromUserDetailsStore.UserDetailsAddLearningPath(result)
            );
            const promise = new Promise(resolve => {
              const response = result;
              resolve(response);
            });
            return promise;
          })
          .catch(error => {
            const promise = new Promise(() => {
              const response = {
                errorMessage: 'An error has occured'
              };
              throw response;
            });
            return promise;
          });
      }
    } else {
      const promise = new Promise(() => {
        const response = {
          errorMessage: 'Title cannot be empty'
        };
        throw response;
      });
      return promise;
    }
  }
  deleteLearningPath(lp) {
    return this.http
      .delete(this.config.apiUrl + 'User/Remove/LearningPath/' + lp.PathId)
      .toPromise();
  }
  addLearningPath(_LearningPathTitle) {
    const title = {
      Name: _LearningPathTitle
    };
    return this.http
      .put(this.config.apiUrl + this._addLpUrl, title)
      .toPromise();
  }
  getCoursesInsidePackage(id, account, project) {
    if (
      (null == account && null == project) ||
      (account == undefined && project == undefined)
    ) {
      //Yorbit
      return this.http
        .get(this.config.apiUrl + 'Courses/PackageIncludingHiddenCourses/' + id)
        .toPromise();
    } else {
      let Url,
        payload = {
          AccountOrProjectId: '',
          PackageId: id
        };
      if (null != project) {
        //project
        Url =
          this.config.apiUrl + 'Course/Project/NonYorbitPackageIncludingHidden';
        payload.AccountOrProjectId = project;
      } else {
        //account
        Url =
          this.config.apiUrl + 'Course/Account/NonYorbitPackageIncludingHidden';
        payload.AccountOrProjectId = account;
      }
      return this.http.post(Url, payload).toPromise();
    }
  }
  loadCoursesInsidePackageToStore(assignedBy, packageId, accountId, projectId) {
    let packageDetails = {};
    packageDetails[packageId] = [];
    return this.getCoursesInsidePackage(packageId, accountId, projectId).then(
      (courseIds: Array<String>) => {
        if (courseIds != null) {
          this.userDetailsStore
            .select(fromUserDetailsStore.getCourseProgressListSelector)
            .subscribe(courseProgressList => {
              courseIds.forEach(courseId => {
                let courseDetails = this.filterPipe.transform(
                  courseProgressList,
                  {
                    property: 'CourseId',
                    flag: courseId.toString()
                  }
                )[0];
                if (courseDetails != undefined) {
                  if (courseDetails.Duration == null) {
                    courseDetails.Duration = '00:00:00';
                  }

                  let course = {
                    ItemId: courseDetails.CourseId,
                    RequestId: courseDetails.RequestID,
                    ItemType: 'Course',
                    ItemName: courseDetails.CourseName,
                    ItemExpertise: courseDetails.Expertise,
                    ImageUrl: '',
                    VideoCount: courseDetails.ContentCount,
                    Badges: [],
                    BadgeIds: null,
                    PackageProgress: {
                      Progress: courseDetails.Progress,
                      ConsumedTime: courseDetails.ConsumedTime,
                      TimeLeft: courseDetails.TimeLeft,
                      TotalTime: courseDetails.Duration
                    },
                    ProgressList: [],
                    Declaration: false,
                    IsMandatory: true,
                    AssignedBy: assignedBy,
                    AssignorRole: null,
                    Department: null,
                    IsCancelable: false,
                    AccountPackage: courseDetails.IsAccount,
                    ProjectPackage: courseDetails.IsProject,
                    Category: null,
                    AccountId: courseDetails.AccountId,
                    ProjectId: courseDetails.ProjectId,
                    WorflowStatus: courseDetails.WorflowStatus,
                    SubStatus: courseDetails.SubStatus,
                    DueDate: '0001-01-01T00:00:00',
                    IsDeleted: false,
                    CreatedDate: '0001-01-01T00:00:00',
                    ModifiedDate: '0001-01-01T00:00:00',
                    DeletedDate: '0001-01-01T00:00:00',
                    CompletedDate: '0001-01-01T00:00:00',
                    IsInIDP: false,
                    IsBlocked: false
                  };
                  this.userDetailsStore
                    .select(
                      fromUserDetailsStore.getBadgesByCourseIdSelector(courseId)
                    )
                    .subscribe(badge => {
                      //console.log("badges",badge);
                      if (
                        badge != undefined &&
                        badge != null &&
                        badge.BadgeId
                      ) {
                        course.Badges = [];
                        course.Badges.push(badge);
                      }
                    });
                  packageDetails[packageId].push(course);
                }
              });
            });
        }
        this.userDetailsStore.dispatch(
          new fromUserDetailsStore.UserDetailsUpdatePackageCoursesList(
            packageDetails
          )
        );
        return packageDetails[packageId];
      }
    );
  }
  getCourseDetails(id, type, isAccountRelated, payload) {
    if (this.courses[id] != undefined) {
      let promise = new Promise((resolve, reject) => {
        resolve(this.courses[id]);
      });
      return promise;
    } else {
      if (!isAccountRelated) {
        if (type == 'Course') {
          return this.http.get(this.config.apiUrl + 'Course/' + id).toPromise();
        } else {
          return this.http
            .get(this.config.apiUrl + 'Package/' + id + '/' + type)
            .toPromise();
        }
      } else {
        if (type == 'Course') {
          return this.http
            .post(this.config.apiUrl + 'Course', payload)
            .toPromise();
        } else {
          return this.http
            .post(this.config.apiUrl + 'Package', payload)
            .toPromise();
        }
      }
    }
  }
  storeCourseDetails(course) {
    if (course != null) {
      if (course.AccountPackage == 'true' || course.ProjectPackage == 'true') {
        //this.courses[course.UniqueId] = course;
      } else {
        //this.courses[course.Id] = course;
      }
    }
  }
  getRecommendationDetails(id) {
    return this.http
      .get<any>(this.config.apiUrl + 'recommendations/byCourse/' + id)
      .toPromise();
  }
  setSkillPathPackageList(list) {
    this.skillPathPackageList = list;
  }
  getSkillPathPackageList() {
    return this.skillPathPackageList;
  }
}
