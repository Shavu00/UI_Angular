import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LPDetailedComponent } from './lp-detailed.component';

describe('LPDetailedComponent', () => {
  let component: LPDetailedComponent;
  let fixture: ComponentFixture<LPDetailedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LPDetailedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LPDetailedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
