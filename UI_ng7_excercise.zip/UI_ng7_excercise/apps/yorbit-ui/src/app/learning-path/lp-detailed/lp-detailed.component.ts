import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import {
  Router,
  ActivatedRoute,
  ParamMap,
  NavigationEnd
} from '@angular/router';
import { LearningPathService } from '../learning-path.service';
import * as fromUserDetailsStore from '../../shared/user-details/store';
import {
  LearningPath,
  PackageList
} from '../../shared/user-details/store/user-details.interface';
import { Store } from '@ngrx/store';
import {
  LPBreadcrumbsStateModel,
  ICourseDetailsModel,
  IPackageDetailsModel,
  IVideoDetailsModel,
  IUnitDetailsModel
} from '../learning-path-breadcrumbs.model';
import { ILPBreadcrumbs } from '../learning-path-breadcrumbs.interface';
import { FilterContentTileByItsPropertiesPipe } from '@YorbitWorkspace/pipes';
import { Subscriber } from 'rxjs';
import { ArrayPropertyFilterPipe } from 'libs/pipes/src/lib/array-property-filter.pipe';
import { MatDialog } from '@angular/material';
import { ContentTileLpComponent } from '../../shared/content-tiles/content-tile-lp/content-tile-lp.component';
@Component({
  selector: 'yorbit-lp-detailed',
  templateUrl: './lp-detailed.component.html',
  styleUrls: ['./lp-detailed.component.scss']
})
export class LPDetailedComponent implements OnInit, OnDestroy {
  arrayPropertyFilterPipe: any;
  LPBreadcrumbs: ILPBreadcrumbs;
  learningPath: LearningPath;
  packageList: PackageList[];
  LPDeatilsCompSubscriptions: any;
  targetSkill: any;
  filterContentTiles: any;
  showTargetSkill: boolean;
  showSelectedCourseFromTargetSkill: boolean;
  selectedCourseFromTargetSkill: PackageList;
  showNoSearchResultsInfo: boolean;
  searchBy:string;
  @ViewChild(ContentTileLpComponent) lpContentTile;
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private lpService: LearningPathService,
    private userDetailsStore: Store<fromUserDetailsStore.IuserDetailsState>,
    private dialog: MatDialog
  ) {
    this.LPDeatilsCompSubscriptions = {};
    this.learningPath = {};
    this.learningPath.PackageList = [];
    this.targetSkill = {};
    this.packageList = [];
    this.filterContentTiles = new FilterContentTileByItsPropertiesPipe();
    this.arrayPropertyFilterPipe = new ArrayPropertyFilterPipe();
    this.selectedCourseFromTargetSkill = {};
    this.showNoSearchResultsInfo = false;
    this.searchBy="";
  }

  ngOnInit() {
    this.packageList = [];
    this.subscribeToRouterEvents();
    this.subscribeToLPFilterModel();
    this.subscribeToBreadcrumbs();
    this.subscribeToDialogCloseEvent();
  }

  subscribeToBreadcrumbs() {
    this.LPDeatilsCompSubscriptions.breadcrumbsSubscription = this.lpService
      .getBreadCrumbs()
      .subscribe(breadcrumbs => {
        this.LPBreadcrumbs = breadcrumbs;

      });
  }
  subscribeToLPFilterModel() {
    this.lpService.getSearchLPModel().subscribe(model => {
      let filteredList;
      this.searchBy=model.toString();
      if (model.length != 0) {
        filteredList = this.filterContentTiles.transform(
          this.learningPath.PackageList,
          model
        );
      } else {
        filteredList = this.learningPath.PackageList;
      }
      this.packageList = this.arrayPropertyFilterPipe.transform(filteredList, {
        property: 'IsDeleted',
        flag: false
      });
      if (this.packageList.length == 0 && model.length != 0) {
        this.showNoSearchResultsInfo = true;
      } else {
        this.showNoSearchResultsInfo = false;
      }
    });
  }
  subscribeToRouterEvents() {
    this.LPDeatilsCompSubscriptions.routeParamsSubscriptions = this.activatedRoute.params.subscribe(
      params => {
        this.userDetailsStore
          .select(fromUserDetailsStore.getLearningPathListEntities)
          .subscribe(res => {
            if (res[params['lpId'].toUpperCase()] != undefined) {
              this.learningPath = res[params['lpId'].toUpperCase()];
              this.packageList = this.arrayPropertyFilterPipe.transform(
                this.learningPath.PackageList,
                {
                  property: 'IsDeleted',
                  flag: false
                }
              );
              if (params['category'] == 'skilling') {
                this.showTargetSkill = true;
                this.showSelectedCourseFromTargetSkill = false;
                this.targetSkill = {
                  ...this.packageList[this.packageList.length - 1]
                };
                this.lpService.setSkillPathPackageList(
                  this.packageList.slice(0, this.packageList.length - 1)
                );
              }

              if(params['category'] == 'myCompliance'){
                this.showTargetSkill = true;
                this.showSelectedCourseFromTargetSkill = false;
                this.targetSkill = {
                  ...this.packageList[0]
                };
                this.lpService.setSkillPathPackageList(
                  this.packageList
                );
              }

              if (params['category'] == 'self') {
                this.showTargetSkill = true;
                this.showSelectedCourseFromTargetSkill = false;
                this.targetSkill = {
                  ...this.packageList[0]
                };
                this.lpService.setSkillPathPackageList(
                  this.packageList
                );

              }

              if(params['category'] == 'myCompliance'){
                this.showTargetSkill = true;
                this.showSelectedCourseFromTargetSkill = false;
                this.targetSkill = {
                  ...this.packageList[0]
                };
                this.lpService.setSkillPathPackageList(
                  this.packageList
                );
              }

              if (params['category'] == 'self') {
                this.showTargetSkill = true;
                this.showSelectedCourseFromTargetSkill = false;
                this.targetSkill = {
                  ...this.packageList[0]
                };
                this.lpService.setSkillPathPackageList(
                  this.packageList
                );

              }
              // setTimeout(  this.updateWorflowStatus(),2000);
              this.lpService.updateBreadcrumbs(
                this.learningPath,
                null,
                null,
                null,
                null
              );
            } else {
              this.packageList = [];
            }
          });
      }
    );
  }
  navigateTo(data) {
    //console.log(data);
    if (data.AccountId === '') {
      data.AccountId = null;
    }
    if (data.ProjectId === '') {
      data.ProjectId = null;
    }
    if (data.ItemType === 'Package' || data.ItemType === 'FamilyPackage') {
      this.router.navigate([
        'learningpath/category/' +
          this.LPBreadcrumbs.LPDetails.LPCategory +
          '/id/' +
          this.LPBreadcrumbs.LPDetails.LPId +
          '/package/' +
          data.ItemId
      ]);
    } else {
      this.router.navigate([
        'learningpath/category/' +
          this.LPBreadcrumbs.LPDetails.LPCategory +
          '/id/' +
          this.LPBreadcrumbs.LPDetails.LPId +
          '/package/null/course/' +
          data.ItemId +
          '/account/' +
          data.AccountPackage +
          '/project/' +
          data.ProjectPackage +
          '/accountId/' +
          data.AccountId +
          '/projectId/' +
          data.ProjectId +
          '/tabs/playlist'
      ]);
    }
  }

  ngOnDestroy() {
    this.unsubscribeAllSubscriptions();
  }
  unsubscribeAllSubscriptions() {
    for (let subscriberKey in this.LPDeatilsCompSubscriptions) {
      let subscriber = this.LPDeatilsCompSubscriptions[subscriberKey];
      if (subscriber instanceof Subscriber) {
        subscriber.unsubscribe();
      }
    }
  }
  subscribeToDialogCloseEvent() {
    this.LPDeatilsCompSubscriptions.matDialogCloseSubscription = this.dialog.afterAllClosed.subscribe(
      val => {
        if (this.LPBreadcrumbs.LPDetails.LPId != null) {
          this.userDetailsStore
            .select(
              fromUserDetailsStore.getLearningPathByIdEntities(
                this.LPBreadcrumbs.LPDetails.IsLPMandatory ?  this.LPBreadcrumbs.LPDetails.LPName.toUpperCase(): this.LPBreadcrumbs.LPDetails.LPId
              )
            )
            .subscribe(lp => {
              this.packageList = this.arrayPropertyFilterPipe.transform(
                lp.PackageList,
                {
                  property: 'IsDeleted',
                  flag: false
                }
              );
            });
        }
      }
    );
  }
  showCourseFromTargetSkill(event) {
    if (event.ItemId) {
      this.showTargetSkill = false;
      this.showSelectedCourseFromTargetSkill = true;
      this.selectedCourseFromTargetSkill = this.arrayPropertyFilterPipe.transform(
        this.packageList,
        {
          property: 'ItemId',
          flag: event.ItemId
        }
      )[0];
    }
  }
  updateDeclareForSkilling(){
    this.packageList = [];
    this.subscribeToRouterEvents();
    this.subscribeToLPFilterModel();
    this.subscribeToBreadcrumbs();
    this.subscribeToDialogCloseEvent();
    this.lpContentTile.reloadSkillTargetCourse();
  }
}
