
export interface ILPBreadcrumbs{
  LPDetails: ILPDetails;
  PackageDetails: IPackageDetails;
  CourseDetails:ICourseDetails;
  UnitDetails:IUnitDetails;
  VideoDetails: IVideoDetails;
}
export interface ILPDetails {
    LPCategory: null | String;
    LPName: null | String;
    IsLPMandatory: boolean;
    LPId: null | String | number;
    SkillPlanId:null | String | number;
}
export interface IPackageDetails {
    PackageName: null | String;
    PackageId: null | String | number;
    IsAccount:boolean;
    IsProject:boolean;
    AccountId:string;
    ProjectId:string;
    Expertise: null | String;
}
export interface ICourseDetails {
    CourseName: null | String;
    CourseId: null | String | number;
    IsAccount:boolean;
    IsProject:boolean;
    AccountId:string;
    ProjectId:string;
    Expertise: null | String;
    VideoCount:number|string;
    IsInternal:boolean;
}
export interface IUnitDetails {
    UnitName: null | String;
    UnitId: null | String | number;
    IsAccount:boolean;
    IsProject:boolean;
    AccountId:string;
    ProjectId:string;
    ContentCount:number|string;
}
export interface IVideoDetails {
    VideoType: null | String;
    VideoId: null | String;
    VideoName: null | String;
    IsAccount:boolean;
    IsProject:boolean;
    AccountId:string;
    ProjectId:string;
    IsCompliance:boolean;
}
