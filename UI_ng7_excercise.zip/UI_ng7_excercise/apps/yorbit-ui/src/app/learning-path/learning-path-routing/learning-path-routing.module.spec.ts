import { LearningPathRoutingModule } from './learning-path-routing.module';

describe('LearningPathRoutingModule', () => {
  let LearningPathRoutingModule: LearningPathRoutingModule;

  beforeEach(() => {
    LearningPathRoutingModule = new LearningPathRoutingModule();
  });

  it('should create an instance', () => {
    expect(LearningPathRoutingModule).toBeTruthy();
  });
});
