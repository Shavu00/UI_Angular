import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { LearningPathComponent } from '../learning-path.component';
import { LPDetailedComponent } from '../lp-detailed/lp-detailed.component';
import { LPPackageViewComponent } from '../lp-package-view/lp-package-view.component';
import { LPCourseViewComponent } from '../lp-course-view/lp-course-view.component';
import { YoutubeVideoPlayerComponent } from '../../shared/video-players/youtube-video-player/youtube-video-player.component';
import { O365VideoPlayerComponent } from '../../shared/video-players/o365-video-player/o365-video-player.component';
import {LpCourseDescriptionComponent} from '../lp-course-view/lp-course-description/lp-course-description.component';
const routes: Routes = [
  {
    path: '',
    component: LearningPathComponent,
    children: [
      {
        path: 'category/:category/id/:lpId',
        component: LPDetailedComponent,
        data: {
          title: 'LearningPath Content'
        }
      },
      {
        path: 'category/:category/id/:lpId/package/:packageId',
        component: LPPackageViewComponent,
        data: {
          title: 'Package view'
        }
      },
      {
        path:'category/:category/id/:lpId/package/:packageId/course/:courseId/account/:accountPackage/project/:projectPackage/accountId/:accountId/projectId/:projectId/tabs/:tab',
        component: LPCourseViewComponent,
        data: {
          title: 'Course view'
        },
        children: [
          {
            path: 'youtube/videoId/:videoId',
            component: YoutubeVideoPlayerComponent,
            data: {
              title: 'Youtube comp'
            }
          },
          {
            path: 'o365/videoId/:videoId',
            component: O365VideoPlayerComponent,
            data: {
              title: 'O365 comp'
            }
          },
          {
            path:'type/external',
            component:LpCourseDescriptionComponent,
            data:{
              title:'External course description'
            }
          }
        ]
      }
    ]
  }
  
];
@NgModule({
  imports: [CommonModule, RouterModule.forChild(routes)],
  exports:[RouterModule]
})
export class LearningPathRoutingModule {}
