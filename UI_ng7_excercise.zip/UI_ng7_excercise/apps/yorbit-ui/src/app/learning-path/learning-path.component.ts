import {
  Component,
  OnInit,
  ViewChild,
  Input,
  OnDestroy,
  AfterViewInit,
  ElementRef
} from '@angular/core';
import { MediaChange, MediaObserver } from '@angular/flex-layout';
import {
  Router,
  ActivatedRoute,
  ParamMap,
  NavigationEnd
} from '@angular/router';
import { LearningPathService } from './learning-path.service';
import * as fromUserDetailsStore from '../shared/user-details/store';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { filter } from 'rxjs/operators';
import { IuserDetails } from '../shared/user-details/store/user-details.interface';
import { PopupTriggerService } from '../shared/services/popup-trigger.service';
import { ArrayPropertyFilterPipe } from 'libs/pipes/src/lib/array-property-filter.pipe';
import { LPBreadcrumbsStateModel } from './learning-path-breadcrumbs.model';
import { ILPBreadcrumbs } from './learning-path-breadcrumbs.interface';
import { Subscriber } from 'rxjs';
import {
  MatDialog,
  MatDialogConfig,
  MatDialogRef,
  MatSnackBarConfig,
  MatSnackBar
} from '@angular/material';
import { AddPopupComponent } from '../shared/card-feature/add-content/add-popup/add-popup.component';
import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';
import { CreateLpComponent } from '../shared/create-lp/create-lp/create-lp.component';

import { Globals } from '../globals';
import { PopupService } from '../shared/global-popups/popup.service';
import { CourseFeedbackComponent } from '../shared/global-popups/course-feedback/course-feedback.component';

@Component({
  selector: 'yorbit-learning-path',
  templateUrl: './learning-path.component.html',
  styleUrls: ['./learning-path.component.scss'],
  inputs: ['fxFlex']
})
export class LearningPathComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('LPnavbar') LPnavbar: any;
  @ViewChild('skillPathsExpansionPanel') skillPathsPanel: any;
  @ViewChild('lpTextbox') lpTextboxField: ElementRef;

  mediaBreakPoint: string;
  LPCategories: Array<string>;
  hasSideNavBackdrop: boolean;
  LPnavbarMode: string;
  mandatoryLps: Array<any>;
  skillingLps: Array<any>;
  myComplianceLp :Array<any>;
  userCreatedLps: Array<any>;
  LPPageSubscriptions: any = {};
  LPBreadcrumbs: ILPBreadcrumbs;
  learningPathsLoading: boolean;
  learningPathsLoadedSuccessfully: boolean;
  searchLPModel: string;
  resumeDetails: any;
  arrayFilterPipe: any;
  showSearchBarInLP: boolean;
  lpContent: any;
  createLpEditMode: boolean;
  createNewLPInProgress: boolean;
  learningPathTitle: string;
  lpCreated: boolean;
  constructor(
    private dialog: MatDialog,
    private mediaObserver: MediaObserver,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private lpService: LearningPathService,
    private userDetailsStore: Store<fromUserDetailsStore.IuserDetailsState>,
    private _dialog: MatDialog,
    private globals: Globals,
    private _popUpSvc: PopupService,
    private snackBar: MatSnackBar,
    private _popupTriggerService: PopupTriggerService
  ) {
    this.lpContent = [];
    this.mediaBreakPoint = '';
    this.createLpEditMode = false;
    this.LPCategories = ['self', 'myCompliance', 'mandatory', 'skilling'];
    this.learningPathsLoading = true;
    this.learningPathsLoadedSuccessfully = false;
    this.mandatoryLps = [];
    this.skillingLps = [];
    this.myComplianceLp =[];
    this.userCreatedLps = [];
    this.subscribeMediaChanges();
    this.searchLPModel = '';
    this.resumeDetails = null;
    this.getResumeDetails();
    this.arrayFilterPipe = new ArrayPropertyFilterPipe();
    this.showSearchBarInLP = false;
  }
  getResumeDetails() {
    this.LPPageSubscriptions.getResumeDetailsSub = this.userDetailsStore
      .select(fromUserDetailsStore.getLPResumeDetails)
      .subscribe(resumeDetails => {
        if (resumeDetails && resumeDetails != null && resumeDetails.ItemId) {
          this.resumeDetails = resumeDetails;
        }
      });
  }
  ngOnDestroy() {
    this.unsubscribeAllSubscriptions();
  }
  unsubscribeAllSubscriptions() {
    for (let subscriberKey in this.LPPageSubscriptions) {
      let subscriber = this.LPPageSubscriptions[subscriberKey];
      if (subscriber instanceof Subscriber) {
        subscriber.unsubscribe();
      }
    }
  }
  ngOnInit() {
    this.getLearningPaths();
    this.subscribeToBreadCrumbEvents();
    this.subscribeToRouterEvents();
    this._popupTriggerService.canTriggerPopupsOnLoad.subscribe(
      canTriggerPopupOnLoad => {
        if (canTriggerPopupOnLoad) {
          this.checkFeedback();
        }
      }
    );
  }
  subscribeToRouterEvents() {
    this.LPPageSubscriptions.routerEventsSub = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        if (event.url == '/learningpath') {
          this.getLearningPaths();
        }
      });
  }
  ngAfterViewInit() {
    if (this.LPBreadcrumbs.LPDetails.LPId != null) {
      if (this.LPBreadcrumbs.LPDetails.LPCategory == 'skilling') {
        if (this.skillPathsPanel) {
          this.skillPathsPanel.open();
        }
      }
    }
  }
  updateSearchModel() {
    this.lpService.updateSearchModel(this.searchLPModel);
  }
  subscribeMediaChanges() {
    this.LPPageSubscriptions.mediaChangeSubscription = this.mediaObserver.media$.subscribe(
      (media: MediaChange) => {
        //console.log("media query subs",media);
        this.mediaBreakPoint = media.mqAlias;
        //add this.router.url=='/learningpath' check in the below if condition for xs
        if (media.mqAlias == 'xs') {
          this.hasSideNavBackdrop = true;
          this.LPnavbarMode = 'over';
        } else if (media.mqAlias != 'xs') {
          this.hasSideNavBackdrop = false;
          this.LPnavbarMode = 'side';
        }
        if (this.LPnavbar != undefined) {
          this.openLPNavBar();
        }
      }
    );
  }
  subscribeToBreadCrumbEvents() {
    //create breadcrumbs model and interface to init it in different components as well instead in the service
    this.LPPageSubscriptions.breadcrumbsSubscription = this.lpService
      .getBreadCrumbs()
      .subscribe(breadcrumbs => {
        if (breadcrumbs.LPDetails.LPId != null) {
          this.userDetailsStore
            .select(
              fromUserDetailsStore.getLearningPathByIdEntities(
              //  breadcrumbs.LPDetails.IsLPMandatory ? breadcrumbs.LPDetails.LPName:breadcrumbs.LPDetails.LPId
              breadcrumbs.LPDetails.LPId.toUpperCase()
              )
            )
            .subscribe(lp => {
              this.lpContent = lp.PackageList;
            });
        }

        this.LPBreadcrumbs = breadcrumbs;
        if (this.LPBreadcrumbs.LPDetails.LPCategory == 'skilling') {
          if (this.skillPathsPanel) {
            this.skillPathsPanel.open();
          }
        }
        if (this.LPBreadcrumbs.CourseDetails.CourseId != null) {
          this.LPnavbar.close();
        } else {
          if (!this.mediaObserver.isActive('xs')) {
            this.LPnavbar.open();
          }
        }
      });
  }
  getLearningPaths() {
    this.learningPathsLoading = true;
    this.userDetailsStore.dispatch(
      new fromUserDetailsStore.UserDetailsGetDetails()
    );
    this.LPPageSubscriptions.getUserDetailLoading = this.userDetailsStore
      .select(fromUserDetailsStore.getUserDetailLoading)
      .subscribe(loading => {
        this.learningPathsLoading = loading;
      });
    this.LPPageSubscriptions.getUserDetailLoaded = this.userDetailsStore
      .select(fromUserDetailsStore.getUserDetailLoaded)
      .subscribe(loaded => {
        this.learningPathsLoadedSuccessfully = loaded;
      });

    this.LPPageSubscriptions.getUserCreatedLPsSelector = this.userDetailsStore
      .select(fromUserDetailsStore.getUserCreatedLPsSelector)
      .subscribe(res => {
        if (this.learningPathsLoadedSuccessfully) {

          this.userCreatedLps = res;
        }
      });
    this.LPPageSubscriptions.getSkillPathsSelector = this.userDetailsStore
      .select(fromUserDetailsStore.getSkillPathsSelector)
      .subscribe(res => {
        if (this.learningPathsLoadedSuccessfully) {
          this.skillingLps = res;
        }
      });
    this.LPPageSubscriptions.getSystemGeneratedMandatoryLPsSelector = this.userDetailsStore
      .select(fromUserDetailsStore.getSystemGeneratedMandatoryLPsSelector)
      .subscribe(res => {
        if (this.learningPathsLoadedSuccessfully) {
          if (res.length > 0) {
            this.mandatoryLps = res.filter(path=>{
              if(path.PathName.toLowerCase() !== 'business ethics and compliance'){
                return true
              }
            });
            this.myComplianceLp = res.filter(path=>{
              if(path.PathName.toLowerCase() === 'business ethics and compliance'){
                return true;
              }
            })
          }
            //this.mandatoryLps = res;
            this.loadLPNavbarView();
            this.initialLPLoad();
        }
      });
  }
  navigateAcrossLP(category, lpId, lpDetails) {
    this.lpContent = lpDetails.PackageList;
    if (this.mediaObserver.isActive('xs')) {
      this.LPnavbar.close();
    }
    this.router.navigate(['learningpath/category/' + category + '/id/' + lpId]);
  }
  //navigateto function comes in lp content tile comp
  navigateTo(data) {
    if (data == 'LP') {
      this.router.navigate([
        'learningpath/category/' +
        this.LPBreadcrumbs.LPDetails.LPCategory +
        '/id/' +
        this.LPBreadcrumbs.LPDetails.LPId
      ]);
    } else if (data == 'Package') {
      this.router.navigate([
        'learningpath/category/' +
        this.LPBreadcrumbs.LPDetails.LPCategory +
        '/id/' +
        this.LPBreadcrumbs.LPDetails.LPId +
        '/package/' +
        this.LPBreadcrumbs.PackageDetails.PackageId
      ]);
    }
  }
  loadLPNavbarView() {
    if (this.mediaObserver.isActive('xs')) {
      this.hasSideNavBackdrop = true;
      this.LPnavbarMode = 'over';
    } else if (this.mediaObserver.isActive('gt-xs')) {
      this.hasSideNavBackdrop = false;
      this.LPnavbarMode = 'side';
    }
    this.LPnavbar.open();
  }
  initialLPLoad() {
    if (this.router.url == '/learningpath') {
      if(this.myComplianceLp.length != 0){
        this.navigateAcrossLP(
          'myCompliance',
          this.myComplianceLp[0].PathName.toUpperCase(),
          this.myComplianceLp[0]
        );
      }
      else if (this.mandatoryLps.length != 0) {
        this.navigateAcrossLP(
          'mandatory',
          this.mandatoryLps[0].PathName.toUpperCase(),
          this.mandatoryLps[0]
        );
      } else if (this.skillingLps.length != 0) {
        this.navigateAcrossLP(
          'skilling',
          this.skillingLps[0].PathId,
          this.skillingLps[0]
        );
        this.skillPathsPanel.open();
      } else if (this.userCreatedLps.length != 0) {
        this.navigateAcrossLP(
          'self',
          this.userCreatedLps[0].PathId,
          this.userCreatedLps[0]
        );
      }
    }
  }
  openLPNavBar() {
    if (this.LPBreadcrumbs != undefined) {
      if (
        this.LPBreadcrumbs.CourseDetails.CourseId != null &&
        this.mediaBreakPoint != 'xs'
      ) {
        this.LPnavbar.close();
      } else {
        this.LPnavbar.open();
        if (this.LPBreadcrumbs.LPDetails.LPCategory == 'skilling') {
          if (this.skillPathsPanel) {
            this.skillPathsPanel.open();
          }
        }
      }
      this.LPPageSubscriptions.mediaChangeSubscription.unsubscribe();
    }
  }
  createNewLP() {
    this.createLpEditMode = true;
    setTimeout(() => {
      this.lpTextboxField.nativeElement.focus();
    }, 100);
    /*
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass = 'popupDialogContainer';
    dialogConfig.disableClose = true;
    this.dialog.open(CreateLpComponent,dialogConfig);
    */
  }
  createLPKeyEvent(event) {
    if (13 === event.keyCode) this.createLearningPath();
  }
  createLearningPath() {
    this.createNewLPInProgress = true;
    this.lpService
      .checkLpExistAndAdd(this.learningPathTitle, this.userCreatedLps)
      .then(result => {
        this.createLpEditMode = false;
        this.createNewLPInProgress = false;
        this.lpCreated = true;
        this.learningPathTitle = '';

        this.userDetailsStore.dispatch(
          new fromUserDetailsStore.UserDetailsAddLearningPath(result)
        );
        //  this.dialogRef.close();
        this.openSnackBar('Learning Path has been created successfully!');
        // this.addContentToLearningPath(result);
      })
      .catch(error => {
        this.learningPathTitle = '';
        this.createLpEditMode = false;
        this.createNewLPInProgress = false;
        this.lpCreated = false;
        this.openSnackBar(error.errorMessage);
      });
  }
  openSnackBar(message) {
    const config = new MatSnackBarConfig();
    config.duration = 5000;
    config.verticalPosition = 'top';
    config.horizontalPosition = 'end';
    // config.panelClass="custom-snackbar";
    this.snackBar.open(message, undefined, config);
  }
  deleteLP(lp) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass = 'popupDialogContainer';
    //dialogue-box-data
    dialogConfig.data = {};
    dialogConfig.data.title = lp.PathName;
    dialogConfig.disableClose = true;
    // let deleteDialogBox: MatDialogRef<any>;
    if (lp.PackageList.length === 0) {
      dialogConfig.data.message1 =
        'Are you sure you want to delete ' + lp.PathName + '?';
      dialogConfig.data.showButtons = true;
      // dialogConfig.width = '350px';
      // dialogConfig.height = '130px';
      let deleteDialogBox = this.dialog.open(
        ConfirmationDialogComponent,
        dialogConfig
      );
      deleteDialogBox.afterClosed().subscribe(data => {
        if (data) {
          this.lpService.deleteLearningPath(lp).then(response => {
            if (response) {
              this.userDetailsStore.dispatch(
                new fromUserDetailsStore.DeleteLearningPath(lp)
              );
              if(this.myComplianceLp.length != 0){
                this.navigateAcrossLP(
                  'myCompliance',
                  this.myComplianceLp[0].PathName.toUpperCase(),
                  this.myComplianceLp[0]
                );
              }
              else if (this.mandatoryLps.length != 0) {
                this.navigateAcrossLP(
                  'mandatory',
                  this.mandatoryLps[0].PathName,
                  this.mandatoryLps[0].PathName
                );
              } else if (this.skillingLps.length != 0) {
                this.navigateAcrossLP(
                  'skilling',
                  this.skillingLps[0].PathId,
                  this.skillingLps[0].PathName
                );
                this.skillPathsPanel.open();
              } else if (this.userCreatedLps.length != 0) {
                this.navigateAcrossLP(
                  'self',
                  this.userCreatedLps[0].PathId,
                  this.userCreatedLps[0].PathName
                );
              } else {
                this.lpService.updateBreadcrumbs(null, null, null, null, null);
                this.router.navigate(['learningpath']);
              }
            }
          });
        }
      });
    } else {
      this.canRemoveLP(lp).then((response: any) => {
        if (response.status) {
          // dialogConfig.height = '200px';
          // dialogConfig.width = '550px';
          dialogConfig.data.message1 =
            'There may be some course/package(s) in progress. Are you sure you want to delete ' +
            lp.PathName +
            '?';
          dialogConfig.data.message2 =
            'Your progress will be remembered by the system and will reflect if you chose to take this course again.';
          dialogConfig.data.showButtons = true;
        } else {
          dialogConfig.data.message1 =
            'This Learning Path has 201/301 course(s) in Progress/Approved/Completed state and hence cannot be deleted.';
          dialogConfig.data.message2 = null;
          dialogConfig.data.showButtons = false;
        }
        let deleteDialogBox = this.dialog.open(
          ConfirmationDialogComponent,
          dialogConfig
        );
        deleteDialogBox.afterClosed().subscribe(data => {
          if (data) {
            this.lpService.deleteLearningPath(lp).then(response => {
              if (response) {
                this.userDetailsStore.dispatch(
                  new fromUserDetailsStore.DeleteLearningPath(lp)
                );
                if(this.myComplianceLp.length != 0){
                  this.navigateAcrossLP(
                    'myCompliance',
                    this.myComplianceLp[0].PathName.toUpperCase(),
                    this.myComplianceLp[0]
                  );
                }
                else if (this.mandatoryLps.length != 0) {
                  this.navigateAcrossLP(
                    'mandatory',
                    this.mandatoryLps[0].PathName,
                    this.mandatoryLps[0].PathName
                  );
                } else if (this.skillingLps.length != 0) {
                  this.navigateAcrossLP(
                    'skilling',
                    this.skillingLps[0].PathId,
                    this.skillingLps[0].PathName
                  );
                  this.skillPathsPanel.open();
                } else if (this.userCreatedLps.length != 0) {
                  this.navigateAcrossLP(
                    'self',
                    this.userCreatedLps[0].PathId,
                    this.userCreatedLps[0].PathName
                  );
                } else {
                  this.lpService.updateBreadcrumbs(
                    null,
                    null,
                    null,
                    null,
                    null
                  );
                  this.router.navigate(['learningpath']);
                }
              }
            });
          }
        });
      });
    }
  }
  canRemoveLP(lp) {
    let promise = new Promise((resolve, reject) => {
      let lpHasWorkflowStartedCourses = false;
      let coursesListWith201and301 = lp.PackageList.filter(content => {
        return (
          !content.IsDeleted &&
          ('201' == content.ItemExpertise || '301' == content.ItemExpertise) &&
          !(content.WorflowStatus == null || content.WorflowStatus == '') &&
          content.ItemType.toLowerCase() == 'course'
        );
      });
      lpHasWorkflowStartedCourses = this.validateCoursesForWorkflowStatus(
        coursesListWith201and301
      );
      if (lpHasWorkflowStartedCourses) {
        //delete not possible
        resolve({ status: false, reason: '' });
      } else {
        let PackagesInLP = lp.PackageList.filter(content => {
          return (
            !content.IsDeleted &&
            (content.ItemType.toLowerCase() == 'package' ||
              content.ItemType.toLowerCase() == 'familypackage')
          );
        });
        if (PackagesInLP.length == 0) {
          //delete possible
          resolve({ status: true, reason: '' });
        } else {
          let noOfPackagesValidated = 0;
          let packageContains201InProgress = false;
          PackagesInLP.forEach(content => {
            this.userDetailsStore
              .select(
                fromUserDetailsStore.getCoursesInsidePackageById(content.ItemId)
              )
              .subscribe(coursesList => {
                if (coursesList == undefined) {
                  this.lpService
                    .loadCoursesInsidePackageToStore(
                      content.AssignedBy,
                      content.ItemId,
                      content.AccountId,
                      content.ProjectId
                    )
                    // .then(courses => {
                    //   packageContains201InProgress = this.validateCoursesForWorkflowStatus(
                    //     courses
                    //   );
                    //   noOfPackagesValidated++;
                    //   if (packageContains201InProgress) {
                    //     //delete not possible
                    //     resolve({ status: false, reason: '' });
                    //     return true;
                    //   } else {
                    //     if (noOfPackagesValidated == PackagesInLP.length) {
                    //       //delete possible
                    //       resolve({ status: true });
                    //       return true;
                    //     }
                    //   }
                    // });
                } else {
                  packageContains201InProgress = this.validateCoursesForWorkflowStatus(
                    coursesList
                  );
                  noOfPackagesValidated++;
                  if (packageContains201InProgress) {
                    //delete not possible
                    resolve({ status: false, reason: '' });
                    //return true;
                  } else {
                    if (noOfPackagesValidated == PackagesInLP.length) {
                      //delete possible
                      resolve({ status: true });
                      //return true;
                    }
                  }
                }
              });
          });
        }
      }
    });
    return promise;
  }
  validateCoursesForWorkflowStatus(courses) {
    let hasWorkflowStartedCourses = courses.some(content => {
      if (
        ('201' == content.ItemExpertise || '301' == content.ItemExpertise) &&
        !(content.WorflowStatus == null || content.WorflowStatus == '') &&
        content.ItemType.toLowerCase() == 'course'
      ) {
        content.WorflowStatus = content.WorflowStatus.toLowerCase();
        if (
          !(
            'request' == content.WorflowStatus ||
            'cancelled' == content.WorflowStatus ||
            'request cancelled' == content.WorflowStatus ||
            'rejected' == content.WorflowStatus ||
            'preapproved' == content.WorflowStatus ||
            'pre-approved' == content.WorflowStatus ||
            'send request' == content.WorflowStatus ||
            'not started' == content.WorflowStatus
          )
        ) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    });
    return hasWorkflowStartedCourses;
  }
  resumeLearningPath() {
    if (this.resumeDetails && this.resumeDetails != null) {
      //get path category

      if (
        this.resumeDetails.ItemId == '' ||
        this.resumeDetails.ItemId == 'null'
      ) {
        this.resumeDetails.ItemId = null;
      }

      this.lpService.updateResumeStatus(true);
      let category = 'self';
      let lpId = this.resumeDetails.PathId;
      this.userDetailsStore
        .select(fromUserDetailsStore.getLearningPathsSelector)
        .subscribe(lps => {
          let lp = this.arrayFilterPipe.transform(lps, {
            property: 'PathId',
            flag: this.resumeDetails.PathId
          })[0];

          if(lp.PathName.toLowerCase() == 'business ethics and compliance'){
            category = 'myCompliance';
            lpId = lp.PathName;
          }
          else if (lp.IsMandatory && lp.IsSkillPlan) {
            category = 'skilling';
          } else if (lp.IsMandatory && !lp.IsSkillPlan) {
            category = 'mandatory';
            lpId = lp.PathName;
          } else {
            category = 'self';
          }
          console.log('lp', lp);
        });
      let packageId = null;
      if (this.resumeDetails.ItemType == 'FamilyPackage') {
        packageId = this.resumeDetails.ItemId;
      } else {
        packageId = null;
      }
      this.router.navigate(
        [
          'category/' +
          category +
          '/id/' +
          lpId +
          '/package/' +
          packageId +
          '/course/' +
          this.resumeDetails.CourseId +
          '/account/false/project/false/accountId/null/projectId/null/tabs/playlist'
        ],
        {
          relativeTo: this.activatedRoute
        }
      );
    }
  }

  openDialog() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.panelClass = 'popupDialogContainer';
    //courseFeedbackDialogContainer
    this._dialog.open(CourseFeedbackComponent, dialogConfig);
  }

  checkFeedback() {
    if (!this.globals.isCustomerAccess) {
      this._popUpSvc.isCourseFeedbackPending().then(res => {
        if (res === true) {
          this._popUpSvc.getPendingCourseFeedBackList().subscribe(
            data => {
              if (data !== null && data.length > 0) {
                let mandatoryList = this.arrayFilterPipe.transform(data, {
                  property: 'IsFeedbackMandatory',
                  flag: true
                });
                if (mandatoryList.length != 0) {
                  this.globals.courseFeedbackList = data;
                  this.openDialog();
                }
              }
            },
            error => {
              console.log('Error in getting Course feedback', error);
            }
          );
        } else {
          //do nothing
        }
      });

    }
  }
}
