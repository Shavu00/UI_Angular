import { Injectable } from '@angular/core';
import {
  Ienvironment,
  EnvironmentService
} from '@YorbitWorkspace/global-environments';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CloudLabService {
  _baseURL: string;

  constructor(private _http: HttpClient, private _envSvc: EnvironmentService) {
    this._baseURL = this._envSvc.getEnvironment().apiUrl;
  }

  getCloudLabDetails(courseId) {
    return this._http.get<any>(
      this._baseURL + 'Course/GetLabRequest/' + courseId + '/lab'
    );
  }

  requestCloudLabAccess(payload) {
    return this._http.post<any>(
      this._baseURL +
        'Course/UpdateRequest/' +
        payload.CourseId +
        '/' +
        payload.CloudLabUniqueId +
        '/lab',
      {}
    );
  }
}
