import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CloudLabComponent } from './cloud-lab.component';

describe('CloudLabComponent', () => {
  let component: CloudLabComponent;
  let fixture: ComponentFixture<CloudLabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CloudLabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CloudLabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
