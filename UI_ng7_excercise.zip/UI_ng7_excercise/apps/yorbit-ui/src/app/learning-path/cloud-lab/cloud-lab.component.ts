import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { CloudLabService } from './cloud-lab.service';
import { LearningPathService } from '../learning-path.service';
import { LPBreadcrumbsStateModel } from '../learning-path-breadcrumbs.model';
import { ILPBreadcrumbs } from '../learning-path-breadcrumbs.interface';
import { Subscriber } from 'rxjs';
import { Router } from '@angular/router';
@Component({
  selector: 'yorbit-cloud-lab',
  templateUrl: './cloud-lab.component.html',
  styleUrls: ['./cloud-lab.component.scss']
})
export class CloudLabComponent implements OnInit, OnDestroy {
  LPBreadcrumbs: ILPBreadcrumbs;
  getLabDetailsInput: any;
  courseId: any;
  courseExpertise: any;
  cloudLabDetails: Array<any>;
  disableCloudLabRequestButton: Array<boolean>;
  statusMessage: Array<string>;
  getRequestProcessing: boolean;
  getRequestError: boolean;
  cloudLabCompSubscriptions: any;

  requestCloudAccessProcessing: Array<boolean>;
  requestCloudAccessError: Array<boolean>;
  //@Input('courseDetails') courseDetails:any;

  constructor(
    private _cloudSvc: CloudLabService,
    private _lpSvc: LearningPathService,
    private _router: Router
  ) {}

  ngOnInit() {
    this.cloudLabCompSubscriptions = {};
    this.subscribeToBreadcrumbs();

    // this.getCourseCloudLabDetails(unit1);
  }
  ngOnDestroy() {
    this.unsubscribeAllSubscriptions();
  }
  getCourseCloudLabDetails(unit) {
    // added to recall the get api after the request cloud lab action is done
    this.getLabDetailsInput = unit;
    this.courseId = null;
    this.courseExpertise = null;
    this.cloudLabDetails = new Array();
    this.disableCloudLabRequestButton = new Array();
    this.statusMessage = new Array();

    //Get Cloud lab details for courses only
    if (unit.ItemType.toLowerCase() === 'course') {
      this.getRequestProcessing = true;
      this.getRequestError = false;
      // Set courseId to UniqueId for Project & Account Courses, courseId to ItemId for Yorbit Courses
      this.courseExpertise = unit.ItemExpertise;
      // if (unit.AccountPackage || unit.ProjectPackage) {
      //   this.courseId = unit.UniqueId;
      // } else {
      this.courseId = unit.ItemId;
      // }
      //Call the Course/Get/{CourseId}/lab api
      //Input : courseId
      //Output : List of objects which has the Cloud lab details
      //Method : GET
      if (this.courseId != null) {
        this._cloudSvc.getCloudLabDetails(this.courseId).subscribe(
          response => {
            this.getRequestProcessing = false;
            this.cloudLabDetails = response;
            if (this.cloudLabDetails != null) {
              this.requestCloudAccessProcessing = new Array(
                this.cloudLabDetails.length
              );
              this.requestCloudAccessError = new Array(
                this.cloudLabDetails.length
              );
            }
            const _101Message =
              'Previously requested 101 Course should be completed';
            const _201Message =
              'Previously requested 201 Course should be completed';
            const _301Message =
              'Previously requested 301 Course should be completed';
            const _201NotApprovedMessage =
              'Only Approved 201 courses be allowed to Request for Cloudlab Access';
            const _301NotApprovedMessage =
              'Only Approved 301 courses be allowed to Request for Cloudlab Access';

            response.forEach((value, key) => {
              this.statusMessage[key] = value.statusMessage;
              if (value.cloudLabDetails != null) {
                switch (this.courseExpertise) {
                  case '101':
                    const status101 = value.cloudLabDetails.AccessStatus;
                    if (
                      status101 === '' &&
                      _101Message.toLowerCase() ===
                        value.statusMessage.toLowerCase()
                    ) {
                      this.disableCloudLabRequestButton[key] = true;
                    } else {
                      this.disableCloudLabRequestButton[key] = false;
                    }
                    break;
                  case '201':
                    const status201 = value.cloudLabDetails.AccessStatus;
                    if (
                      status201 === '' &&
                      _201Message.toLowerCase() ===
                        value.statusMessage.toLowerCase()
                    ) {
                      this.disableCloudLabRequestButton[key] = true;
                    } else if (
                      status201.toLowerCase() === 'not yet approved' &&
                      _201NotApprovedMessage.toLowerCase() ===
                        value.statusMessage.toLowerCase()
                    ) {
                      this.disableCloudLabRequestButton[key] = true;
                    } else {
                      this.disableCloudLabRequestButton[key] = false;
                    }
                    break;
                  case '301':
                    const status301 = value.cloudLabDetails.AccessStatus;
                    if (
                      status301 === '' &&
                      _301Message.toLowerCase() ===
                        value.statusMessage.toLowerCase()
                    ) {
                      this.disableCloudLabRequestButton[key] = true;
                    } else if (
                      status301.toLowerCase() === 'not yet approved' &&
                      _301NotApprovedMessage.toLowerCase() ===
                        value.statusMessage.toLowerCase()
                    ) {
                      this.disableCloudLabRequestButton[key] = true;
                    } else {
                      this.disableCloudLabRequestButton[key] = false;
                    }
                    break;
                  default:
                    this.disableCloudLabRequestButton[key] = false;
                }
              }
            });
          },
          error => {
            this.getRequestProcessing = false;
            if (error.status === '403') {
              //this.cloudLabDetails[0] = error.data.cloudLabDetails;
              this.cloudLabDetails[0] = { cloudLabDetails: null };
            } else {
              this.getRequestError = true;
            }
          }
        );
      }
    }
  }

  requestCloudLabAccess(cloud, index) {
    const payload = {
      CourseId: cloud.CourseId,
      CloudLabUniqueId: cloud.CloudLabUniqueId
    };
    this.requestCloudAccessProcessing[index] = true;
    this.requestCloudAccessError[index] = false;
    //Call the Course/UpdateRequest/lab api
    //Input : payload
    //Output : an object with a string true/false
    //true => requested successfully. false => request not created
    //Method : POST
    this._cloudSvc.requestCloudLabAccess(payload).subscribe(
      response => {
        if (response.toLowerCase() === 'success') {
          this.requestCloudAccessProcessing[index] = false;
          this.cloudLabDetails[index].cloudLabDetails.AccessStatus =
            'Access Requested';
          //need to update the lab details
          this.getCourseCloudLabDetails(this.getLabDetailsInput);
        }
      },
      error => {
        this.requestCloudAccessProcessing[index] = false;
        this.requestCloudAccessError[index] = true;
      }
    );
  }

  disableOtherCloudLabReqButtons() {
    //disables other cloud lab request buttons when a request is get processed.
    if (this.cloudLabDetails != null) {
      for (let count = 0; count <= this.cloudLabDetails.length; count++) {
        if (this.requestCloudAccessProcessing[count]) {
          return true;
        }
      }
      return false;
    } else {
      return false;
    }
  }

  subscribeToBreadcrumbs() {
    this.cloudLabCompSubscriptions.breadcrumbsSubscription = this._lpSvc
      .getBreadCrumbs()
      .subscribe(breadcrumbs => {
        this.LPBreadcrumbs = breadcrumbs;
        if (this.LPBreadcrumbs.CourseDetails.CourseId !== null) {
          if (
            this.cloudLabCompSubscriptions.breadcrumbsSubscription !== undefined
          ) {
            this.cloudLabCompSubscriptions.breadcrumbsSubscription.unsubscribe();
          } else {
            const unit = {
              ItemType: 'Course',
              ItemExpertise: this.LPBreadcrumbs.CourseDetails.Expertise,
              AccountPackage: this.LPBreadcrumbs.CourseDetails.IsAccount,
              ProjectPackage: this.LPBreadcrumbs.CourseDetails.IsProject,
              ItemId: this.LPBreadcrumbs.CourseDetails.CourseId
            };
            this.getCourseCloudLabDetails(unit);
          }
        }
      });
  }
  unsubscribeAllSubscriptions() {
    for (const subscriberKey in this.cloudLabCompSubscriptions) {
      if (this.cloudLabCompSubscriptions[subscriberKey] instanceof Subscriber) {
        this.cloudLabCompSubscriptions[subscriberKey].unsubscribe();
      }
    }
  }

  goToCloudHelp() {
    this._router.navigate(['/info/faq/Cloud Lab']);
  }
}
