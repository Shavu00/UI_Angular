import { TestBed, inject } from '@angular/core/testing';

import { CloudLabService } from './cloud-lab.service';

describe('CloudLabService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CloudLabService]
    });
  });

  it('should be created', inject([CloudLabService], (service: CloudLabService) => {
    expect(service).toBeTruthy();
  }));
});
