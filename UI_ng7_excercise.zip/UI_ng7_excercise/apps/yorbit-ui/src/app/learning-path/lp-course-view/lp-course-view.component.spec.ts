import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LPCourseViewComponent } from './lp-course-view.component';

describe('LPCourseViewComponent', () => {
  let component: LPCourseViewComponent;
  let fixture: ComponentFixture<LPCourseViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LPCourseViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LPCourseViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
