import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LpCourseDescriptionComponent } from './lp-course-description.component';

describe('LpCourseDescriptionComponent', () => {
  let component: LpCourseDescriptionComponent;
  let fixture: ComponentFixture<LpCourseDescriptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LpCourseDescriptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LpCourseDescriptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
