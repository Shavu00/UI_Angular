﻿import { Component, OnInit, OnDestroy } from '@angular/core';
import { MediaChange, MediaObserver } from '@angular/flex-layout';
import { DatePipe } from '@angular/common';

import {
  Router,
  ActivatedRoute,
  ParamMap,
  NavigationEnd,
  NavigationStart
} from '@angular/router';
import { LearningPathService } from '../learning-path.service';
import * as fromUserDetailsStore from '../../shared/user-details/store';
import {
  LearningPath,
  PackageList,
  Badge
} from '../../shared/user-details/store/user-details.interface';
import { Store } from '@ngrx/store';
import {
  LPBreadcrumbsStateModel,
  ICourseDetailsModel,
  IPackageDetailsModel,
  IVideoDetailsModel,
  IUnitDetailsModel
} from '../learning-path-breadcrumbs.model';
import { ILPBreadcrumbs } from '../learning-path-breadcrumbs.interface';
import { ArrayPropertyFilterPipe } from '@YorbitWorkspace/pipes';
import { Subscriber } from 'rxjs';
import { PlaylistService } from '../../shared/playlist/playlist.service';
import { Globals } from '../../globals';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { LinkifyPipe } from '@YorbitWorkspace/pipes';
import { filter } from 'rxjs/operators';
import { DeclarePopupService } from '../../shared/content-tiles/declare-popup/declare-popup.service';
@Component({
  selector: 'yorbit-lp-course-view',
  templateUrl: './lp-course-view.component.html',
  styleUrls: ['./lp-course-view.component.scss']
})
export class LPCourseViewComponent implements OnInit, OnDestroy {
  LPBreadcrumbs: ILPBreadcrumbs;
  courseDetails: any;
  LPCourseCompSubscriptions: any;
  badgeImage: string;
  quizScore: number | string;
  badge: Badge;
  filterPipe = new ArrayPropertyFilterPipe();
  tabsList: Array<any>;
  resumeLP: boolean;
  newAray: Array<any>;
  canPlayAll: boolean;
  recommendedCourses: any;
  recommendationsNotAvailable: boolean;
  quizDetails: any;
  courseProgress: any;
  quizNotAvailable: boolean;
  quizCheckInProgress: boolean;
  courseListForShowingLastCompletedDate: Array<string>;
  pageLoadedSuccessfully: boolean;
  pageLoading: boolean;
  isAccountRelated: boolean;
  courseAvailable: boolean;
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private mediaObserver: MediaObserver,
    private lpService: LearningPathService,
    private userDetailsStore: Store<fromUserDetailsStore.IuserDetailsState>,
    private playlistService: PlaylistService,
    private globals: Globals,
    private dialog: MatDialog,
    private declarePopupService:DeclarePopupService
  ) {
    this.pageLoading = true;
    this.pageLoadedSuccessfully = false;
    this.LPCourseCompSubscriptions = {};
    //this.tabsList = ['playlist', 'cloud', 'yammer'];
    this.tabsList = ['playlist', 'cloud'];
    this.subscribeMediaChanges();
    this.subscribeToResumeStatus();
    this.resumeLP = false;
    this.newAray = new Array(5);
    this.badge = {
      BadgeId: 0,
      BadgeImage: null,
      BadgeName: '',
      CompletedDate: '0001-01-01T00:00:00',
      CourseId: null,
      IsExternalCertificate: false,
      IsFeedbackMandatory: false,
      IsFeedbackSet: false,
      IsRetakeMandatory: false,
      Score: 0,
      Status: null,
      UniqueId: '',
      isMigrated: false
    };
    this.recommendedCourses = [];
    this.recommendationsNotAvailable = false;
    this.quizDetails = {};
    this.courseProgress = {};
    this.quizNotAvailable = false;
    this.quizCheckInProgress = false;
    this.isAccountRelated = false;
    this.courseListForShowingLastCompletedDate = this.globals.courseListForShowingLastCompletedDate;
    this.courseAvailable = false;
  }
  subscribeMediaChanges() {
    this.LPCourseCompSubscriptions.mediaChangeSubscription = this.mediaObserver.media$.subscribe(
      (media: MediaChange) => {
        //add this.router.url=='/learningpath' check in the below if condition for xs
        // if (
        //   media.mqAlias === 'xs' ||
        //   media.mqAlias === 'sm' ||
        //   media.mqAlias === 'md'
        // ) {
        //   if (this.tabsList.indexOf('yammer') === -1) {
        //     this.tabsList.push('yammer');
        //   }
        // } else {
        //   if (this.tabsList.indexOf('yammer') !== -1) {
        //     this.tabsList.splice(this.tabsList.indexOf('yammer'), 1);
        //   }
        // }
      }
    );
  }
  ngOnInit() {
    this.subscribeToRouterEvents();
  }
  ngOnDestroy() {
    this.unsubscribeAllSubscriptions();
  }
  subscribeToBreadcrumbs() {
    this.LPCourseCompSubscriptions.breadcrumbsSubscription = this.lpService
      .getBreadCrumbs()
      .subscribe(breadcrumbs => {
        this.LPBreadcrumbs = breadcrumbs;
        //remove below call once external course playlist tab view is implemented
        if (this.LPBreadcrumbs.CourseDetails.CourseId != null) {
          if (
            !this.LPBreadcrumbs.CourseDetails.IsInternal ||
            this.LPBreadcrumbs.CourseDetails.Expertise == '301' ||
            this.LPBreadcrumbs.CourseDetails.IsAccount ||
            this.LPBreadcrumbs.CourseDetails.IsProject
          ) {
            //remove tabslist setting to cloud alone when playlist for external course is implemented
            this.navigateToExternalCourseView();
          }
        }
      });
  }
  subscribeToRouterEvents() {
    this.LPCourseCompSubscriptions.routeParamsSubscriptions = this.activatedRoute.params.subscribe(
      params => {
        let payload = null;
        this.isAccountRelated = false;
        if (
          params['accountPackage'] === 'true' ||
          params['projectPackage'] === 'true'
        ) {
          this.isAccountRelated = true;
          payload = {
            AccountId: params['accountId'],
            AccountPackage: params['accountPackage'],
            ItemId: params['courseId'],
            ProjectId: params['projectId'],
            ProjectPackage: params['projectPackage']
          };
        }
        this.getQuizDetails(params['courseId']);
        this.getRecommendedCourses(params['courseId']);
        this.lpService
          .getCourseDetails(
            params['courseId'],
            'Course',
            this.isAccountRelated,
            payload
          )
          .then((data: any) => {
            if (data != null) {
              this.subscribeToBreadcrumbs();
              if (data.IsHidden) {
                this.userDetailsStore
                  .select(
                    fromUserDetailsStore.getCourseProgressEntitiesByIdSelector(
                      params['courseId']
                    )
                  )
                  .subscribe(course => {
                    if (course.Expertise == '101') {
                      this.userDetailsStore
                        .select(
                          fromUserDetailsStore.getBadgesByCourseIdSelector(
                            params['courseId']
                          )
                        )
                        .subscribe(badge => {
                          if (
                            badge.Status === 'true' ||
                            parseInt(course.Progress) > 0
                          ) {
                            this.courseAvailable = true;
                          }
                        });
                    } else {
                      if (course.WorflowStatus != null) {
                        course.WorflowStatus = course.WorflowStatus.toLowerCase();
                      }
                      else {
                        course.WorflowStatus = '';
                      }
                      if (
                        !(
                          '' == course.WorflowStatus ||
                          'request' == course.WorflowStatus ||
                          'cancelled' == course.WorflowStatus ||
                          'request cancelled' == course.WorflowStatus ||
                          'rejected' == course.WorflowStatus ||
                          'preapproved' == course.WorflowStatus ||
                          'pre-approved' == course.WorflowStatus ||
                          'send request' == course.WorflowStatus ||
                          'not started' == course.WorflowStatus
                        )
                      ) {
                        this.courseAvailable = true;
                      }
                    }
                  });
              } else {
                this.courseAvailable = true;
              }
              if (this.courseAvailable) {
                this.courseDetails = data;
                this.lpService.storeCourseDetails(this.courseDetails);
                this.pageLoadedSuccessfully = true;
                this.pageLoading = false;
                //update breadcrumbs
                this.userDetailsStore
                  .select(fromUserDetailsStore.getLearningPathListEntities)
                  .subscribe(res => {
                    let packageEntity = null;
                    if (res[params['lpId'].toUpperCase()] !== undefined) {
                      const learningPath = res[params['lpId'].toUpperCase()];
                      if (
                        params['packageId'] !== 'null' &&
                        params['packageId'] != null
                      ) {
                        let packages = this.filterPipe.transform(
                          learningPath.PackageList,
                          {
                            property: 'ItemType',
                            flag: 'Package'
                          }
                        );
                        let familyPackages = this.filterPipe.transform(
                          learningPath.PackageList,
                          {
                            property: 'ItemType',
                            flag: 'FamilyPackage'
                          }
                        );
                        let allPackageEntitiesInLP = packages.concat(familyPackages);
                        let undeletedEntities = this.filterPipe.transform(
                          allPackageEntitiesInLP,
                          {
                            property: 'IsDeleted',
                            flag: false
                          }
                        );
                        packageEntity = this.filterPipe.transform(
                          undeletedEntities,
                          {
                            property: 'ItemId',
                            flag: params['packageId']
                          }
                        )[0];
                        this.lpService.updateBreadcrumbs(
                          learningPath,
                          packageEntity,
                          this.courseDetails,
                          null,
                          null
                        );
                      } else {
                        this.lpService.updateBreadcrumbs(
                          learningPath,
                          null,
                          this.courseDetails,
                          null,
                          null
                        );
                      }
                    }
                  });
              } else {
                this.pageLoadedSuccessfully = true;
                this.pageLoading = false;
              }
            } else {
              this.pageLoadedSuccessfully = false;
              this.pageLoading = false;
            }
          });
      },
      error => {
        this.pageLoadedSuccessfully = false;
        this.pageLoading = false;
      }
    );
  }
  getQuizDetails(courseId) {
    this.userDetailsStore
      .select(fromUserDetailsStore.getBadgesByCourseIdSelector(courseId))
      .subscribe(badge => {
        //console.log("badges",badge);
        if (badge.BadgeId) {
          this.badge = { ...badge };
        }
      });
    this.userDetailsStore
      .select(
        fromUserDetailsStore.getCourseProgressEntitiesByIdSelector(courseId)
      )
      .subscribe(course => {
        if (course && course.CourseId) {
          course.Progress = parseInt(course.Progress);
          this.courseProgress = { ...course };
          if (this.courseProgress.Expertise != '101') {
            const isDeclared=this.declarePopupService.declareBadge(this.badge.BadgeImage)
            if (
             ( this.courseProgress.WorflowStatus.toLowerCase() ==
              'course completed' && !this.badge.IsRetakeMandatory)||isDeclared
            ) {
              this.badge.Status = 'true';
            } else {
              this.badge.Status = 'false';
            }
          }
        }
      });
    this.userDetailsStore
      .select(fromUserDetailsStore.getQuizByCourseIdSelector(courseId))
      .subscribe(quiz => {
        if (quiz && quiz.EntityId) {
          this.quizDetails = { ...quiz };

          if (this.courseProgress.Expertise === '101') {
            const isDeclared=this.declarePopupService.declareBadge(this.badge.BadgeImage)
            if(isDeclared&&this.quizDetails.HasPassed)
            this.badge.BadgeImage=this.declarePopupService.acquiredBadge.skill
          }
        } else {
          this.quizDetails.QuizId = null;
        }
      });
  }
  getRecommendedCourses(id) {
    this.lpService
      .getRecommendationDetails(id)
      .then(response => {
        if (response != null && response !== undefined && response.length > 0) {
          let filteredArray = response.filter(data => {
            if (data.IsHidden) {
              return false;
            } else {
              return true;
            }
          });
          this.recommendedCourses = filteredArray;
          if (this.recommendedCourses.length == 0) {
            this.recommendationsNotAvailable = true;
          }
        } else {
          this.recommendationsNotAvailable = true;
        }
      })
      .catch(err => { });
  }
  subscribeToResumeStatus() {
    this.lpService.getResumeStatus().subscribe(status => {
      this.resumeLP = status;
    });
  }
  unsubscribeAllSubscriptions() {
    for (let subscriberKey in this.LPCourseCompSubscriptions) {
      let subscriber = this.LPCourseCompSubscriptions[subscriberKey];
      if (subscriber instanceof Subscriber) {
        subscriber.unsubscribe();
      }
    }
  }

  navigateToExternalCourseView() {
    this.router.navigate(['type/external'], {
      relativeTo: this.activatedRoute
    });
  }

  startQuiz() {
    this.userDetailsStore
    .select(
      fromUserDetailsStore.getCourseProgressEntitiesByIdSelector(this.courseDetails.Id)
    )
    .subscribe(course => {
      if (course && course.CourseId) {
        course.Progress = parseInt(course.Progress);
        this.courseProgress = { ...course };
      }
    });
    if(this.courseProgress.Progress){
    this.courseProgress.Progress = parseInt(this.courseProgress.Progress);
    }
    if (
      this.quizDetails.ShowProgress &&
      !this.quizDetails.RetakeQuiz &&
      !this.quizDetails.HasPassed &&
      this.courseProgress.Progress < 50
    ) {
      const dialogConfig = new MatDialogConfig();
      (dialogConfig.panelClass = 'popupDialogContainer'),
        (dialogConfig.disableClose = true),
        (dialogConfig.data = {});
      dialogConfig.data.message1 =
        this.courseProgress.Progress + '% content viewed.';
      dialogConfig.data.message2 =
        'Watch at least <span style="font-weight:bold;color:#fff">50%</span> of the videos to retake the quiz.';
      dialogConfig.data.showButtons = false;
      dialogConfig.data.title = this.LPBreadcrumbs.CourseDetails.CourseName;
      this.dialog.open(ConfirmationDialogComponent, dialogConfig);
    } else {
      this.router.navigate([
        'quiz/',
        this.LPBreadcrumbs.CourseDetails.CourseId,
        this.LPBreadcrumbs.LPDetails.LPId,
        this.LPBreadcrumbs.LPDetails.LPCategory
      ]);
    }
  }
  goBackToLP() {
    this.router.navigate([
      'learningpath/category/' +
      this.LPBreadcrumbs.LPDetails.LPCategory +
      '/id/' +
      this.LPBreadcrumbs.LPDetails.LPId
    ]);
  }
  checkQuizAvailability() {
    let courseDetails = {
      IsAccount: this.LPBreadcrumbs.CourseDetails.IsAccount,
      IsProject: this.LPBreadcrumbs.CourseDetails.IsProject,
      AccountId: this.LPBreadcrumbs.CourseDetails.AccountId,
      ProjectId: this.LPBreadcrumbs.CourseDetails.ProjectId,
      entityType: 'course',
      courseId: this.LPBreadcrumbs.CourseDetails.CourseId
    };
    this.quizCheckInProgress = true;
    this.lpService
      .quizAvailabilityCheck(courseDetails)
      .then((response: any) => {
        if (response != null) {
          this.quizDetails = response;
          this.quizCheckInProgress = false;
          this.quizNotAvailable = false;
          this.userDetailsStore.dispatch(
            new fromUserDetailsStore.AddQuizDetails(response)
          );
        } else {
          this.quizCheckInProgress = false;
          this.quizNotAvailable = true;
          setTimeout(()=>{this.quizNotAvailable = false},5000);
        }
      })
      .catch(function () {
        this.quizCheckInProgress = false;
        this.quizNotAvailable = true;
        setTimeout(()=>{this.quizNotAvailable = false},5000);
      });
  }
  isDateValid(date) {
    const result = new Date(date);
    if (result.getFullYear() == 1) {
      return false;
    } else {
      return true;
      //  return this.datePipe.transform(date,'dd/MM/yyyy');
    }
  }

  getTime(date, format) {
    const result = new Date(date);
    return new DatePipe('en-US').transform(result, format);
  }

  isMandateCourse(courseId) {
    if (courseId != undefined) {
      const id = courseId.toString();
      if (this.courseListForShowingLastCompletedDate.indexOf(id) !== -1) {
        return true;
      } else {
        return false;
      }
    }
  }

  disableMandatoryRetake(courseId){
    if(this.isMandateCourse(courseId)){
    if((this.globals.mandatoryLPProgress == '100' && this.globals.mandatoryLPProgress != null) && !this.badge.IsRetakeMandatory){
    return true;
    }
    else{
    return false;
    }
    }
    else{
    return false;
    }
    }
    getMandatoryQuizTooltip(){
      return 'This button will be enabled on ' + this.getTime(this.globals.mandatoryRetakeDate,'MMM d, y');
      }

}
