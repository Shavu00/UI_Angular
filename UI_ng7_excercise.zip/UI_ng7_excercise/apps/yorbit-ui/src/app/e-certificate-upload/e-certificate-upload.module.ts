import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { ECertificateUploadComponent } from './e-certificate-upload.component';
import { ECertificateUploadRoutingModule } from './e-certificate-upload.routing.module';
import { ECertificatePopupComponent } from "./e-certificate-popup/e-certificate-popup.component";
import { FlexLayoutModule } from '@angular/flex-layout';
import { DirectivesModule } from '@YorbitWorkspace/directives';
import { MatAutocompleteModule, MatInputModule, MatDatepickerModule, MatNativeDateModule, MatExpansionModule, MatDialogModule, MatButtonModule, MatIconModule } from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    ECertificateUploadRoutingModule,

    MatAutocompleteModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatExpansionModule,
    MatInputModule,
    MatAutocompleteModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    ReactiveFormsModule,
    FormsModule,
    FlexLayoutModule,
    DirectivesModule
  ],
  entryComponents: [ECertificatePopupComponent],
  declarations: [ECertificateUploadComponent, ECertificatePopupComponent]
})
export class ECertificateUploadModule {}
