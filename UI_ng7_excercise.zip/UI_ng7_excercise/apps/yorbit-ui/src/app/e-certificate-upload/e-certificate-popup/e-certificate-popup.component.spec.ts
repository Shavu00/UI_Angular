import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ECertificatePopupComponent } from './e-certificate-popup.component';

describe('ECertificatePopupComponent', () => {
  let component: ECertificatePopupComponent;
  let fixture: ComponentFixture<ECertificatePopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ECertificatePopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ECertificatePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
