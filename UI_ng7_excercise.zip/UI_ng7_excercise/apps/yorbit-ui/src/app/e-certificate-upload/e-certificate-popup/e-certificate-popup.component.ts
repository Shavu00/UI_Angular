import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ECertificateUploadComponent } from '../e-certificate-upload.component';
import { Router } from '@angular/router';

@Component({
  selector: 'yorbit-e-certificate-popup',
  templateUrl: './e-certificate-popup.component.html',
  styleUrls: ['./e-certificate-popup.component.scss']
})
export class ECertificatePopupComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<ECertificateUploadComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: any,
    private router: Router
  ) {}

  ngOnInit() {
    //console.log('external certificate pop up data', this.dialogData);
  }
  close(input) {
    this.dialogRef.close(input);
  }
  goToLp() {
    this.close('No');
    let url: string;
    if (this.dialogData.data.isMandatory) {
      url =
        'learningpath/category/' +
        'mandatory' +
        '/id/' +
        this.dialogData.data.lpName;
    } else {
      url =
        'learningpath/category/' + 'self' + '/id/' + this.dialogData.data.lpId;
    }
    setTimeout(() => {
      this.router.navigate([url]);
    }, 1000);
  }
}
