import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material';
import { FormControl } from '@angular/forms';
import { Observable, Subscriber } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import * as fromUserDetailsStore from '../shared/user-details/store';
import { Store } from '@ngrx/store';
import { ArrayPropertyFilterPipe } from '@YorbitWorkspace/pipes';
import { MediaChange, MediaObserver } from '@angular/flex-layout';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { ECertificatePopupComponent } from './e-certificate-popup/e-certificate-popup.component';
import { ECertificateUploadService } from './e-certificate-upload.service';
import { Globals } from '../globals';
interface Academy {
  Name: string;
}
interface Genre {
  Name: string;
}
interface Skill {
  Name: string;
}
@Component({
  selector: 'yorbit-e-certificate-upload',
  templateUrl: './e-certificate-upload.component.html',
  styleUrls: ['./e-certificate-upload.component.scss']
})
export class ECertificateUploadComponent implements OnInit, OnDestroy {
  panelOpenState: boolean;
  isTermsAndConditionRead: boolean;
  isAcademySelected: boolean;
  isGenreSelected: boolean;
  isSkillSelected: boolean;
  isCourseSelected: boolean;
  beforeJoiningCheckBox: boolean;
  selectedCertificationDate: any;
  selectedExpiryDate: any;
  courseLoaded: boolean;
  noExpDateCheckBox: boolean;
  eCertifcateUploadFile: any;
  uploadBtnTitle: string;
  mUploadBtnTitle: string;
  isCertificateDateSelected: boolean;
  isExpiryDateSelected: boolean;
  fileNotSelected: boolean;
  disableUploadButton: boolean;
  btnTitle: string;
  disableExpiryDate: boolean;
  uploadBtnClicked: boolean;
  minCertDate: Date;
  minExpDate: Date;
  listOfAcademy: Array<Academy>;
  selectedAcademy: Academy;
  listOfGenre: Array<Genre>;
  selectedGenre: Genre;
  listOfSkill: Array<Skill>;
  selectedSkill: Skill;
  listOfAllCourse: Array<any>;
  listOfCourse: any;
  selectedCourse: any;
  myControl = new FormControl();
  filteredCourse: Observable<any[]>;
  successfullyUploded: boolean;
  courseExist: boolean;
  courseScheduled: boolean;
  showMobileView: boolean;
  showDesktopView: boolean;
  arrayFilterPipe: any;
  eCertificateSubscription: any = {};
  constructor(
    private ecertificateService: ECertificateUploadService,
    private _popup: MatDialog,
    private mediaObserver: MediaObserver,
    private userDetailsStore: Store<fromUserDetailsStore.IuserDetailsState>,
    private globals: Globals,
    private router: Router
  ) {
    this.listOfAcademy = [];
    this.listOfGenre = [];
    this.listOfSkill = [];
    this.listOfAllCourse = [];
    this.listOfCourse = [];
    this.showMobileView = false;
    this.showDesktopView = false;
    this.subscribeMediaChanges();
    //initialize all the variables
    this.resetAllVariable();
    this.arrayFilterPipe = new ArrayPropertyFilterPipe();
  }

  ngOnInit() {
    //get courses
    this.getExternalCourses();
  }
  getExternalCourses() {
    this.ecertificateService.getExternalCourses().subscribe(courses => {
      //console.log('external course list', courses);
      this.listOfAllCourse = courses;
      //sort in alphabetic order
      this.listOfAllCourse.sort((a, b) => {
        const x = a.Name.toLowerCase();
        const y = b.Name.toLowerCase();
        if (x < y) {
          return -1;
        }
        if (x > y) {
          return 1;
        }
        return 0;
      });
      //filter course name
      this.filterCourseName();
      //get academy
      this.getAcademyList();
    });
  }
  subscribeMediaChanges() {
    this.mediaObserver.media$.subscribe((media: MediaChange) => {
      if (media.mqAlias === 'xs') {
        this.showMobileView = true;
        this.showDesktopView = false;
      } else if (media.mqAlias !== 'xs') {
        this.showDesktopView = true;
        this.showMobileView = false;
      }
    });
  }
  readTermsAndCondition() {
    this.uploadBtnClicked = false;
    this.validateAllCondition();
  }
  private filterCourseName() {
    this.filteredCourse = this.myControl.valueChanges.pipe(
      startWith<string | any>(''),
      map(value => (typeof value === 'string' ? value : value.Name)),
      map(Name => (Name ? this._filter(Name) : this.listOfAllCourse.slice()))
    );
  }
  displayFn(course?: any): string | undefined {
    return course ? course.Name : undefined;
  }
  private _filter(Name: string): any[] {
    const filterValue = Name.toLowerCase();
    return this.listOfAllCourse.filter(
      option => option.Name.toLowerCase().indexOf(filterValue) === 0
    );
  }
  searchedCourseName(course) {
    this.isAcademySelected = true;
    this.isGenreSelected = true;
    this.isSkillSelected = true;
    this.isCourseSelected = true;
    this.listOfAcademy = [];
    this.listOfGenre = [];
    this.listOfSkill = [];
    this.listOfCourse = [];
    const academy = {
      Name: course.Academy
    };
    this.listOfAcademy.push(academy);
    this.selectedAcademy = this.listOfAcademy[0];
    const genre = {
      Name: course.Genre
    };
    this.listOfGenre.push(genre);
    this.selectedGenre = this.listOfGenre[0];
    const skill = {
      Name: course.Skill
    };
    this.listOfSkill.push(skill);
    this.selectedSkill = this.listOfSkill[0];
    this.listOfCourse.push(course);
    this.selectedCourse = this.listOfCourse[0];
    this.uploadBtnClicked = false;
    this.validateAllCondition();
  }
  getAcademyList() {
    //filter academy
    this.listOfAllCourse.forEach(element => {
      const academy = {
        Name: element.Academy
      };
      this.listOfAcademy.push(academy);
    });
    //remove duplicate
    this.listOfAcademy = this.listOfAcademy.filter(
      data =>
        !this.listOfAcademy[data.Name] && (this.listOfAcademy[data.Name] = true)
    );
    const obj = {
      Name: 'Select the academy'
    };
    this.listOfAcademy.unshift(obj);
    this.selectedAcademy = this.listOfAcademy[0];
    //configure genres
    this.getGenreList();
    //configure skills
    this.getSkillList();
    //configure courses
    this.getCourseList();
  }
  getGenreList() {
    const obj = {
      Name: 'Select the genre'
    };
    this.listOfGenre.unshift(obj);
    this.selectedGenre = this.listOfGenre[0];
  }
  getSkillList() {
    const obj = {
      Name: 'Select the skill'
    };
    this.listOfSkill.unshift(obj);
    this.selectedSkill = this.listOfSkill[0];
  }
  getCourseList() {
    const obj = {
      Name: 'Select the course'
    };
    this.listOfCourse.unshift(obj);
    this.selectedCourse = this.listOfCourse[0];
  }
  academySelectedFunction() {
    this.isAcademySelected = true;
    this.isGenreSelected = false;
    this.isSkillSelected = false;
    this.isCourseSelected = false;
    this.listOfGenre = [];
    this.listOfSkill = [];
    this.listOfCourse = [];
    //configure genre, skill and course list
    this.getGenreList();
    this.getSkillList();
    this.getCourseList();
    //get genre list
    //filter genre
    this.listOfAllCourse.forEach(element => {
      if (element.Academy === this.selectedAcademy.Name) {
        const genre = {
          Name: element.Genre
        };
        this.listOfGenre.push(genre);
      }
    });
    //remove duplicate
    this.listOfGenre = this.listOfGenre.filter(
      data =>
        !this.listOfGenre[data.Name] && (this.listOfGenre[data.Name] = true)
    );
    this.uploadBtnClicked = false;
    this.validateAllCondition();
  }
  genreSelectedFunction() {
    this.isGenreSelected = true;
    this.isSkillSelected = false;
    this.isCourseSelected = false;
    this.listOfSkill = [];
    this.listOfCourse = [];
    //configure skill and course list
    this.getSkillList();
    this.getCourseList();
    //get skill list
    //filter skill
    this.listOfAllCourse.forEach(element => {
      if (element.Genre === this.selectedGenre.Name) {
        const skill = {
          Name: element.Skill
        };
        this.listOfSkill.push(skill);
      }
    });
    //remove duplicate
    this.listOfSkill = this.listOfSkill.filter(
      data =>
        !this.listOfSkill[data.Name] && (this.listOfSkill[data.Name] = true)
    );
    this.uploadBtnClicked = false;
    this.validateAllCondition();
  }
  skillSelectedFunction() {
    this.isSkillSelected = true;
    this.isCourseSelected = false;
    this.listOfCourse = [];
    //configure course list
    this.getCourseList();
    //get course list
    this.listOfAllCourse.forEach((element: any) => {
      if (element.Skill === this.selectedSkill.Name) {
        this.listOfCourse.push(element);
      }
    });
    this.uploadBtnClicked = false;
    this.validateAllCondition();
  }
  courseSelectedFunction() {
    this.isCourseSelected = true;
    this.uploadBtnClicked = false;
    this.validateAllCondition();
  }
  resetAllVariable() {
    this.isTermsAndConditionRead = false;
    this.isAcademySelected = false;
    this.isGenreSelected = false;
    this.isSkillSelected = false;
    this.isCourseSelected = false;
    this.beforeJoiningCheckBox = false;
    this.eCertifcateUploadFile = '';
    this.uploadBtnTitle = 'Upload';
    this.mUploadBtnTitle = 'Upload Certificate';
    this.disableUploadButton = true;
    this.btnTitle = 'Please enter all mandatory fields';
    this.disableExpiryDate = false;
    this.isCertificateDateSelected = false;
    this.isExpiryDateSelected = false;
    this.fileNotSelected = true;
    this.uploadBtnClicked = false;
    this.minCertDate = new Date();
    this.minExpDate = new Date();
    this.successfullyUploded = false;
    this.courseExist = false;
    this.courseScheduled = false;
  }
  certificateDateSelected(event: MatDatepickerInputEvent<Date>) {
    this.isCertificateDateSelected = true;
    this.selectedCertificationDate = event.value;
    this.uploadBtnClicked = false;
    this.validateAllCondition();
  }
  expiryDateSelected(event: MatDatepickerInputEvent<Date>) {
    this.isExpiryDateSelected = true;
    this.selectedExpiryDate = event.value;
    this.uploadBtnClicked = false;
    this.validateAllCondition();
  }
  disableExpDateOrCheckBoxFunction() {
    if (this.noExpDateCheckBox) {
      this.isExpiryDateSelected = true;
      this.disableExpiryDate = true;
      this.selectedExpiryDate = '';
    } else {
      this.isExpiryDateSelected = false;
      this.disableExpiryDate = false;
    }
    this.uploadBtnClicked = false;
    this.validateAllCondition();
  }
  setDefaultValuesForUploads() {}
  fileModel(event) {
    this.fileNotSelected = false;
    this.eCertifcateUploadFile = event.file;
    this.uploadBtnClicked = false;
    this.validateAllCondition();
  }
  goToFAQ() {
    //navigate to footer faqs
    this.router.navigate(['info/faq/Certificate Upload']);
  }
  uploadFile() {
    this.uploadBtnClicked = true;
    if (this.noExpDateCheckBox === undefined) {
      this.noExpDateCheckBox = false;
    }
    this.validateAllCondition();
  }
  validateAllCondition() {
    if (this.fileNotSelected) {
      this.btnTitle = 'Please select a file';
    } else {
      const uploadedFileSize = this.eCertifcateUploadFile.size / (1024 * 1024);
      if (
        this.eCertifcateUploadFile.type === 'application/pdf' ||
        this.eCertifcateUploadFile.type === 'image/jpeg' ||
        this.eCertifcateUploadFile.type === 'application/x-zip-compressed'
      ) {
        if (uploadedFileSize < 10) {
          this.fileNotSelected = false;
          this.btnTitle = 'Click to upload certificate.';
        } else {
          this.fileNotSelected = true;
          this.btnTitle = 'Please choose file less than 10MB !';
        }
      } else {
        this.fileNotSelected = true;
        this.btnTitle = 'Please choose only pdf/jpg/jpeg/zip file !';
      }
    }
    if (!this.isTermsAndConditionRead) {
      this.btnTitle =
        'Please read all the terms given above and check the check box';
    }
    if (!this.isAcademySelected) {
      this.btnTitle = 'Please select academy';
    }
    if (!this.isGenreSelected) {
      this.btnTitle = 'Please select genre';
    }
    if (!this.isSkillSelected) {
      this.btnTitle = 'Please select skill';
    }
    if (!this.isCourseSelected) {
      this.btnTitle = 'Please select course';
    }
    if (!this.isCertificateDateSelected) {
      this.btnTitle = 'Please enter certification date';
    }
    if (!this.isExpiryDateSelected) {
      this.btnTitle = 'Please enter expiry date';
    }
    if (
      this.isTermsAndConditionRead &&
      this.isAcademySelected &&
      this.isGenreSelected &&
      this.isSkillSelected &&
      this.isCourseSelected &&
      this.isCertificateDateSelected &&
      this.isExpiryDateSelected &&
      !this.fileNotSelected
    ) {
      this.btnTitle = 'Click to upload certificate';
      this.disableUploadButton = false;
      if (this.uploadBtnClicked) {
        this.checkForCourseInLP();
      }
    } else {
      this.disableUploadButton = true;
    }
  }
  checkForCourseInLP() {
    //console.log('selectedCourseId', this.selectedCourse.Id);
    const matchedCourseList = [];
    let matchedLp: any = {};
    this.eCertificateSubscription.lpSubscription = this.userDetailsStore
      .select(fromUserDetailsStore.getUnDeletedLPsSelector)
      .subscribe(lps => {
        //console.log(lps);
        if (lps && lps.length !== 0) {
          lps.some(lp => {
            const activeContents = this.arrayFilterPipe.transform(
              lp.PackageList,
              {
                property: 'IsDeleted',
                flag: false
              }
            );
            const contentListOfSameItemTypes = this.arrayFilterPipe.transform(
              activeContents,
              {
                property: 'ItemType',
                flag: 'Course'
              }
            );
            const course = this.arrayFilterPipe.transform(
              contentListOfSameItemTypes,
              {
                property: 'ItemId',
                flag: this.selectedCourse.Id.toString()
              }
            );
            if (course.length !== 0) {
              //console.log('lp details',lp);
              //console.log('course details', course);
              matchedCourseList.push(course[0]);
              matchedLp = lp;
              //this.checkForStatusToUpload(course[0], lp);
            } else {
              //this.checkForCoursesInsidePackage(lp);
            }
          });
        }
      });
    if (matchedCourseList.length !== 0) {
      if (matchedLp.PathName.toLowerCase() === 'migrated') {
        this.checkForCoursesInsidePackage(matchedLp);
      } else {
        this.checkForStatusToUpload(matchedCourseList[0], matchedLp);
      }
    } else {
      this.checkForCoursesInsidePackage(matchedLp);
    }
  }
  checkForCoursesInsidePackage(lp) {
    this.eCertificateSubscription.lpSubscription = this.userDetailsStore
      .select(
        fromUserDetailsStore.getCourseProgressEntitiesByIdSelector(
          this.selectedCourse.Id
        )
      )
      .subscribe(cpList => {
        //console.log('course details inside package', cpList);
        if (cpList !== undefined && cpList !== null) {
          if (Object.keys(lp).length === 0 || lp.PathName === undefined) {
            this.uploadBtnTitle = 'Uploading...';
            this.mUploadBtnTitle = 'Uploading...';
            this.apiCallForBlob();
          } else {
            this.checkForStatusToUpload(cpList, lp);
          }
        } else {
          this.uploadBtnTitle = 'Uploading...';
          this.mUploadBtnTitle = 'Uploading...';
          this.apiCallForBlob();
        }
      });
  }
  checkForStatusToUpload(course, lp) {
    const data = {
      lpName: lp.PathName,
      lpId: lp.PathId,
      isMandatory: lp.IsMandatory,
      wfStatus: course.WorflowStatus
    };
    if (
      course.WorflowStatus === null ||
      course.WorflowStatus === '' ||
      course.WorflowStatus.toLowerCase() === 'not started' ||
      course.WorflowStatus.toLowerCase() === 'cancelled' ||
      course.WorflowStatus.toLowerCase() === 'rejected' ||
      course.WorflowStatus.toLowerCase() === 'request cancelled'
    ) {
      this.openpopup('Confirmation', data);
    } else {
      this.openpopup('Conflict', data);
    }
  }
  apiCallForBlob() {
    this.ecertificateService
      .uploadToBlob(this.eCertifcateUploadFile, this.selectedCourse.Id)
      .then((response: any) => {
        this.apiCallForSql(response.Msg);
      })
      .catch((error: any) => {
        if (
          error.error.Msg ===
          "Currently this course is in Pending/Approved Status so you can't upload"
        ) {
          this.courseScheduled = true;
        } else if (error.error.Msg === 'This course already exist in your LP') {
          this.courseExist = true;
        } else {
          this.openpopup('Failure', error.error.Msg);
          this.uploadBtnTitle = 'Upload';
          this.mUploadBtnTitle = 'Upload';
          // this.uploadBtnClicked = false;
          // this.disableUploadButton = true;
        }
      });
  }
  apiCallForSql(fileUrl: string) {
    const certStartDate =
      this.selectedCertificationDate.getFullYear() +
      '-' +
      (this.selectedCertificationDate.getMonth() + 1) +
      '-' +
      this.selectedCertificationDate.getDate();
    let certExptDate;
    if (this.selectedExpiryDate !== '') {
      certExptDate =
        this.selectedExpiryDate.getFullYear() +
        '-' +
        (this.selectedExpiryDate.getMonth() + 1) +
        '-' +
        this.selectedExpiryDate.getDate();
    } else {
      certExptDate = this.selectedExpiryDate;
    }
    const obj = {
      RequestId: 0,
      Mid: '',
      IsCourse_available: false,
      Academy: this.selectedAcademy.Name,
      Genre: this.selectedGenre.Name,
      Skill: this.selectedSkill.Name,
      CourseName: this.selectedCourse.Name,
      CourseId: this.selectedCourse.Id,
      Certificate_Name: '',
      Brief_desc: '',
      Certification_dt: certStartDate,
      Expiry_Dt: certExptDate,
      fileAzuredbPath: fileUrl,
      IsCheck_noexpiry: this.noExpDateCheckBox,
      IsCheck_beforeDOJ: this.beforeJoiningCheckBox,
      CertficateStatus: 'Pending',
      RequestedDate: '',
      RequestedBy: '',
      LastModifiedDate: '',
      LastModifiedBy: '',
      Remarks: '',
      Department: ''
    };
    //console.log('payload for sql api call', obj);
    const successMessage =
      'Certificate has been uploaded successfully for ' +
      this.selectedCourse.Name;
    const errorMessage = 'Some thing went wrong';
    this.ecertificateService.uploadToSql(obj).subscribe(
      res => {
        this.uploadBtnTitle = 'Uploaded';
        this.mUploadBtnTitle = 'Uploaded';
        this.openpopup('Success', successMessage);
        //reset all variable
        this.resetAllVariable();
        this.successfullyUploded = true;
        this.selectedCertificationDate = '';
        this.selectedExpiryDate = '';
        this.noExpDateCheckBox = false;
        this.eCertifcateUploadFile = '';
      },
      error => {
        this.uploadBtnTitle = 'Failed';
        this.mUploadBtnTitle = 'Failed';
        this.openpopup('Failure', errorMessage);
        //reset all variable
        this.resetAllVariable();
        this.selectedCertificationDate = '';
        this.selectedExpiryDate = '';
        this.noExpDateCheckBox = false;
        this.eCertifcateUploadFile = '';
      }
    );
  }
  openpopup(status, data) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.panelClass = 'popupDialogContainer';
    dialogConfig.data = {
      status: status,
      data: data
    };
    const response = this._popup.open(ECertificatePopupComponent, dialogConfig);
    response.afterClosed().subscribe(res => {
      //do something after pop up close
      //console.log(res);
      if (res === 'Yes') {
        this.uploadBtnTitle = 'Uploading...';
        this.mUploadBtnTitle = 'Uploading...';
        this.apiCallForBlob();
      }
    });
  }
  back() {
    window.history.back();
  }
  ngOnDestroy() {
    this.unsubscribeAllSubscriptions();
  }
  unsubscribeAllSubscriptions() {
    for (let subscriberKey in this.eCertificateSubscription) {
      let subscriber = this.eCertificateSubscription[subscriberKey];
      if (subscriber instanceof Subscriber) {
        subscriber.unsubscribe();
      }
    }
  }
}
