import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap } from 'rxjs/operators';
import {
  EnvironmentService,
  Ienvironment
} from '@YorbitWorkspace/global-environments';

@Injectable({
  providedIn: 'root'
})
export class ECertificateUploadService {
  config: Ienvironment;
  constructor(private http: HttpClient, private _envSvc: EnvironmentService) {
    this.config = this._envSvc.getEnvironment();
  }
  getExternalCourses(): Observable<any> {
    return this.http
      .get(this.config.apiUrl + 'Course/ExternalCertificationCourses')
      .pipe(
        map((res: Response) => res),
        catchError((e: Response) => throwError(e))
      );
  }
  uploadToBlob(file, courseId): any {
    const fd = new FormData();
    fd.append('file', file, file.name);
    //const httpHeaders = new HttpHeaders().append('Content-Type', 'undefined');
    return this.http
      .post(this.config.apiUrl + 'AzureBlob/Upload/Certificate/' + courseId, fd)
      .toPromise();
  }
  uploadToSql(certData): Observable<any> {
    return this.http
      .post(this.config.apiUrl + 'UploadSql/Certificate', certData)
      .pipe(
        tap((res: Response) => res),
        catchError((e: Response) => throwError(e))
      );
  }
}
