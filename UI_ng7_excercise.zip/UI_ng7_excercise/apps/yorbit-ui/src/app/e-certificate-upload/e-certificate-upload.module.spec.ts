import { ECertificateUploadModule } from './e-certificate-upload.module';

describe('ECertificateUploadModule', () => {
  let eCertificateUploadModule: ECertificateUploadModule;

  beforeEach(() => {
    eCertificateUploadModule = new ECertificateUploadModule();
  });

  it('should create an instance', () => {
    expect(eCertificateUploadModule).toBeTruthy();
  });
});
