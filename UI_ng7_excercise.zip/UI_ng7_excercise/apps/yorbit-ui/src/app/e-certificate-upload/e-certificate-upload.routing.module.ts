import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ECertificateUploadComponent } from './e-certificate-upload.component';

const routes: Routes = [{ path: '', component: ECertificateUploadComponent }];

@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes)]
})
export class ECertificateUploadRoutingModule {}
