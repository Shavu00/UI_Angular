import { TestBed, inject } from '@angular/core/testing';

import { ECertificateUploadService } from './e-certificate-upload.service';

describe('ECertificateUploadService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ECertificateUploadService]
    });
  });

  it('should be created', inject(
    [ECertificateUploadService],
    (service: ECertificateUploadService) => {
      expect(service).toBeTruthy();
    }
  ));
});
