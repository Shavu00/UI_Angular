import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ECertificateUploadComponent } from './e-certificate-upload.component';

describe('ECertificateUploadComponent', () => {
  let component: ECertificateUploadComponent;
  let fixture: ComponentFixture<ECertificateUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ECertificateUploadComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ECertificateUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
